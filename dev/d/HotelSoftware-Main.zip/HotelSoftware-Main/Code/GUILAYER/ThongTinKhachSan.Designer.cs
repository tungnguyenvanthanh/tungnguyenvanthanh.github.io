﻿namespace GUILAYER
{
    partial class ThongTinKhachSan
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinKhachSan));
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.NutHuy = new DevExpress.XtraEditors.SimpleButton();
            this.NutOK = new DevExpress.XtraEditors.SimpleButton();
            this.LabelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.SetHotNumber = new DevExpress.XtraEditors.TextEdit();
            this.MailPassword = new DevExpress.XtraEditors.TextEdit();
            this.MailUsername = new DevExpress.XtraEditors.TextEdit();
            this.Logo = new DevExpress.XtraEditors.PictureEdit();
            ((System.ComponentModel.ISupportInitialize)(this.SetHotNumber.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MailPassword.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MailUsername.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logo.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(12, 207);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(110, 26);
            this.LabelControl1.TabIndex = 0;
            this.LabelControl1.Text = "Username";
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Location = new System.Drawing.Point(12, 270);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(102, 26);
            this.LabelControl2.TabIndex = 1;
            this.LabelControl2.Text = "Password";
            // 
            // NutHuy
            // 
            this.NutHuy.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutHuy.Appearance.Options.UseFont = true;
            this.NutHuy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutHuy.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.NutHuy.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutHuy.ImageOptions.SvgImage")));
            this.NutHuy.Location = new System.Drawing.Point(359, 328);
            this.NutHuy.Name = "NutHuy";
            this.NutHuy.Size = new System.Drawing.Size(94, 46);
            this.NutHuy.TabIndex = 8;
            this.NutHuy.Text = "HỦY";
            // 
            // NutOK
            // 
            this.NutOK.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutOK.Appearance.Options.UseFont = true;
            this.NutOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutOK.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutOK.ImageOptions.SvgImage")));
            this.NutOK.Location = new System.Drawing.Point(471, 328);
            this.NutOK.Name = "NutOK";
            this.NutOK.Size = new System.Drawing.Size(94, 46);
            this.NutOK.TabIndex = 7;
            this.NutOK.Text = "OK";
            this.NutOK.Click += new System.EventHandler(this.OK_Click);
            // 
            // LabelControl3
            // 
            this.LabelControl3.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LabelControl3.Appearance.Options.UseFont = true;
            this.LabelControl3.Location = new System.Drawing.Point(12, 149);
            this.LabelControl3.Name = "LabelControl3";
            this.LabelControl3.Size = new System.Drawing.Size(118, 26);
            this.LabelControl3.TabIndex = 11;
            this.LabelControl3.Text = "Điện Thoại";
            // 
            // SetHotNumber
            // 
            this.SetHotNumber.Location = new System.Drawing.Point(145, 146);
            this.SetHotNumber.Name = "SetHotNumber";
            this.SetHotNumber.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SetHotNumber.Properties.Appearance.Options.UseFont = true;
            this.SetHotNumber.Size = new System.Drawing.Size(420, 32);
            this.SetHotNumber.TabIndex = 1;
            // 
            // MailPassword
            // 
            this.MailPassword.Location = new System.Drawing.Point(145, 267);
            this.MailPassword.Name = "MailPassword";
            this.MailPassword.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MailPassword.Properties.Appearance.Options.UseFont = true;
            this.MailPassword.Size = new System.Drawing.Size(420, 32);
            this.MailPassword.TabIndex = 3;
            // 
            // MailUsername
            // 
            this.MailUsername.Location = new System.Drawing.Point(145, 204);
            this.MailUsername.Name = "MailUsername";
            this.MailUsername.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MailUsername.Properties.Appearance.Options.UseFont = true;
            this.MailUsername.Size = new System.Drawing.Size(420, 32);
            this.MailUsername.TabIndex = 2;
            // 
            // Logo
            // 
            this.Logo.EditValue = global::GUILAYER.Properties.Resources.Logo;
            this.Logo.Location = new System.Drawing.Point(240, 10);
            this.Logo.Name = "Logo";
            this.Logo.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.Logo.Properties.Appearance.Options.UseBackColor = true;
            this.Logo.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.Logo.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.Logo.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Zoom;
            this.Logo.Size = new System.Drawing.Size(100, 100);
            this.Logo.TabIndex = 17;
            // 
            // ThongTinKhachSan
            // 
            this.AcceptButton = this.NutOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.NutHuy;
            this.ClientSize = new System.Drawing.Size(580, 393);
            this.Controls.Add(this.Logo);
            this.Controls.Add(this.SetHotNumber);
            this.Controls.Add(this.LabelControl3);
            this.Controls.Add(this.NutHuy);
            this.Controls.Add(this.NutOK);
            this.Controls.Add(this.MailPassword);
            this.Controls.Add(this.MailUsername);
            this.Controls.Add(this.LabelControl2);
            this.Controls.Add(this.LabelControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ThongTinKhachSan";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "THÔNG TIN KHÁCH SẠN";
            this.Load += new System.EventHandler(this.Form_Load);
            ((System.ComponentModel.ISupportInitialize)(this.SetHotNumber.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MailPassword.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MailUsername.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Logo.Properties)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private DevExpress.XtraEditors.LabelControl LabelControl2;
        private DevExpress.XtraEditors.TextEdit MailUsername;
        private DevExpress.XtraEditors.TextEdit MailPassword;
        private DevExpress.XtraEditors.SimpleButton NutHuy;
        private DevExpress.XtraEditors.SimpleButton NutOK;
        private DevExpress.XtraEditors.TextEdit SetHotNumber;
        private DevExpress.XtraEditors.LabelControl LabelControl3;
        private DevExpress.XtraEditors.PictureEdit Logo;
    }
}