﻿using System;
using System.Linq;

namespace GUILAYER
{
    public partial class PhanTichDuLieuTheoM : DevExpress.XtraEditors.XtraUserControl
    {
        public PhanTichDuLieuTheoM()
        {
            InitializeComponent();
        }
    }
}
