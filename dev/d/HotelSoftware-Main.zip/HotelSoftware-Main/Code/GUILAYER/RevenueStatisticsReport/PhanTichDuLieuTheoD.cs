﻿using System;
using System.Linq;

namespace GUILAYER
{
    public partial class PhanTichDuLieuTheoD : DevExpress.XtraEditors.XtraUserControl
    {
        public PhanTichDuLieuTheoD()
        {
            InitializeComponent();
        }
    }
}
