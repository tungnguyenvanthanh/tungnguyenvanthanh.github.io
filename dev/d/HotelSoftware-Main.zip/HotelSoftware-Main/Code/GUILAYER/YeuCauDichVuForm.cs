﻿using System;
using System.Linq;

namespace GUILAYER
{
    public partial class YeuCauDichVuForm : DevExpress.XtraEditors.XtraForm
    {
        public YeuCauDichVuForm()
        {
            InitializeComponent();
        }
    }
}