﻿using System;
using System.Linq;

namespace GUILAYER
{
    public partial class ChuyenPhongForm : DevExpress.XtraEditors.XtraForm
    {
        public ChuyenPhongForm()
        {
            InitializeComponent();
        }
    }
}