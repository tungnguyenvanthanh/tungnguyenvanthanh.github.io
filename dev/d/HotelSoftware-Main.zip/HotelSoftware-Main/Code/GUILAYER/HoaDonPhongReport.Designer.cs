﻿namespace GUILAYER
{
    partial class HoaDonPhongReport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DevExpress.XtraReports.UI.XRWatermark xrWatermark1 = new DevExpress.XtraReports.UI.XRWatermark();
            this.TopMargin = new DevExpress.XtraReports.UI.TopMarginBand();
            this.BottomMargin = new DevExpress.XtraReports.UI.BottomMarginBand();
            this.Detail = new DevExpress.XtraReports.UI.DetailBand();
            this.Line4 = new DevExpress.XtraReports.UI.XRLine();
            this.Line3 = new DevExpress.XtraReports.UI.XRLine();
            this.Line2 = new DevExpress.XtraReports.UI.XRLine();
            this.Line1 = new DevExpress.XtraReports.UI.XRLine();
            this.Label31 = new DevExpress.XtraReports.UI.XRLabel();
            this.LucTraTien = new DevExpress.XtraReports.UI.XRLabel();
            this.TrangThai = new DevExpress.XtraReports.UI.XRLabel();
            this.Label28 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label26 = new DevExpress.XtraReports.UI.XRLabel();
            this.GiamGia = new DevExpress.XtraReports.UI.XRLabel();
            this.GiaCanThanhToan = new DevExpress.XtraReports.UI.XRLabel();
            this.Label27 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label25 = new DevExpress.XtraReports.UI.XRLabel();
            this.GiaPhongBanDau = new DevExpress.XtraReports.UI.XRLabel();
            this.NgayThanhToan = new DevExpress.XtraReports.UI.XRLabel();
            this.Label24 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label16 = new DevExpress.XtraReports.UI.XRLabel();
            this.ThoiHan = new DevExpress.XtraReports.UI.XRLabel();
            this.LoaiHinh = new DevExpress.XtraReports.UI.XRLabel();
            this.Label17 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label15 = new DevExpress.XtraReports.UI.XRLabel();
            this.NgayTra = new DevExpress.XtraReports.UI.XRLabel();
            this.NgayLay = new DevExpress.XtraReports.UI.XRLabel();
            this.Label14 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label13 = new DevExpress.XtraReports.UI.XRLabel();
            this.NgayDat = new DevExpress.XtraReports.UI.XRLabel();
            this.TenPhong = new DevExpress.XtraReports.UI.XRLabel();
            this.QuocTich = new DevExpress.XtraReports.UI.XRLabel();
            this.QueQuan = new DevExpress.XtraReports.UI.XRLabel();
            this.Email = new DevExpress.XtraReports.UI.XRLabel();
            this.LienHe = new DevExpress.XtraReports.UI.XRLabel();
            this.HoVaTen = new DevExpress.XtraReports.UI.XRLabel();
            this.MaKhach = new DevExpress.XtraReports.UI.XRLabel();
            this.NgayHD = new DevExpress.XtraReports.UI.XRLabel();
            this.MaHoaDon = new DevExpress.XtraReports.UI.XRLabel();
            this.Label12 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label10 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label11 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label8 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label7 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label9 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label6 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label21 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label4 = new DevExpress.XtraReports.UI.XRLabel();
            this.ReportHeader = new DevExpress.XtraReports.UI.ReportHeaderBand();
            this.Label35 = new DevExpress.XtraReports.UI.XRLabel();
            this.DiaChiMailKS = new DevExpress.XtraReports.UI.XRLabel();
            this.SoDienThoaiKS = new DevExpress.XtraReports.UI.XRLabel();
            this.Label34 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label20 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label2 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label1 = new DevExpress.XtraReports.UI.XRLabel();
            this.Label32 = new DevExpress.XtraReports.UI.XRLabel();
            this.ReportFooter = new DevExpress.XtraReports.UI.ReportFooterBand();
            ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
            // 
            // TopMargin
            // 
            this.TopMargin.Name = "TopMargin";
            // 
            // BottomMargin
            // 
            this.BottomMargin.Name = "BottomMargin";
            // 
            // Detail
            // 
            this.Detail.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.Line4,
            this.Line3,
            this.Line2,
            this.Line1,
            this.Label31,
            this.LucTraTien,
            this.TrangThai,
            this.Label28,
            this.Label26,
            this.GiamGia,
            this.GiaCanThanhToan,
            this.Label27,
            this.Label25,
            this.GiaPhongBanDau,
            this.NgayThanhToan,
            this.Label24,
            this.Label16,
            this.ThoiHan,
            this.LoaiHinh,
            this.Label17,
            this.Label15,
            this.NgayTra,
            this.NgayLay,
            this.Label14,
            this.Label13,
            this.NgayDat,
            this.TenPhong,
            this.QuocTich,
            this.QueQuan,
            this.Email,
            this.LienHe,
            this.HoVaTen,
            this.MaKhach,
            this.NgayHD,
            this.MaHoaDon,
            this.Label12,
            this.Label10,
            this.Label11,
            this.Label8,
            this.Label7,
            this.Label9,
            this.Label6,
            this.Label21,
            this.Label4});
            this.Detail.HeightF = 654.8719F;
            this.Detail.Name = "Detail";
            // 
            // Line4
            // 
            this.Line4.LineWidth = 2F;
            this.Line4.LocationFloat = new DevExpress.Utils.PointFloat(1.667114F, 651.7469F);
            this.Line4.Name = "Line4";
            this.Line4.SizeF = new System.Drawing.SizeF(625.3329F, 3.125F);
            // 
            // Line3
            // 
            this.Line3.LineWidth = 2F;
            this.Line3.LocationFloat = new DevExpress.Utils.PointFloat(0.0006713867F, 477.9136F);
            this.Line3.Name = "Line3";
            this.Line3.SizeF = new System.Drawing.SizeF(625.3329F, 3.125F);
            // 
            // Line2
            // 
            this.Line2.LineWidth = 2F;
            this.Line2.LocationFloat = new DevExpress.Utils.PointFloat(0.0006713867F, 300.7051F);
            this.Line2.Name = "Line2";
            this.Line2.SizeF = new System.Drawing.SizeF(625.3329F, 3.125F);
            // 
            // Line1
            // 
            this.Line1.LineWidth = 2F;
            this.Line1.LocationFloat = new DevExpress.Utils.PointFloat(0.0002670288F, 76.38885F);
            this.Line1.Name = "Line1";
            this.Line1.SizeF = new System.Drawing.SizeF(625.3329F, 3.125F);
            // 
            // Label31
            // 
            this.Label31.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label31.LocationFloat = new DevExpress.Utils.PointFloat(0.0001017253F, 550.2048F);
            this.Label31.Multiline = true;
            this.Label31.Name = "Label31";
            this.Label31.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label31.SizeF = new System.Drawing.SizeF(105.8333F, 23.00006F);
            this.Label31.StylePriority.UseFont = false;
            this.Label31.StylePriority.UseTextAlignment = false;
            this.Label31.Text = "Lúc Trả Tiền:";
            this.Label31.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // LucTraTien
            // 
            this.LucTraTien.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.LucTraTien.LocationFloat = new DevExpress.Utils.PointFloat(105.8334F, 550.2051F);
            this.LucTraTien.Multiline = true;
            this.LucTraTien.Name = "LucTraTien";
            this.LucTraTien.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.LucTraTien.SizeF = new System.Drawing.SizeF(193.5001F, 23F);
            this.LucTraTien.StylePriority.UseFont = false;
            this.LucTraTien.StylePriority.UseTextAlignment = false;
            this.LucTraTien.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // TrangThai
            // 
            this.TrangThai.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.TrangThai.LocationFloat = new DevExpress.Utils.PointFloat(474.9998F, 501.8719F);
            this.TrangThai.Multiline = true;
            this.TrangThai.Name = "TrangThai";
            this.TrangThai.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.TrangThai.SizeF = new System.Drawing.SizeF(150.3335F, 22.99997F);
            this.TrangThai.StylePriority.UseFont = false;
            this.TrangThai.StylePriority.UseTextAlignment = false;
            this.TrangThai.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label28
            // 
            this.Label28.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label28.LocationFloat = new DevExpress.Utils.PointFloat(349.9998F, 501.8719F);
            this.Label28.Multiline = true;
            this.Label28.Name = "Label28";
            this.Label28.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label28.SizeF = new System.Drawing.SizeF(125F, 23F);
            this.Label28.StylePriority.UseFont = false;
            this.Label28.StylePriority.UseTextAlignment = false;
            this.Label28.Text = "Trạng Thái HĐ:";
            this.Label28.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label26
            // 
            this.Label26.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label26.LocationFloat = new DevExpress.Utils.PointFloat(349.9998F, 550.2054F);
            this.Label26.Multiline = true;
            this.Label26.Name = "Label26";
            this.Label26.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label26.SizeF = new System.Drawing.SizeF(113.3333F, 23F);
            this.Label26.StylePriority.UseFont = false;
            this.Label26.StylePriority.UseTextAlignment = false;
            this.Label26.Text = "Giảm Giá(%):";
            this.Label26.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // GiamGia
            // 
            this.GiamGia.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.GiamGia.LocationFloat = new DevExpress.Utils.PointFloat(463.3331F, 550.2051F);
            this.GiamGia.Multiline = true;
            this.GiamGia.Name = "GiamGia";
            this.GiamGia.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.GiamGia.SizeF = new System.Drawing.SizeF(162.0001F, 23F);
            this.GiamGia.StylePriority.UseFont = false;
            this.GiamGia.StylePriority.UseTextAlignment = false;
            this.GiamGia.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // GiaCanThanhToan
            // 
            this.GiaCanThanhToan.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.GiaCanThanhToan.LocationFloat = new DevExpress.Utils.PointFloat(463.3331F, 601.0388F);
            this.GiaCanThanhToan.Multiline = true;
            this.GiaCanThanhToan.Name = "GiaCanThanhToan";
            this.GiaCanThanhToan.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.GiaCanThanhToan.SizeF = new System.Drawing.SizeF(162.0002F, 23F);
            this.GiaCanThanhToan.StylePriority.UseFont = false;
            this.GiaCanThanhToan.StylePriority.UseTextAlignment = false;
            this.GiaCanThanhToan.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label27
            // 
            this.Label27.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label27.LocationFloat = new DevExpress.Utils.PointFloat(349.9998F, 601.0385F);
            this.Label27.Multiline = true;
            this.Label27.Name = "Label27";
            this.Label27.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label27.SizeF = new System.Drawing.SizeF(113.3333F, 23.00006F);
            this.Label27.StylePriority.UseFont = false;
            this.Label27.StylePriority.UseTextAlignment = false;
            this.Label27.Text = "Giá Phải Trả:";
            this.Label27.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label25
            // 
            this.Label25.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label25.LocationFloat = new DevExpress.Utils.PointFloat(0.0001780192F, 601.0385F);
            this.Label25.Multiline = true;
            this.Label25.Name = "Label25";
            this.Label25.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label25.SizeF = new System.Drawing.SizeF(132.4999F, 23F);
            this.Label25.StylePriority.UseFont = false;
            this.Label25.StylePriority.UseTextAlignment = false;
            this.Label25.Text = "Giá Phòng Gốc:";
            this.Label25.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // GiaPhongBanDau
            // 
            this.GiaPhongBanDau.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.GiaPhongBanDau.LocationFloat = new DevExpress.Utils.PointFloat(132.5F, 601.0385F);
            this.GiaPhongBanDau.Multiline = true;
            this.GiaPhongBanDau.Name = "GiaPhongBanDau";
            this.GiaPhongBanDau.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.GiaPhongBanDau.SizeF = new System.Drawing.SizeF(166.8335F, 23F);
            this.GiaPhongBanDau.StylePriority.UseFont = false;
            this.GiaPhongBanDau.StylePriority.UseTextAlignment = false;
            this.GiaPhongBanDau.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // NgayThanhToan
            // 
            this.NgayThanhToan.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.NgayThanhToan.LocationFloat = new DevExpress.Utils.PointFloat(132.5F, 501.8719F);
            this.NgayThanhToan.Multiline = true;
            this.NgayThanhToan.Name = "NgayThanhToan";
            this.NgayThanhToan.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.NgayThanhToan.SizeF = new System.Drawing.SizeF(166.8335F, 22.99997F);
            this.NgayThanhToan.StylePriority.UseFont = false;
            this.NgayThanhToan.StylePriority.UseTextAlignment = false;
            this.NgayThanhToan.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label24
            // 
            this.Label24.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label24.LocationFloat = new DevExpress.Utils.PointFloat(5.086263E-05F, 501.8719F);
            this.Label24.Multiline = true;
            this.Label24.Name = "Label24";
            this.Label24.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label24.SizeF = new System.Drawing.SizeF(132.5F, 23.00003F);
            this.Label24.StylePriority.UseFont = false;
            this.Label24.StylePriority.UseTextAlignment = false;
            this.Label24.Text = "Ngày Giao Dịch:";
            this.Label24.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label16
            // 
            this.Label16.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label16.LocationFloat = new DevExpress.Utils.PointFloat(5.086263E-05F, 428.5385F);
            this.Label16.Multiline = true;
            this.Label16.Name = "Label16";
            this.Label16.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label16.SizeF = new System.Drawing.SizeF(84.99999F, 23.00003F);
            this.Label16.StylePriority.UseFont = false;
            this.Label16.StylePriority.UseTextAlignment = false;
            this.Label16.Text = "Thời Hạn:";
            this.Label16.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // ThoiHan
            // 
            this.ThoiHan.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.ThoiHan.LocationFloat = new DevExpress.Utils.PointFloat(85.00005F, 428.5385F);
            this.ThoiHan.Multiline = true;
            this.ThoiHan.Name = "ThoiHan";
            this.ThoiHan.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.ThoiHan.SizeF = new System.Drawing.SizeF(214.3333F, 23.00003F);
            this.ThoiHan.StylePriority.UseFont = false;
            this.ThoiHan.StylePriority.UseTextAlignment = false;
            this.ThoiHan.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // LoaiHinh
            // 
            this.LoaiHinh.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.LoaiHinh.LocationFloat = new DevExpress.Utils.PointFloat(439.9998F, 428.5387F);
            this.LoaiHinh.Multiline = true;
            this.LoaiHinh.Name = "LoaiHinh";
            this.LoaiHinh.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.LoaiHinh.SizeF = new System.Drawing.SizeF(187.0003F, 23.00003F);
            this.LoaiHinh.StylePriority.UseFont = false;
            this.LoaiHinh.StylePriority.UseTextAlignment = false;
            this.LoaiHinh.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label17
            // 
            this.Label17.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label17.LocationFloat = new DevExpress.Utils.PointFloat(349.9998F, 428.5387F);
            this.Label17.Multiline = true;
            this.Label17.Name = "Label17";
            this.Label17.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label17.SizeF = new System.Drawing.SizeF(90F, 22.99997F);
            this.Label17.StylePriority.UseFont = false;
            this.Label17.StylePriority.UseTextAlignment = false;
            this.Label17.Text = "Loại Hình:";
            this.Label17.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label15
            // 
            this.Label15.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label15.LocationFloat = new DevExpress.Utils.PointFloat(349.9999F, 377.7052F);
            this.Label15.Multiline = true;
            this.Label15.Name = "Label15";
            this.Label15.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label15.SizeF = new System.Drawing.SizeF(89.99988F, 23.00003F);
            this.Label15.StylePriority.UseFont = false;
            this.Label15.StylePriority.UseTextAlignment = false;
            this.Label15.Text = "Ngày Trả:";
            this.Label15.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // NgayTra
            // 
            this.NgayTra.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.NgayTra.LocationFloat = new DevExpress.Utils.PointFloat(439.9998F, 377.7052F);
            this.NgayTra.Multiline = true;
            this.NgayTra.Name = "NgayTra";
            this.NgayTra.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.NgayTra.SizeF = new System.Drawing.SizeF(187.0002F, 23.00003F);
            this.NgayTra.StylePriority.UseFont = false;
            this.NgayTra.StylePriority.UseTextAlignment = false;
            this.NgayTra.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // NgayLay
            // 
            this.NgayLay.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.NgayLay.LocationFloat = new DevExpress.Utils.PointFloat(85.00005F, 377.7052F);
            this.NgayLay.Multiline = true;
            this.NgayLay.Name = "NgayLay";
            this.NgayLay.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.NgayLay.SizeF = new System.Drawing.SizeF(214.3334F, 23.00003F);
            this.NgayLay.StylePriority.UseFont = false;
            this.NgayLay.StylePriority.UseTextAlignment = false;
            this.NgayLay.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label14
            // 
            this.Label14.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label14.LocationFloat = new DevExpress.Utils.PointFloat(5.086263E-05F, 377.7052F);
            this.Label14.Multiline = true;
            this.Label14.Name = "Label14";
            this.Label14.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label14.SizeF = new System.Drawing.SizeF(85F, 23F);
            this.Label14.StylePriority.UseFont = false;
            this.Label14.StylePriority.UseTextAlignment = false;
            this.Label14.Text = "Ngày Lấy:";
            this.Label14.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label13
            // 
            this.Label13.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label13.LocationFloat = new DevExpress.Utils.PointFloat(349.9998F, 328.8718F);
            this.Label13.Multiline = true;
            this.Label13.Name = "Label13";
            this.Label13.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label13.SizeF = new System.Drawing.SizeF(90F, 23.00003F);
            this.Label13.StylePriority.UseFont = false;
            this.Label13.StylePriority.UseTextAlignment = false;
            this.Label13.Text = "Ngày Đặt:";
            this.Label13.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // NgayDat
            // 
            this.NgayDat.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.NgayDat.LocationFloat = new DevExpress.Utils.PointFloat(439.9998F, 328.8718F);
            this.NgayDat.Multiline = true;
            this.NgayDat.Name = "NgayDat";
            this.NgayDat.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.NgayDat.SizeF = new System.Drawing.SizeF(187.0003F, 23F);
            this.NgayDat.StylePriority.UseFont = false;
            this.NgayDat.StylePriority.UseTextAlignment = false;
            this.NgayDat.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // TenPhong
            // 
            this.TenPhong.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.TenPhong.LocationFloat = new DevExpress.Utils.PointFloat(95.00005F, 328.8718F);
            this.TenPhong.Multiline = true;
            this.TenPhong.Name = "TenPhong";
            this.TenPhong.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.TenPhong.SizeF = new System.Drawing.SizeF(204.3334F, 23.00003F);
            this.TenPhong.StylePriority.UseFont = false;
            this.TenPhong.StylePriority.UseTextAlignment = false;
            this.TenPhong.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // QuocTich
            // 
            this.QuocTich.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.QuocTich.LocationFloat = new DevExpress.Utils.PointFloat(88.33359F, 201.0384F);
            this.QuocTich.Multiline = true;
            this.QuocTich.Name = "QuocTich";
            this.QuocTich.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.QuocTich.SizeF = new System.Drawing.SizeF(210.9999F, 22.99998F);
            this.QuocTich.StylePriority.UseFont = false;
            this.QuocTich.StylePriority.UseTextAlignment = false;
            this.QuocTich.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // QueQuan
            // 
            this.QueQuan.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.QueQuan.LocationFloat = new DevExpress.Utils.PointFloat(439.9998F, 150.205F);
            this.QueQuan.Multiline = true;
            this.QueQuan.Name = "QueQuan";
            this.QueQuan.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.QueQuan.SizeF = new System.Drawing.SizeF(187.0003F, 123.8334F);
            this.QueQuan.StylePriority.UseFont = false;
            this.QueQuan.StylePriority.UseTextAlignment = false;
            this.QueQuan.TextAlignment = DevExpress.XtraPrinting.TextAlignment.TopJustify;
            // 
            // Email
            // 
            this.Email.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.Email.LocationFloat = new DevExpress.Utils.PointFloat(61.66672F, 251.0384F);
            this.Email.Multiline = true;
            this.Email.Name = "Email";
            this.Email.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Email.SizeF = new System.Drawing.SizeF(237.6668F, 23.00005F);
            this.Email.StylePriority.UseFont = false;
            this.Email.StylePriority.UseTextAlignment = false;
            this.Email.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // LienHe
            // 
            this.LienHe.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.LienHe.LocationFloat = new DevExpress.Utils.PointFloat(61.66672F, 150.205F);
            this.LienHe.Multiline = true;
            this.LienHe.Name = "LienHe";
            this.LienHe.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.LienHe.SizeF = new System.Drawing.SizeF(237.6668F, 23.00002F);
            this.LienHe.StylePriority.UseFont = false;
            this.LienHe.StylePriority.UseTextAlignment = false;
            this.LienHe.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // HoVaTen
            // 
            this.HoVaTen.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.HoVaTen.LocationFloat = new DevExpress.Utils.PointFloat(439.9998F, 103.0384F);
            this.HoVaTen.Multiline = true;
            this.HoVaTen.Name = "HoVaTen";
            this.HoVaTen.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.HoVaTen.SizeF = new System.Drawing.SizeF(187.0002F, 22.99998F);
            this.HoVaTen.StylePriority.UseFont = false;
            this.HoVaTen.StylePriority.UseTextAlignment = false;
            this.HoVaTen.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // MaKhach
            // 
            this.MaKhach.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.MaKhach.LocationFloat = new DevExpress.Utils.PointFloat(90.00005F, 103.0384F);
            this.MaKhach.Multiline = true;
            this.MaKhach.Name = "MaKhach";
            this.MaKhach.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.MaKhach.SizeF = new System.Drawing.SizeF(209.3334F, 23F);
            this.MaKhach.StylePriority.UseFont = false;
            this.MaKhach.StylePriority.UseTextAlignment = false;
            this.MaKhach.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // NgayHD
            // 
            this.NgayHD.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.NgayHD.LocationFloat = new DevExpress.Utils.PointFloat(429.9998F, 26.66662F);
            this.NgayHD.Multiline = true;
            this.NgayHD.Name = "NgayHD";
            this.NgayHD.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.NgayHD.SizeF = new System.Drawing.SizeF(197.0002F, 23F);
            this.NgayHD.StylePriority.UseFont = false;
            this.NgayHD.StylePriority.UseTextAlignment = false;
            this.NgayHD.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // MaHoaDon
            // 
            this.MaHoaDon.Font = new DevExpress.Drawing.DXFont("Verdana", 10F);
            this.MaHoaDon.LocationFloat = new DevExpress.Utils.PointFloat(105.8334F, 26.66662F);
            this.MaHoaDon.Multiline = true;
            this.MaHoaDon.Name = "MaHoaDon";
            this.MaHoaDon.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.MaHoaDon.SizeF = new System.Drawing.SizeF(193.5F, 23F);
            this.MaHoaDon.StylePriority.UseFont = false;
            this.MaHoaDon.StylePriority.UseTextAlignment = false;
            this.MaHoaDon.Text = "Primary Key";
            this.MaHoaDon.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label12
            // 
            this.Label12.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label12.LocationFloat = new DevExpress.Utils.PointFloat(0.0001525879F, 328.8718F);
            this.Label12.Multiline = true;
            this.Label12.Name = "Label12";
            this.Label12.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label12.SizeF = new System.Drawing.SizeF(94.99991F, 23.00003F);
            this.Label12.StylePriority.UseFont = false;
            this.Label12.StylePriority.UseTextAlignment = false;
            this.Label12.Text = "Tên Phòng:";
            this.Label12.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label10
            // 
            this.Label10.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label10.LocationFloat = new DevExpress.Utils.PointFloat(349.9998F, 150.205F);
            this.Label10.Multiline = true;
            this.Label10.Name = "Label10";
            this.Label10.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label10.SizeF = new System.Drawing.SizeF(90F, 23.00002F);
            this.Label10.StylePriority.UseFont = false;
            this.Label10.StylePriority.UseTextAlignment = false;
            this.Label10.Text = "Quê Quán:";
            this.Label10.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label11
            // 
            this.Label11.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label11.LocationFloat = new DevExpress.Utils.PointFloat(0.0002670288F, 201.0384F);
            this.Label11.Multiline = true;
            this.Label11.Name = "Label11";
            this.Label11.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label11.SizeF = new System.Drawing.SizeF(88.33333F, 22.99998F);
            this.Label11.StylePriority.UseFont = false;
            this.Label11.StylePriority.UseTextAlignment = false;
            this.Label11.Text = "Quốc Tịch:";
            this.Label11.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label8
            // 
            this.Label8.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label8.LocationFloat = new DevExpress.Utils.PointFloat(5.086263E-05F, 251.0384F);
            this.Label8.Multiline = true;
            this.Label8.Name = "Label8";
            this.Label8.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label8.SizeF = new System.Drawing.SizeF(61.66667F, 22.99998F);
            this.Label8.StylePriority.UseFont = false;
            this.Label8.StylePriority.UseTextAlignment = false;
            this.Label8.Text = "Email:";
            this.Label8.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label7
            // 
            this.Label7.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label7.LocationFloat = new DevExpress.Utils.PointFloat(5.086263E-05F, 150.205F);
            this.Label7.Multiline = true;
            this.Label7.Name = "Label7";
            this.Label7.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label7.SizeF = new System.Drawing.SizeF(61.66667F, 23.00002F);
            this.Label7.StylePriority.UseFont = false;
            this.Label7.StylePriority.UseTextAlignment = false;
            this.Label7.Text = "Phone:";
            this.Label7.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label9
            // 
            this.Label9.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label9.LocationFloat = new DevExpress.Utils.PointFloat(349.9998F, 103.0384F);
            this.Label9.Multiline = true;
            this.Label9.Name = "Label9";
            this.Label9.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label9.SizeF = new System.Drawing.SizeF(90F, 23F);
            this.Label9.StylePriority.UseFont = false;
            this.Label9.StylePriority.UseTextAlignment = false;
            this.Label9.Text = "Họ Và Tên:";
            this.Label9.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label6
            // 
            this.Label6.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label6.LocationFloat = new DevExpress.Utils.PointFloat(5.086263E-05F, 103.0384F);
            this.Label6.Multiline = true;
            this.Label6.Name = "Label6";
            this.Label6.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label6.SizeF = new System.Drawing.SizeF(90F, 23F);
            this.Label6.StylePriority.UseFont = false;
            this.Label6.StylePriority.UseTextAlignment = false;
            this.Label6.Text = "Mã Khách:";
            this.Label6.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label21
            // 
            this.Label21.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label21.LocationFloat = new DevExpress.Utils.PointFloat(349.9998F, 26.66667F);
            this.Label21.Multiline = true;
            this.Label21.Name = "Label21";
            this.Label21.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label21.SizeF = new System.Drawing.SizeF(80F, 23F);
            this.Label21.StylePriority.UseFont = false;
            this.Label21.StylePriority.UseTextAlignment = false;
            this.Label21.Text = "Ngày HĐ:";
            this.Label21.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // Label4
            // 
            this.Label4.Font = new DevExpress.Drawing.DXFont("Verdana", 10F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label4.LocationFloat = new DevExpress.Utils.PointFloat(0F, 26.66667F);
            this.Label4.Multiline = true;
            this.Label4.Name = "Label4";
            this.Label4.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label4.SizeF = new System.Drawing.SizeF(105.8334F, 23F);
            this.Label4.StylePriority.UseFont = false;
            this.Label4.StylePriority.UseTextAlignment = false;
            this.Label4.Text = "Mã Hóa Đơn:";
            this.Label4.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleLeft;
            // 
            // ReportHeader
            // 
            this.ReportHeader.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.Label35,
            this.DiaChiMailKS,
            this.SoDienThoaiKS,
            this.Label34,
            this.Label20,
            this.Label2,
            this.Label1});
            this.ReportHeader.HeightF = 286.1111F;
            this.ReportHeader.Name = "ReportHeader";
            // 
            // Label35
            // 
            this.Label35.Font = new DevExpress.Drawing.DXFont("Verdana", 13F);
            this.Label35.LocationFloat = new DevExpress.Utils.PointFloat(0F, 146.5F);
            this.Label35.Multiline = true;
            this.Label35.Name = "Label35";
            this.Label35.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label35.SizeF = new System.Drawing.SizeF(51.66606F, 31.50008F);
            this.Label35.StylePriority.UseFont = false;
            this.Label35.StylePriority.UseTextAlignment = false;
            this.Label35.Text = "Mail:";
            this.Label35.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleJustify;
            // 
            // DiaChiMailKS
            // 
            this.DiaChiMailKS.Font = new DevExpress.Drawing.DXFont("Verdana", 13F);
            this.DiaChiMailKS.LocationFloat = new DevExpress.Utils.PointFloat(51.66606F, 146.5F);
            this.DiaChiMailKS.Multiline = true;
            this.DiaChiMailKS.Name = "DiaChiMailKS";
            this.DiaChiMailKS.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.DiaChiMailKS.SizeF = new System.Drawing.SizeF(573.6668F, 31.50008F);
            this.DiaChiMailKS.StylePriority.UseFont = false;
            this.DiaChiMailKS.StylePriority.UseTextAlignment = false;
            this.DiaChiMailKS.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleJustify;
            // 
            // SoDienThoaiKS
            // 
            this.SoDienThoaiKS.Font = new DevExpress.Drawing.DXFont("Verdana", 13F);
            this.SoDienThoaiKS.LocationFloat = new DevExpress.Utils.PointFloat(51.66606F, 114.9999F);
            this.SoDienThoaiKS.Multiline = true;
            this.SoDienThoaiKS.Name = "SoDienThoaiKS";
            this.SoDienThoaiKS.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.SoDienThoaiKS.SizeF = new System.Drawing.SizeF(573.6668F, 31.50008F);
            this.SoDienThoaiKS.StylePriority.UseFont = false;
            this.SoDienThoaiKS.StylePriority.UseTextAlignment = false;
            this.SoDienThoaiKS.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleJustify;
            // 
            // Label34
            // 
            this.Label34.Font = new DevExpress.Drawing.DXFont("Verdana", 13F);
            this.Label34.LocationFloat = new DevExpress.Utils.PointFloat(0F, 114.9999F);
            this.Label34.Multiline = true;
            this.Label34.Name = "Label34";
            this.Label34.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label34.SizeF = new System.Drawing.SizeF(51.66606F, 31.50008F);
            this.Label34.StylePriority.UseFont = false;
            this.Label34.StylePriority.UseTextAlignment = false;
            this.Label34.Text = "SĐT:";
            this.Label34.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleJustify;
            // 
            // Label20
            // 
            this.Label20.Font = new DevExpress.Drawing.DXFont("Times New Roman", 22F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label20.ForeColor = System.Drawing.Color.SeaGreen;
            this.Label20.LocationFloat = new DevExpress.Utils.PointFloat(0F, 199.6668F);
            this.Label20.Multiline = true;
            this.Label20.Name = "Label20";
            this.Label20.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label20.SizeF = new System.Drawing.SizeF(627F, 50.50002F);
            this.Label20.StylePriority.UseFont = false;
            this.Label20.StylePriority.UseForeColor = false;
            this.Label20.StylePriority.UseTextAlignment = false;
            this.Label20.Text = "HÓA ĐƠN THANH TOÁN PHÍ PHÒNG\r\n";
            this.Label20.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // Label2
            // 
            this.Label2.Font = new DevExpress.Drawing.DXFont("Verdana", 13F);
            this.Label2.LocationFloat = new DevExpress.Utils.PointFloat(0F, 74.66665F);
            this.Label2.Multiline = true;
            this.Label2.Name = "Label2";
            this.Label2.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label2.SizeF = new System.Drawing.SizeF(625.3329F, 40.3333F);
            this.Label2.StylePriority.UseFont = false;
            this.Label2.StylePriority.UseTextAlignment = false;
            this.Label2.Text = "Địa chỉ: Phường Xuân Khánh, Quận Ninh Kiều, TP Cần Thơ";
            this.Label2.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleJustify;
            // 
            // Label1
            // 
            this.Label1.Font = new DevExpress.Drawing.DXFont("Times New Roman", 30F, DevExpress.Drawing.DXFontStyle.Bold);
            this.Label1.ForeColor = System.Drawing.Color.SeaGreen;
            this.Label1.LocationFloat = new DevExpress.Utils.PointFloat(5.086263E-05F, 0F);
            this.Label1.Multiline = true;
            this.Label1.Name = "Label1";
            this.Label1.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label1.SizeF = new System.Drawing.SizeF(625.3333F, 74.66666F);
            this.Label1.StylePriority.UseFont = false;
            this.Label1.StylePriority.UseForeColor = false;
            this.Label1.StylePriority.UseTextAlignment = false;
            this.Label1.Text = "KHÁCH SẠN LHT CẦN THƠ";
            this.Label1.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // Label32
            // 
            this.Label32.LocationFloat = new DevExpress.Utils.PointFloat(0.0002670288F, 0F);
            this.Label32.Multiline = true;
            this.Label32.Name = "Label32";
            this.Label32.Padding = new DevExpress.XtraPrinting.PaddingInfo(2, 2, 0, 0, 100F);
            this.Label32.SizeF = new System.Drawing.SizeF(625.3333F, 23F);
            this.Label32.StylePriority.UseTextAlignment = false;
            this.Label32.Text = "KHÁCH SẠN CHÚNG TÔI RẤT HẬN HẠNH PHỤC VỤ QUÝ KHÁCH";
            this.Label32.TextAlignment = DevExpress.XtraPrinting.TextAlignment.MiddleCenter;
            // 
            // ReportFooter
            // 
            this.ReportFooter.Controls.AddRange(new DevExpress.XtraReports.UI.XRControl[] {
            this.Label32});
            this.ReportFooter.HeightF = 23F;
            this.ReportFooter.Name = "ReportFooter";
            // 
            // HoaDonPhongReport
            // 
            this.Bands.AddRange(new DevExpress.XtraReports.UI.Band[] {
            this.TopMargin,
            this.BottomMargin,
            this.Detail,
            this.ReportHeader,
            this.ReportFooter});
            this.Font = new DevExpress.Drawing.DXFont("Arial", 9.75F);
            this.PageColor = System.Drawing.Color.Empty;
            this.PageHeight = 1169;
            this.PageWidth = 827;
            this.PaperKind = DevExpress.Drawing.Printing.DXPaperKind.A4;
            this.Version = "24.1";
            xrWatermark1.Id = "Watermark1";
            this.Watermarks.AddRange(new DevExpress.XtraPrinting.Drawing.Watermark[] {
            xrWatermark1});
            this.BeforePrint += new DevExpress.XtraReports.UI.BeforePrintEventHandler(this.HoaDonPhongReport_BeforePrint);
            ((System.ComponentModel.ISupportInitialize)(this)).EndInit();

        }

        #endregion

        private DevExpress.XtraReports.UI.TopMarginBand TopMargin;
        private DevExpress.XtraReports.UI.BottomMarginBand BottomMargin;
        private DevExpress.XtraReports.UI.DetailBand Detail;
        private DevExpress.XtraReports.UI.ReportHeaderBand ReportHeader;
        private DevExpress.XtraReports.UI.XRLabel Label1;
        private DevExpress.XtraReports.UI.XRLabel Label2;
        private DevExpress.XtraReports.UI.XRLabel Label20;
        private DevExpress.XtraReports.UI.XRLabel Label4;
        private DevExpress.XtraReports.UI.XRLabel Label21;
        private DevExpress.XtraReports.UI.XRLabel Label6;
        private DevExpress.XtraReports.UI.XRLabel Label9;
        private DevExpress.XtraReports.UI.XRLabel Label7;
        private DevExpress.XtraReports.UI.XRLabel Label8;
        private DevExpress.XtraReports.UI.XRLabel Label10;
        private DevExpress.XtraReports.UI.XRLabel Label11;
        private DevExpress.XtraReports.UI.XRLabel Label12;
        private DevExpress.XtraReports.UI.XRLabel MaHoaDon;
        private DevExpress.XtraReports.UI.XRLabel LienHe;
        private DevExpress.XtraReports.UI.XRLabel HoVaTen;
        private DevExpress.XtraReports.UI.XRLabel MaKhach;
        private DevExpress.XtraReports.UI.XRLabel NgayHD;
        private DevExpress.XtraReports.UI.XRLabel Email;
        private DevExpress.XtraReports.UI.XRLabel QuocTich;
        private DevExpress.XtraReports.UI.XRLabel QueQuan;
        private DevExpress.XtraReports.UI.XRLabel TenPhong;
        private DevExpress.XtraReports.UI.XRLabel Label13;
        private DevExpress.XtraReports.UI.XRLabel NgayDat;
        private DevExpress.XtraReports.UI.XRLabel Label15;
        private DevExpress.XtraReports.UI.XRLabel NgayTra;
        private DevExpress.XtraReports.UI.XRLabel NgayLay;
        private DevExpress.XtraReports.UI.XRLabel Label14;
        private DevExpress.XtraReports.UI.XRLabel Label16;
        private DevExpress.XtraReports.UI.XRLabel ThoiHan;
        private DevExpress.XtraReports.UI.XRLabel LoaiHinh;
        private DevExpress.XtraReports.UI.XRLabel Label17;
        private DevExpress.XtraReports.UI.XRLabel NgayThanhToan;
        private DevExpress.XtraReports.UI.XRLabel Label24;
        private DevExpress.XtraReports.UI.XRLabel Label25;
        private DevExpress.XtraReports.UI.XRLabel GiaPhongBanDau;
        private DevExpress.XtraReports.UI.XRLabel Label26;
        private DevExpress.XtraReports.UI.XRLabel GiamGia;
        private DevExpress.XtraReports.UI.XRLabel GiaCanThanhToan;
        private DevExpress.XtraReports.UI.XRLabel Label27;
        private DevExpress.XtraReports.UI.XRLabel TrangThai;
        private DevExpress.XtraReports.UI.XRLabel Label28;
        private DevExpress.XtraReports.UI.XRLabel Label31;
        private DevExpress.XtraReports.UI.XRLabel LucTraTien;
        private DevExpress.XtraReports.UI.XRLabel Label32;
        private DevExpress.XtraReports.UI.ReportFooterBand ReportFooter;
        private DevExpress.XtraReports.UI.XRLine Line4;
        private DevExpress.XtraReports.UI.XRLine Line3;
        private DevExpress.XtraReports.UI.XRLine Line2;
        private DevExpress.XtraReports.UI.XRLine Line1;
        private DevExpress.XtraReports.UI.XRLabel Label34;
        private DevExpress.XtraReports.UI.XRLabel SoDienThoaiKS;
        private DevExpress.XtraReports.UI.XRLabel Label35;
        private DevExpress.XtraReports.UI.XRLabel DiaChiMailKS;
    }
}
