﻿using System;
using System.Linq;

namespace GUILAYER
{
    public partial class KhoiPhucSaoLuuForm : DevExpress.XtraEditors.XtraForm
    {
        public KhoiPhucSaoLuuForm()
        {
            InitializeComponent();
        }
    }
}