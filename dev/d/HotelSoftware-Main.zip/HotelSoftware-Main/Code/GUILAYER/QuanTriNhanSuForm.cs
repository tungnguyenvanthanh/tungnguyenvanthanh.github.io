﻿using System;
using System.Linq;

namespace GUILAYER
{
    public partial class QuanTriNhanSuForm : DevExpress.XtraEditors.XtraForm
    {
        public QuanTriNhanSuForm()
        {
            InitializeComponent();
        }
    }
}