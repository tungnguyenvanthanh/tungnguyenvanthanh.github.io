﻿namespace GUILAYER
{
    partial class DatPhongNghiForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DatPhongNghiForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            this.BarManager = new DevExpress.XtraBars.BarManager(this.components);
            this.Bar1 = new DevExpress.XtraBars.Bar();
            this.NutDatPhong = new DevExpress.XtraBars.BarButtonItem();
            this.NutHuyPhong = new DevExpress.XtraBars.BarButtonItem();
            this.BarDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.DockManager = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.HideContainerLeft = new DevExpress.XtraBars.Docking.AutoHideContainer();
            this.ThanhPhanLoaiPhongO = new DevExpress.XtraBars.Docking.DockPanel();
            this.ControlContainer1 = new DevExpress.XtraBars.Docking.ControlContainer();
            this.DangCoSan_SE = new DevExpress.XtraEditors.SpinEdit();
            this.DangNgung_SE = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.DaDuocDat_SE = new DevExpress.XtraEditors.SpinEdit();
            this.DaCoNguoi_SE = new DevExpress.XtraEditors.SpinEdit();
            this.TongPhong_SE = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.TrangThai_RG = new DevExpress.XtraEditors.RadioGroup();
            this.ThanhPhanLoaiSuKien = new DevExpress.XtraBars.Docking.DockPanel();
            this.DockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.DatPhongSearch = new DevExpress.XtraEditors.SearchControl();
            this.PhongNghi_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.KhachHang_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.TrangThai_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.TimeLine_CBB = new DevExpress.XtraEditors.ComboBoxEdit();
            this.LoaiHinh_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.HuyPhongPopup = new DevExpress.XtraBars.BarButtonItem();
            this.DatPhongHienTai = new DevExpress.XtraBars.BarButtonItem();
            this.NhatKyDatPhong = new DevExpress.XtraBars.BarButtonItem();
            this.LayPhongHienTai = new DevExpress.XtraBars.BarButtonItem();
            this.BangSuKien = new Guna.UI2.WinForms.Guna2DataGridView();
            this.MAPHONGDAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.IDKHACH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HOVATEN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MAPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYDAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYLAY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYTRA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GIAPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MALOAIHINH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENLOAIHINH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MATRANGTHAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENTRANGTHAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GHICHU = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.THOIHAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhanTrang = new DevExpress.XtraTab.XtraTabControl();
            this.TabSuKien = new DevExpress.XtraTab.XtraTabPage();
            this.TabPhongO = new DevExpress.XtraTab.XtraTabPage();
            this.PGC = new DevExpress.XtraBars.Ribbon.GalleryControl();
            this.GalleryControlClient1 = new DevExpress.XtraBars.Ribbon.GalleryControlClient();
            this.FloatingNotes = new DevExpress.Utils.ToolTipController(this.components);
            this.BangTuyChonSuKien = new DevExpress.XtraBars.PopupMenu(this.components);
            this.BangTuyChonPhongO = new DevExpress.XtraBars.PopupMenu(this.components);
            this.Lock = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.BarManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DockManager)).BeginInit();
            this.HideContainerLeft.SuspendLayout();
            this.ThanhPhanLoaiPhongO.SuspendLayout();
            this.ControlContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DangCoSan_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DangNgung_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DaDuocDat_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DaCoNguoi_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongPhong_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThai_RG.Properties)).BeginInit();
            this.ThanhPhanLoaiSuKien.SuspendLayout();
            this.DockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DatPhongSearch.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PhongNghi_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KhachHang_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThai_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeLine_CBB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LoaiHinh_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangSuKien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PhanTrang)).BeginInit();
            this.PhanTrang.SuspendLayout();
            this.TabSuKien.SuspendLayout();
            this.TabPhongO.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PGC)).BeginInit();
            this.PGC.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BangTuyChonSuKien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangTuyChonPhongO)).BeginInit();
            this.SuspendLayout();
            // 
            // BarManager
            // 
            this.BarManager.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.Bar1});
            this.BarManager.DockControls.Add(this.BarDockControlTop);
            this.BarManager.DockControls.Add(this.BarDockControlBottom);
            this.BarManager.DockControls.Add(this.BarDockControlLeft);
            this.BarManager.DockControls.Add(this.BarDockControlRight);
            this.BarManager.DockManager = this.DockManager;
            this.BarManager.Form = this;
            this.BarManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.NutDatPhong,
            this.NutHuyPhong,
            this.HuyPhongPopup,
            this.DatPhongHienTai,
            this.NhatKyDatPhong,
            this.LayPhongHienTai});
            this.BarManager.MainMenu = this.Bar1;
            this.BarManager.MaxItemId = 12;
            // 
            // Bar1
            // 
            this.Bar1.BarName = "Main menu";
            this.Bar1.DockCol = 0;
            this.Bar1.DockRow = 0;
            this.Bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.Bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.NutDatPhong, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.NutHuyPhong, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.Bar1.OptionsBar.MultiLine = true;
            this.Bar1.OptionsBar.UseWholeRow = true;
            this.Bar1.Text = "Main menu";
            // 
            // NutDatPhong
            // 
            this.NutDatPhong.Caption = "ĐẶT PHÒNG";
            this.NutDatPhong.Hint = "Cho phép đặt nhiều phòng cùng lúc";
            this.NutDatPhong.Id = 0;
            this.NutDatPhong.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutDatPhong.ImageOptions.SvgImage")));
            this.NutDatPhong.Name = "NutDatPhong";
            this.NutDatPhong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutDatPhong_ItemClick);
            // 
            // NutHuyPhong
            // 
            this.NutHuyPhong.Caption = "HỦY PHÒNG";
            this.NutHuyPhong.Hint = "Chỉ cho phép hủy từng lịch đặt phòng";
            this.NutHuyPhong.Id = 1;
            this.NutHuyPhong.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutHuyPhong.ImageOptions.SvgImage")));
            this.NutHuyPhong.Name = "NutHuyPhong";
            this.NutHuyPhong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutHuyPhong_ItemClick);
            // 
            // BarDockControlTop
            // 
            this.BarDockControlTop.CausesValidation = false;
            this.BarDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.BarDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.BarDockControlTop.Manager = this.BarManager;
            this.BarDockControlTop.Size = new System.Drawing.Size(1883, 35);
            // 
            // BarDockControlBottom
            // 
            this.BarDockControlBottom.CausesValidation = false;
            this.BarDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BarDockControlBottom.Location = new System.Drawing.Point(0, 741);
            this.BarDockControlBottom.Manager = this.BarManager;
            this.BarDockControlBottom.Size = new System.Drawing.Size(1883, 0);
            // 
            // BarDockControlLeft
            // 
            this.BarDockControlLeft.CausesValidation = false;
            this.BarDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.BarDockControlLeft.Location = new System.Drawing.Point(0, 35);
            this.BarDockControlLeft.Manager = this.BarManager;
            this.BarDockControlLeft.Size = new System.Drawing.Size(0, 706);
            // 
            // BarDockControlRight
            // 
            this.BarDockControlRight.CausesValidation = false;
            this.BarDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.BarDockControlRight.Location = new System.Drawing.Point(1883, 35);
            this.BarDockControlRight.Manager = this.BarManager;
            this.BarDockControlRight.Size = new System.Drawing.Size(0, 706);
            // 
            // DockManager
            // 
            this.DockManager.AutoHideContainers.AddRange(new DevExpress.XtraBars.Docking.AutoHideContainer[] {
            this.HideContainerLeft});
            this.DockManager.Form = this;
            this.DockManager.MenuManager = this.BarManager;
            this.DockManager.Style = DevExpress.XtraBars.Docking2010.Views.DockingViewStyle.Light;
            this.DockManager.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane",
            "DevExpress.XtraBars.TabFormControl",
            "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl",
            "DevExpress.XtraBars.ToolbarForm.ToolbarFormControl"});
            // 
            // HideContainerLeft
            // 
            this.HideContainerLeft.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.HideContainerLeft.Controls.Add(this.ThanhPhanLoaiPhongO);
            this.HideContainerLeft.Controls.Add(this.ThanhPhanLoaiSuKien);
            this.HideContainerLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.HideContainerLeft.Enabled = false;
            this.HideContainerLeft.Location = new System.Drawing.Point(0, 35);
            this.HideContainerLeft.Name = "HideContainerLeft";
            this.HideContainerLeft.Size = new System.Drawing.Size(30, 706);
            // 
            // ThanhPhanLoaiPhongO
            // 
            this.ThanhPhanLoaiPhongO.Controls.Add(this.ControlContainer1);
            this.ThanhPhanLoaiPhongO.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.ThanhPhanLoaiPhongO.FloatSize = new System.Drawing.Size(310, 722);
            this.ThanhPhanLoaiPhongO.ID = new System.Guid("cd8cddae-8ef3-4409-ae77-92378dd0440d");
            this.ThanhPhanLoaiPhongO.Location = new System.Drawing.Point(0, 0);
            this.ThanhPhanLoaiPhongO.Name = "ThanhPhanLoaiPhongO";
            this.ThanhPhanLoaiPhongO.Options.ShowCloseButton = false;
            this.ThanhPhanLoaiPhongO.OriginalSize = new System.Drawing.Size(310, 200);
            this.ThanhPhanLoaiPhongO.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.ThanhPhanLoaiPhongO.SavedIndex = 0;
            this.ThanhPhanLoaiPhongO.Size = new System.Drawing.Size(310, 706);
            this.ThanhPhanLoaiPhongO.Text = "THANH PHÒNG Ở";
            this.ThanhPhanLoaiPhongO.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            // 
            // ControlContainer1
            // 
            this.ControlContainer1.Controls.Add(this.DangCoSan_SE);
            this.ControlContainer1.Controls.Add(this.DangNgung_SE);
            this.ControlContainer1.Controls.Add(this.LabelControl13);
            this.ControlContainer1.Controls.Add(this.DaDuocDat_SE);
            this.ControlContainer1.Controls.Add(this.DaCoNguoi_SE);
            this.ControlContainer1.Controls.Add(this.TongPhong_SE);
            this.ControlContainer1.Controls.Add(this.LabelControl12);
            this.ControlContainer1.Controls.Add(this.LabelControl11);
            this.ControlContainer1.Controls.Add(this.LabelControl10);
            this.ControlContainer1.Controls.Add(this.LabelControl9);
            this.ControlContainer1.Controls.Add(this.LabelControl8);
            this.ControlContainer1.Controls.Add(this.LabelControl7);
            this.ControlContainer1.Controls.Add(this.TrangThai_RG);
            this.ControlContainer1.Location = new System.Drawing.Point(0, 33);
            this.ControlContainer1.Name = "ControlContainer1";
            this.ControlContainer1.Size = new System.Drawing.Size(309, 673);
            this.ControlContainer1.TabIndex = 0;
            // 
            // DangCoSan_SE
            // 
            this.DangCoSan_SE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DangCoSan_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.DangCoSan_SE.Enabled = false;
            this.DangCoSan_SE.Location = new System.Drawing.Point(200, 398);
            this.DangCoSan_SE.MenuManager = this.BarManager;
            this.DangCoSan_SE.Name = "DangCoSan_SE";
            this.DangCoSan_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.DangCoSan_SE.Properties.Appearance.Options.UseFont = true;
            this.DangCoSan_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.DangCoSan_SE.Properties.IsFloatValue = false;
            this.DangCoSan_SE.Properties.MaskSettings.Set("mask", "N00");
            this.DangCoSan_SE.Size = new System.Drawing.Size(100, 36);
            this.DangCoSan_SE.TabIndex = 20;
            // 
            // DangNgung_SE
            // 
            this.DangNgung_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.DangNgung_SE.Enabled = false;
            this.DangNgung_SE.Location = new System.Drawing.Point(200, 561);
            this.DangNgung_SE.MenuManager = this.BarManager;
            this.DangNgung_SE.Name = "DangNgung_SE";
            this.DangNgung_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.DangNgung_SE.Properties.Appearance.Options.UseFont = true;
            this.DangNgung_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.DangNgung_SE.Properties.IsFloatValue = false;
            this.DangNgung_SE.Properties.MaskSettings.Set("mask", "N00");
            this.DangNgung_SE.Size = new System.Drawing.Size(100, 36);
            this.DangNgung_SE.TabIndex = 17;
            // 
            // LabelControl13
            // 
            this.LabelControl13.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl13.Appearance.Options.UseFont = true;
            this.LabelControl13.Location = new System.Drawing.Point(50, 401);
            this.LabelControl13.Name = "LabelControl13";
            this.LabelControl13.Size = new System.Drawing.Size(123, 30);
            this.LabelControl13.TabIndex = 21;
            this.LabelControl13.Text = "Đang có sẵn:";
            // 
            // DaDuocDat_SE
            // 
            this.DaDuocDat_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.DaDuocDat_SE.Enabled = false;
            this.DaDuocDat_SE.Location = new System.Drawing.Point(200, 508);
            this.DaDuocDat_SE.MenuManager = this.BarManager;
            this.DaDuocDat_SE.Name = "DaDuocDat_SE";
            this.DaDuocDat_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.DaDuocDat_SE.Properties.Appearance.Options.UseFont = true;
            this.DaDuocDat_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.DaDuocDat_SE.Properties.IsFloatValue = false;
            this.DaDuocDat_SE.Properties.MaskSettings.Set("mask", "N00");
            this.DaDuocDat_SE.Size = new System.Drawing.Size(100, 36);
            this.DaDuocDat_SE.TabIndex = 20;
            // 
            // DaCoNguoi_SE
            // 
            this.DaCoNguoi_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.DaCoNguoi_SE.Enabled = false;
            this.DaCoNguoi_SE.Location = new System.Drawing.Point(200, 453);
            this.DaCoNguoi_SE.MenuManager = this.BarManager;
            this.DaCoNguoi_SE.Name = "DaCoNguoi_SE";
            this.DaCoNguoi_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.DaCoNguoi_SE.Properties.Appearance.Options.UseFont = true;
            this.DaCoNguoi_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.DaCoNguoi_SE.Properties.IsFloatValue = false;
            this.DaCoNguoi_SE.Properties.MaskSettings.Set("mask", "N00");
            this.DaCoNguoi_SE.Size = new System.Drawing.Size(100, 36);
            this.DaCoNguoi_SE.TabIndex = 17;
            // 
            // TongPhong_SE
            // 
            this.TongPhong_SE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TongPhong_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.TongPhong_SE.Enabled = false;
            this.TongPhong_SE.Location = new System.Drawing.Point(200, 344);
            this.TongPhong_SE.MenuManager = this.BarManager;
            this.TongPhong_SE.Name = "TongPhong_SE";
            this.TongPhong_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TongPhong_SE.Properties.Appearance.Options.UseFont = true;
            this.TongPhong_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TongPhong_SE.Properties.IsFloatValue = false;
            this.TongPhong_SE.Properties.MaskSettings.Set("mask", "N00");
            this.TongPhong_SE.Size = new System.Drawing.Size(100, 36);
            this.TongPhong_SE.TabIndex = 6;
            // 
            // LabelControl12
            // 
            this.LabelControl12.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl12.Appearance.Options.UseFont = true;
            this.LabelControl12.Location = new System.Drawing.Point(50, 564);
            this.LabelControl12.Name = "LabelControl12";
            this.LabelControl12.Size = new System.Drawing.Size(125, 30);
            this.LabelControl12.TabIndex = 19;
            this.LabelControl12.Text = "Đang ngưng:";
            // 
            // LabelControl11
            // 
            this.LabelControl11.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl11.Appearance.Options.UseFont = true;
            this.LabelControl11.Location = new System.Drawing.Point(50, 511);
            this.LabelControl11.Name = "LabelControl11";
            this.LabelControl11.Size = new System.Drawing.Size(123, 30);
            this.LabelControl11.TabIndex = 18;
            this.LabelControl11.Text = "Đã được đặt:";
            // 
            // LabelControl10
            // 
            this.LabelControl10.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl10.Appearance.Options.UseFont = true;
            this.LabelControl10.Location = new System.Drawing.Point(50, 456);
            this.LabelControl10.Name = "LabelControl10";
            this.LabelControl10.Size = new System.Drawing.Size(122, 30);
            this.LabelControl10.TabIndex = 19;
            this.LabelControl10.Text = "Đã có người:";
            // 
            // LabelControl9
            // 
            this.LabelControl9.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl9.Appearance.Options.UseFont = true;
            this.LabelControl9.Location = new System.Drawing.Point(50, 347);
            this.LabelControl9.Name = "LabelControl9";
            this.LabelControl9.Size = new System.Drawing.Size(62, 30);
            this.LabelControl9.TabIndex = 17;
            this.LabelControl9.Text = "Tất cả:";
            // 
            // LabelControl8
            // 
            this.LabelControl8.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl8.Appearance.Options.UseFont = true;
            this.LabelControl8.Location = new System.Drawing.Point(10, 295);
            this.LabelControl8.Name = "LabelControl8";
            this.LabelControl8.Size = new System.Drawing.Size(93, 30);
            this.LabelControl8.TabIndex = 6;
            this.LabelControl8.Text = "Thông Số";
            // 
            // LabelControl7
            // 
            this.LabelControl7.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl7.Appearance.Options.UseFont = true;
            this.LabelControl7.Location = new System.Drawing.Point(10, 10);
            this.LabelControl7.Name = "LabelControl7";
            this.LabelControl7.Size = new System.Drawing.Size(101, 30);
            this.LabelControl7.TabIndex = 6;
            this.LabelControl7.Text = "Tình Trạng";
            // 
            // TrangThai_RG
            // 
            this.TrangThai_RG.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TrangThai_RG.Location = new System.Drawing.Point(10, 50);
            this.TrangThai_RG.Name = "TrangThai_RG";
            this.TrangThai_RG.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrangThai_RG.Properties.Appearance.Options.UseFont = true;
            this.TrangThai_RG.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.TrangThai_RG.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "ALL"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("AVAILABLE", "Đang Có Sẵn"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("OCCUPIED", "Đã Có Người"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("RESERVED", "Đã Được Đặt"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("SUSPENDED", "Đang Ngưng")});
            this.TrangThai_RG.Size = new System.Drawing.Size(290, 225);
            this.TrangThai_RG.TabIndex = 18;
            this.TrangThai_RG.SelectedIndexChanged += new System.EventHandler(this.TrangThaiPO_EditValueChanged);
            // 
            // ThanhPhanLoaiSuKien
            // 
            this.ThanhPhanLoaiSuKien.Controls.Add(this.DockPanel1_Container);
            this.ThanhPhanLoaiSuKien.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.ThanhPhanLoaiSuKien.FloatSize = new System.Drawing.Size(310, 722);
            this.ThanhPhanLoaiSuKien.ID = new System.Guid("99d789a7-ac0c-43ca-a767-22720e1c3bef");
            this.ThanhPhanLoaiSuKien.Location = new System.Drawing.Point(0, 0);
            this.ThanhPhanLoaiSuKien.Name = "ThanhPhanLoaiSuKien";
            this.ThanhPhanLoaiSuKien.Options.ShowCloseButton = false;
            this.ThanhPhanLoaiSuKien.OriginalSize = new System.Drawing.Size(310, 200);
            this.ThanhPhanLoaiSuKien.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.ThanhPhanLoaiSuKien.SavedIndex = 0;
            this.ThanhPhanLoaiSuKien.Size = new System.Drawing.Size(310, 706);
            this.ThanhPhanLoaiSuKien.Text = "THANH SỰ KIỆN";
            this.ThanhPhanLoaiSuKien.Visibility = DevExpress.XtraBars.Docking.DockVisibility.AutoHide;
            // 
            // DockPanel1_Container
            // 
            this.DockPanel1_Container.Controls.Add(this.DatPhongSearch);
            this.DockPanel1_Container.Controls.Add(this.PhongNghi_SLUE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl6);
            this.DockPanel1_Container.Controls.Add(this.LabelControl5);
            this.DockPanel1_Container.Controls.Add(this.KhachHang_SLUE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl4);
            this.DockPanel1_Container.Controls.Add(this.TrangThai_SLUE);
            this.DockPanel1_Container.Controls.Add(this.TimeLine_CBB);
            this.DockPanel1_Container.Controls.Add(this.LoaiHinh_SLUE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl1);
            this.DockPanel1_Container.Controls.Add(this.LabelControl3);
            this.DockPanel1_Container.Controls.Add(this.LabelControl2);
            this.DockPanel1_Container.Location = new System.Drawing.Point(0, 33);
            this.DockPanel1_Container.Name = "DockPanel1_Container";
            this.DockPanel1_Container.Size = new System.Drawing.Size(309, 673);
            this.DockPanel1_Container.TabIndex = 0;
            // 
            // DatPhongSearch
            // 
            this.DatPhongSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.DatPhongSearch.EditValue = "";
            this.DatPhongSearch.Location = new System.Drawing.Point(10, 512);
            this.DatPhongSearch.MenuManager = this.BarManager;
            this.DatPhongSearch.Name = "DatPhongSearch";
            this.DatPhongSearch.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.DatPhongSearch.Properties.Appearance.Options.UseFont = true;
            this.DatPhongSearch.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Repository.ClearButton(),
            new DevExpress.XtraEditors.Repository.SearchButton()});
            this.DatPhongSearch.Size = new System.Drawing.Size(290, 36);
            this.DatPhongSearch.TabIndex = 23;
            this.DatPhongSearch.TextChanged += new System.EventHandler(this.DatPhongSearch_TextChanged);
            // 
            // PhongNghi_SLUE
            // 
            this.PhongNghi_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PhongNghi_SLUE.Location = new System.Drawing.Point(10, 227);
            this.PhongNghi_SLUE.MenuManager = this.BarManager;
            this.PhongNghi_SLUE.Name = "PhongNghi_SLUE";
            this.PhongNghi_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.PhongNghi_SLUE.Properties.Appearance.Options.UseFont = true;
            this.PhongNghi_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.PhongNghi_SLUE.Properties.DisplayMember = "TENPHONG";
            this.PhongNghi_SLUE.Properties.NullText = "ALL";
            this.PhongNghi_SLUE.Properties.PopupView = this.GridView3;
            this.PhongNghi_SLUE.Properties.ValueMember = "MAPHONG";
            this.PhongNghi_SLUE.Size = new System.Drawing.Size(290, 36);
            this.PhongNghi_SLUE.TabIndex = 32;
            this.PhongNghi_SLUE.EditValueChanged += new System.EventHandler(this.PhongNghi_EditValueChanged);
            // 
            // GridView3
            // 
            this.GridView3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView3.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView3.Appearance.Row.Options.UseFont = true;
            this.GridView3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn4,
            this.GridColumn6,
            this.GridColumn9});
            this.GridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView3.Name = "GridView3";
            this.GridView3.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView3.OptionsView.ShowGroupPanel = false;
            this.GridView3.OptionsView.ShowIndicator = false;
            this.GridView3.RowHeight = 40;
            // 
            // GridColumn4
            // 
            this.GridColumn4.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn4.AppearanceHeader.Options.UseFont = true;
            this.GridColumn4.Caption = "TÊN PHÒNG";
            this.GridColumn4.FieldName = "TENPHONG";
            this.GridColumn4.Name = "GridColumn4";
            this.GridColumn4.Visible = true;
            this.GridColumn4.VisibleIndex = 0;
            // 
            // GridColumn6
            // 
            this.GridColumn6.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn6.AppearanceHeader.Options.UseFont = true;
            this.GridColumn6.Caption = "TẦNG THỨ";
            this.GridColumn6.FieldName = "TANGTHU";
            this.GridColumn6.Name = "GridColumn6";
            this.GridColumn6.Visible = true;
            this.GridColumn6.VisibleIndex = 1;
            // 
            // GridColumn9
            // 
            this.GridColumn9.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn9.AppearanceHeader.Options.UseFont = true;
            this.GridColumn9.Caption = "TÊN LOẠI PHÒNG";
            this.GridColumn9.FieldName = "TENLOAIPHONG";
            this.GridColumn9.Name = "GridColumn9";
            this.GridColumn9.Visible = true;
            this.GridColumn9.VisibleIndex = 2;
            // 
            // LabelControl6
            // 
            this.LabelControl6.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl6.Appearance.Options.UseFont = true;
            this.LabelControl6.Location = new System.Drawing.Point(10, 476);
            this.LabelControl6.Name = "LabelControl6";
            this.LabelControl6.Size = new System.Drawing.Size(91, 30);
            this.LabelControl6.TabIndex = 24;
            this.LabelControl6.Text = "Tìm Kiếm";
            // 
            // LabelControl5
            // 
            this.LabelControl5.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl5.Appearance.Options.UseFont = true;
            this.LabelControl5.Location = new System.Drawing.Point(10, 191);
            this.LabelControl5.Name = "LabelControl5";
            this.LabelControl5.Size = new System.Drawing.Size(114, 30);
            this.LabelControl5.TabIndex = 33;
            this.LabelControl5.Text = "Phòng Nghỉ";
            // 
            // KhachHang_SLUE
            // 
            this.KhachHang_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.KhachHang_SLUE.Location = new System.Drawing.Point(10, 131);
            this.KhachHang_SLUE.MenuManager = this.BarManager;
            this.KhachHang_SLUE.Name = "KhachHang_SLUE";
            this.KhachHang_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.KhachHang_SLUE.Properties.Appearance.Options.UseFont = true;
            this.KhachHang_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.KhachHang_SLUE.Properties.DisplayMember = "HOVATEN";
            this.KhachHang_SLUE.Properties.NullText = "ALL";
            this.KhachHang_SLUE.Properties.PopupView = this.GridView1;
            this.KhachHang_SLUE.Properties.ValueMember = "IDKHACH";
            this.KhachHang_SLUE.Size = new System.Drawing.Size(290, 36);
            this.KhachHang_SLUE.TabIndex = 30;
            this.KhachHang_SLUE.EditValueChanged += new System.EventHandler(this.KhachHang_EditValueChanged);
            // 
            // GridView1
            // 
            this.GridView1.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView1.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView1.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView1.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView1.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView1.Appearance.Row.Options.UseFont = true;
            this.GridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn1,
            this.GridColumn2});
            this.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView1.Name = "GridView1";
            this.GridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView1.OptionsView.ShowGroupPanel = false;
            this.GridView1.OptionsView.ShowIndicator = false;
            this.GridView1.RowHeight = 40;
            // 
            // GridColumn1
            // 
            this.GridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn1.AppearanceHeader.Options.UseFont = true;
            this.GridColumn1.Caption = "ID KHÁCH";
            this.GridColumn1.FieldName = "IDKHACH";
            this.GridColumn1.Name = "GridColumn1";
            this.GridColumn1.Visible = true;
            this.GridColumn1.VisibleIndex = 0;
            // 
            // GridColumn2
            // 
            this.GridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn2.AppearanceHeader.Options.UseFont = true;
            this.GridColumn2.Caption = "HỌ VÀ TÊN";
            this.GridColumn2.FieldName = "HOVATEN";
            this.GridColumn2.Name = "GridColumn2";
            this.GridColumn2.Visible = true;
            this.GridColumn2.VisibleIndex = 1;
            // 
            // LabelControl4
            // 
            this.LabelControl4.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl4.Appearance.Options.UseFont = true;
            this.LabelControl4.Location = new System.Drawing.Point(10, 95);
            this.LabelControl4.Name = "LabelControl4";
            this.LabelControl4.Size = new System.Drawing.Size(116, 30);
            this.LabelControl4.TabIndex = 31;
            this.LabelControl4.Text = "Khách Hàng";
            // 
            // TrangThai_SLUE
            // 
            this.TrangThai_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TrangThai_SLUE.Location = new System.Drawing.Point(10, 423);
            this.TrangThai_SLUE.MenuManager = this.BarManager;
            this.TrangThai_SLUE.Name = "TrangThai_SLUE";
            this.TrangThai_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TrangThai_SLUE.Properties.Appearance.Options.UseFont = true;
            this.TrangThai_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TrangThai_SLUE.Properties.DisplayMember = "TENTRANGTHAI";
            this.TrangThai_SLUE.Properties.NullText = "ALL";
            this.TrangThai_SLUE.Properties.PopupView = this.GridView4;
            this.TrangThai_SLUE.Properties.ValueMember = "MATRANGTHAI";
            this.TrangThai_SLUE.Size = new System.Drawing.Size(290, 36);
            this.TrangThai_SLUE.TabIndex = 24;
            this.TrangThai_SLUE.EditValueChanged += new System.EventHandler(this.TrangThaiPD_EditValueChanged);
            // 
            // GridView4
            // 
            this.GridView4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView4.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView4.Appearance.Row.Options.UseFont = true;
            this.GridView4.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn8,
            this.GridColumn7});
            this.GridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView4.Name = "GridView4";
            this.GridView4.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView4.OptionsView.ShowGroupPanel = false;
            this.GridView4.OptionsView.ShowIndicator = false;
            this.GridView4.RowHeight = 40;
            // 
            // GridColumn8
            // 
            this.GridColumn8.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn8.AppearanceHeader.Options.UseFont = true;
            this.GridColumn8.Caption = "TÊN TRẠNG THÁI";
            this.GridColumn8.FieldName = "TENTRANGTHAI";
            this.GridColumn8.Name = "GridColumn8";
            this.GridColumn8.Visible = true;
            this.GridColumn8.VisibleIndex = 0;
            // 
            // GridColumn7
            // 
            this.GridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn7.AppearanceHeader.Options.UseFont = true;
            this.GridColumn7.Caption = "MÔ TẢ";
            this.GridColumn7.FieldName = "MOTA";
            this.GridColumn7.Name = "GridColumn7";
            this.GridColumn7.Visible = true;
            this.GridColumn7.VisibleIndex = 1;
            // 
            // TimeLine_CBB
            // 
            this.TimeLine_CBB.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TimeLine_CBB.EditValue = "Today";
            this.TimeLine_CBB.Location = new System.Drawing.Point(10, 40);
            this.TimeLine_CBB.MenuManager = this.BarManager;
            this.TimeLine_CBB.Name = "TimeLine_CBB";
            this.TimeLine_CBB.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TimeLine_CBB.Properties.Appearance.Options.UseFont = true;
            this.TimeLine_CBB.Properties.AppearanceDropDown.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TimeLine_CBB.Properties.AppearanceDropDown.Options.UseFont = true;
            this.TimeLine_CBB.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TimeLine_CBB.Properties.Items.AddRange(new object[] {
            "Today",
            "One Week",
            "One Month",
            "One Year",
            "All Time"});
            this.TimeLine_CBB.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.TimeLine_CBB.Size = new System.Drawing.Size(290, 36);
            this.TimeLine_CBB.TabIndex = 28;
            this.TimeLine_CBB.SelectedValueChanged += new System.EventHandler(this.TimeLine_EditValueChanged);
            // 
            // LoaiHinh_SLUE
            // 
            this.LoaiHinh_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LoaiHinh_SLUE.Location = new System.Drawing.Point(10, 327);
            this.LoaiHinh_SLUE.MenuManager = this.BarManager;
            this.LoaiHinh_SLUE.Name = "LoaiHinh_SLUE";
            this.LoaiHinh_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LoaiHinh_SLUE.Properties.Appearance.Options.UseFont = true;
            this.LoaiHinh_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LoaiHinh_SLUE.Properties.DisplayMember = "TENLOAIHINH";
            this.LoaiHinh_SLUE.Properties.NullText = "ALL";
            this.LoaiHinh_SLUE.Properties.PopupView = this.GridView2;
            this.LoaiHinh_SLUE.Properties.ValueMember = "MALOAIHINH";
            this.LoaiHinh_SLUE.Size = new System.Drawing.Size(290, 36);
            this.LoaiHinh_SLUE.TabIndex = 25;
            this.LoaiHinh_SLUE.EditValueChanged += new System.EventHandler(this.LoaiHinh_EditValueChanged);
            // 
            // GridView2
            // 
            this.GridView2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView2.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView2.Appearance.Row.Options.UseFont = true;
            this.GridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn3,
            this.GridColumn5});
            this.GridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView2.Name = "GridView2";
            this.GridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView2.OptionsView.ShowGroupPanel = false;
            this.GridView2.OptionsView.ShowIndicator = false;
            this.GridView2.RowHeight = 40;
            // 
            // GridColumn3
            // 
            this.GridColumn3.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn3.AppearanceHeader.Options.UseFont = true;
            this.GridColumn3.Caption = "TÊN LOẠI HÌNH";
            this.GridColumn3.FieldName = "TENLOAIHINH";
            this.GridColumn3.Name = "GridColumn3";
            this.GridColumn3.Visible = true;
            this.GridColumn3.VisibleIndex = 0;
            // 
            // GridColumn5
            // 
            this.GridColumn5.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn5.AppearanceHeader.Options.UseFont = true;
            this.GridColumn5.Caption = "MÔ TẢ";
            this.GridColumn5.FieldName = "MOTA";
            this.GridColumn5.Name = "GridColumn5";
            this.GridColumn5.Visible = true;
            this.GridColumn5.VisibleIndex = 1;
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(10, 4);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(82, 30);
            this.LabelControl1.TabIndex = 29;
            this.LabelControl1.Text = "Timeline";
            // 
            // LabelControl3
            // 
            this.LabelControl3.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl3.Appearance.Options.UseFont = true;
            this.LabelControl3.Location = new System.Drawing.Point(10, 387);
            this.LabelControl3.Name = "LabelControl3";
            this.LabelControl3.Size = new System.Drawing.Size(100, 30);
            this.LabelControl3.TabIndex = 27;
            this.LabelControl3.Text = "Trạng Thái";
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Location = new System.Drawing.Point(10, 291);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(100, 30);
            this.LabelControl2.TabIndex = 26;
            this.LabelControl2.Text = "Hạng Mục";
            // 
            // HuyPhongPopup
            // 
            this.HuyPhongPopup.Caption = "HỦY PHÒNG";
            this.HuyPhongPopup.Id = 8;
            this.HuyPhongPopup.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("HuyPhongPopup.ImageOptions.SvgImage")));
            this.HuyPhongPopup.Name = "HuyPhongPopup";
            this.HuyPhongPopup.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutHuyPhong_ItemClick);
            // 
            // DatPhongHienTai
            // 
            this.DatPhongHienTai.Caption = "ĐẶT PHÒNG HIỆN TẠI";
            this.DatPhongHienTai.Id = 9;
            this.DatPhongHienTai.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("DatPhongHienTai.ImageOptions.SvgImage")));
            this.DatPhongHienTai.Name = "DatPhongHienTai";
            this.DatPhongHienTai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.DatPhongHienTai_ItemClick);
            // 
            // NhatKyDatPhong
            // 
            this.NhatKyDatPhong.Caption = "NHẬT KÝ ĐẶT PHÒNG";
            this.NhatKyDatPhong.Id = 10;
            this.NhatKyDatPhong.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NhatKyDatPhong.ImageOptions.SvgImage")));
            this.NhatKyDatPhong.Name = "NhatKyDatPhong";
            this.NhatKyDatPhong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NhatKyDatPhong_ItemClick);
            // 
            // LayPhongHienTai
            // 
            this.LayPhongHienTai.Caption = "LẤY PHÒNG HIỆN TẠI";
            this.LayPhongHienTai.Id = 11;
            this.LayPhongHienTai.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("LayPhongHienTai.ImageOptions.SvgImage")));
            this.LayPhongHienTai.Name = "LayPhongHienTai";
            this.LayPhongHienTai.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.LayPhongHienTai_ItemClick);
            // 
            // BangSuKien
            // 
            this.BangSuKien.AllowUserToAddRows = false;
            this.BangSuKien.AllowUserToDeleteRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            this.BangSuKien.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.BangSuKien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BangSuKien.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangSuKien.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BangSuKien.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangSuKien.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BangSuKien.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.BangSuKien.ColumnHeadersHeight = 40;
            this.BangSuKien.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MAPHONGDAT,
            this.IDKHACH,
            this.HOVATEN,
            this.MAPHONG,
            this.TENPHONG,
            this.NGAYDAT,
            this.NGAYLAY,
            this.NGAYTRA,
            this.GIAPHONG,
            this.MALOAIHINH,
            this.TENLOAIHINH,
            this.MATRANGTHAI,
            this.TENTRANGTHAI,
            this.GHICHU,
            this.THOIHAN});
            this.BangSuKien.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(41)))), ((int)(((byte)(62)))));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BangSuKien.DefaultCellStyle = dataGridViewCellStyle16;
            this.BangSuKien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BangSuKien.EnableHeadersVisualStyles = false;
            this.BangSuKien.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangSuKien.Location = new System.Drawing.Point(0, 0);
            this.BangSuKien.Margin = new System.Windows.Forms.Padding(2150, 2040, 2150, 2040);
            this.BangSuKien.MultiSelect = false;
            this.BangSuKien.Name = "BangSuKien";
            this.BangSuKien.ReadOnly = true;
            this.BangSuKien.RowHeadersVisible = false;
            this.BangSuKien.RowHeadersWidth = 51;
            this.BangSuKien.RowTemplate.Height = 40;
            this.BangSuKien.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.BangSuKien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BangSuKien.Size = new System.Drawing.Size(1851, 648);
            this.BangSuKien.TabIndex = 5;
            this.BangSuKien.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.LightGrid;
            this.BangSuKien.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.BangSuKien.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.BangSuKien.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.BangSuKien.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.BangSuKien.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.BangSuKien.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangSuKien.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangSuKien.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.BangSuKien.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.BangSuKien.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangSuKien.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.BangSuKien.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.BangSuKien.ThemeStyle.HeaderStyle.Height = 40;
            this.BangSuKien.ThemeStyle.ReadOnly = true;
            this.BangSuKien.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.BangSuKien.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangSuKien.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangSuKien.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(41)))), ((int)(((byte)(62)))));
            this.BangSuKien.ThemeStyle.RowsStyle.Height = 40;
            this.BangSuKien.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.BangSuKien.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.BangSuKien.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.BangSuKien_ColumnHeaderMouseClick);
            this.BangSuKien.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BangSuKien_MouseClick);
            // 
            // MAPHONGDAT
            // 
            this.MAPHONGDAT.DataPropertyName = "MAPHONGDAT";
            this.MAPHONGDAT.HeaderText = "MÃ ĐẶT";
            this.MAPHONGDAT.MinimumWidth = 6;
            this.MAPHONGDAT.Name = "MAPHONGDAT";
            this.MAPHONGDAT.ReadOnly = true;
            this.MAPHONGDAT.Visible = false;
            // 
            // IDKHACH
            // 
            this.IDKHACH.DataPropertyName = "IDKHACH";
            this.IDKHACH.HeaderText = "ID KHÁCH";
            this.IDKHACH.MinimumWidth = 6;
            this.IDKHACH.Name = "IDKHACH";
            this.IDKHACH.ReadOnly = true;
            // 
            // HOVATEN
            // 
            this.HOVATEN.DataPropertyName = "HOVATEN";
            this.HOVATEN.HeaderText = "HỌ TÊN";
            this.HOVATEN.MinimumWidth = 6;
            this.HOVATEN.Name = "HOVATEN";
            this.HOVATEN.ReadOnly = true;
            // 
            // MAPHONG
            // 
            this.MAPHONG.DataPropertyName = "MAPHONG";
            this.MAPHONG.HeaderText = "MÃ PHÒNG";
            this.MAPHONG.MinimumWidth = 6;
            this.MAPHONG.Name = "MAPHONG";
            this.MAPHONG.ReadOnly = true;
            this.MAPHONG.Visible = false;
            // 
            // TENPHONG
            // 
            this.TENPHONG.DataPropertyName = "TENPHONG";
            this.TENPHONG.HeaderText = "TÊN PHÒNG";
            this.TENPHONG.MinimumWidth = 6;
            this.TENPHONG.Name = "TENPHONG";
            this.TENPHONG.ReadOnly = true;
            // 
            // NGAYDAT
            // 
            this.NGAYDAT.DataPropertyName = "NGAYDAT";
            dataGridViewCellStyle11.Format = "g";
            dataGridViewCellStyle11.NullValue = null;
            this.NGAYDAT.DefaultCellStyle = dataGridViewCellStyle11;
            this.NGAYDAT.HeaderText = "NGÀY ĐẶT";
            this.NGAYDAT.MinimumWidth = 6;
            this.NGAYDAT.Name = "NGAYDAT";
            this.NGAYDAT.ReadOnly = true;
            this.NGAYDAT.Visible = false;
            // 
            // NGAYLAY
            // 
            this.NGAYLAY.DataPropertyName = "NGAYLAY";
            dataGridViewCellStyle12.Format = "g";
            dataGridViewCellStyle12.NullValue = null;
            this.NGAYLAY.DefaultCellStyle = dataGridViewCellStyle12;
            this.NGAYLAY.HeaderText = "NGÀY LẤY";
            this.NGAYLAY.MinimumWidth = 6;
            this.NGAYLAY.Name = "NGAYLAY";
            this.NGAYLAY.ReadOnly = true;
            // 
            // NGAYTRA
            // 
            this.NGAYTRA.DataPropertyName = "NGAYTRA";
            dataGridViewCellStyle13.Format = "g";
            dataGridViewCellStyle13.NullValue = null;
            this.NGAYTRA.DefaultCellStyle = dataGridViewCellStyle13;
            this.NGAYTRA.HeaderText = "NGÀY TRẢ";
            this.NGAYTRA.MinimumWidth = 6;
            this.NGAYTRA.Name = "NGAYTRA";
            this.NGAYTRA.ReadOnly = true;
            // 
            // GIAPHONG
            // 
            this.GIAPHONG.DataPropertyName = "GIAPHONG";
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle14.Format = "N0";
            dataGridViewCellStyle14.NullValue = null;
            this.GIAPHONG.DefaultCellStyle = dataGridViewCellStyle14;
            this.GIAPHONG.HeaderText = "GIÁ PHÒNG";
            this.GIAPHONG.MinimumWidth = 6;
            this.GIAPHONG.Name = "GIAPHONG";
            this.GIAPHONG.ReadOnly = true;
            // 
            // MALOAIHINH
            // 
            this.MALOAIHINH.DataPropertyName = "MALOAIHINH";
            this.MALOAIHINH.HeaderText = "MÃ LOẠI HÌNH";
            this.MALOAIHINH.MinimumWidth = 6;
            this.MALOAIHINH.Name = "MALOAIHINH";
            this.MALOAIHINH.ReadOnly = true;
            this.MALOAIHINH.Visible = false;
            // 
            // TENLOAIHINH
            // 
            this.TENLOAIHINH.DataPropertyName = "TENLOAIHINH";
            this.TENLOAIHINH.HeaderText = "LOẠI HÌNH";
            this.TENLOAIHINH.MinimumWidth = 6;
            this.TENLOAIHINH.Name = "TENLOAIHINH";
            this.TENLOAIHINH.ReadOnly = true;
            this.TENLOAIHINH.Visible = false;
            // 
            // MATRANGTHAI
            // 
            this.MATRANGTHAI.DataPropertyName = "MATRANGTHAI";
            this.MATRANGTHAI.HeaderText = "MÃ TRẠNG THÁI";
            this.MATRANGTHAI.MinimumWidth = 6;
            this.MATRANGTHAI.Name = "MATRANGTHAI";
            this.MATRANGTHAI.ReadOnly = true;
            this.MATRANGTHAI.Visible = false;
            // 
            // TENTRANGTHAI
            // 
            this.TENTRANGTHAI.DataPropertyName = "TENTRANGTHAI";
            this.TENTRANGTHAI.HeaderText = "TRẠNG THÁI";
            this.TENTRANGTHAI.MinimumWidth = 6;
            this.TENTRANGTHAI.Name = "TENTRANGTHAI";
            this.TENTRANGTHAI.ReadOnly = true;
            // 
            // GHICHU
            // 
            this.GHICHU.DataPropertyName = "GHICHU";
            this.GHICHU.HeaderText = "GHI CHÚ";
            this.GHICHU.MinimumWidth = 6;
            this.GHICHU.Name = "GHICHU";
            this.GHICHU.ReadOnly = true;
            // 
            // THOIHAN
            // 
            this.THOIHAN.DataPropertyName = "THOIHAN";
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle15.Format = "N2";
            dataGridViewCellStyle15.NullValue = null;
            this.THOIHAN.DefaultCellStyle = dataGridViewCellStyle15;
            this.THOIHAN.HeaderText = "THỜI HẠN";
            this.THOIHAN.MinimumWidth = 6;
            this.THOIHAN.Name = "THOIHAN";
            this.THOIHAN.ReadOnly = true;
            this.THOIHAN.Visible = false;
            // 
            // PhanTrang
            // 
            this.PhanTrang.Cursor = System.Windows.Forms.Cursors.Default;
            this.PhanTrang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PhanTrang.Location = new System.Drawing.Point(30, 35);
            this.PhanTrang.Margin = new System.Windows.Forms.Padding(185);
            this.PhanTrang.Name = "PhanTrang";
            this.PhanTrang.SelectedTabPage = this.TabSuKien;
            this.PhanTrang.Size = new System.Drawing.Size(1853, 706);
            this.PhanTrang.TabIndex = 11;
            this.PhanTrang.TabPages.AddRange(new DevExpress.XtraTab.XtraTabPage[] {
            this.TabSuKien,
            this.TabPhongO});
            this.PhanTrang.SelectedPageChanged += new DevExpress.XtraTab.TabPageChangedEventHandler(this.SelectedPageChanged);
            // 
            // TabSuKien
            // 
            this.TabSuKien.Appearance.HeaderActive.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.TabSuKien.Appearance.HeaderActive.Options.UseFont = true;
            this.TabSuKien.Controls.Add(this.BangSuKien);
            this.TabSuKien.Cursor = System.Windows.Forms.Cursors.Default;
            this.TabSuKien.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("TabSuKien.ImageOptions.SvgImage")));
            this.TabSuKien.Margin = new System.Windows.Forms.Padding(185);
            this.TabSuKien.Name = "TabSuKien";
            this.TabSuKien.Size = new System.Drawing.Size(1851, 648);
            this.TabSuKien.Text = "SỰ KIỆN";
            // 
            // TabPhongO
            // 
            this.TabPhongO.Appearance.HeaderActive.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.TabPhongO.Appearance.HeaderActive.Options.UseFont = true;
            this.TabPhongO.Controls.Add(this.PGC);
            this.TabPhongO.Cursor = System.Windows.Forms.Cursors.Default;
            this.TabPhongO.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("TabPhongO.ImageOptions.SvgImage")));
            this.TabPhongO.Margin = new System.Windows.Forms.Padding(185);
            this.TabPhongO.Name = "TabPhongO";
            this.TabPhongO.Size = new System.Drawing.Size(1851, 648);
            this.TabPhongO.Text = "PHÒNG Ở";
            // 
            // PGC
            // 
            this.PGC.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.PGC.Controls.Add(this.GalleryControlClient1);
            this.PGC.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PGC.Dock = System.Windows.Forms.DockStyle.Fill;
            // 
            // 
            // 
            this.PGC.Gallery.Appearance.ItemCaptionAppearance.Hovered.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.PGC.Gallery.Appearance.ItemCaptionAppearance.Hovered.Options.UseFont = true;
            this.PGC.Gallery.Appearance.ItemDescriptionAppearance.Hovered.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.PGC.Gallery.Appearance.ItemDescriptionAppearance.Hovered.Options.UseFont = true;
            this.PGC.Gallery.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.PGC.Gallery.ImageSize = new System.Drawing.Size(160, 160);
            this.PGC.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.ZoomInside;
            this.PGC.Gallery.ItemSize = new System.Drawing.Size(160, 160);
            this.PGC.Gallery.ShowItemText = true;
            this.PGC.Gallery.GalleryItemHover += new DevExpress.XtraBars.Ribbon.GalleryItemEventHandler(this.GalleryItemHover);
            this.PGC.Gallery.GalleryItemLeave += new DevExpress.XtraBars.Ribbon.GalleryItemEventHandler(this.GalleryItemLeave);
            this.PGC.Location = new System.Drawing.Point(0, 0);
            this.PGC.Margin = new System.Windows.Forms.Padding(289);
            this.PGC.Name = "PGC";
            this.PGC.Size = new System.Drawing.Size(1851, 648);
            this.PGC.TabIndex = 2;
            this.PGC.Text = "THƯ VIỆN PHÒNG";
            this.PGC.ToolTipController = this.FloatingNotes;
            this.PGC.MouseClick += new System.Windows.Forms.MouseEventHandler(this.PhongGalleryMouseClick);
            this.PGC.MouseMove += new System.Windows.Forms.MouseEventHandler(this.PhongGalleryMouseMove);
            // 
            // GalleryControlClient1
            // 
            this.GalleryControlClient1.GalleryControl = this.PGC;
            this.GalleryControlClient1.Location = new System.Drawing.Point(1, 1);
            this.GalleryControlClient1.Margin = new System.Windows.Forms.Padding(289);
            this.GalleryControlClient1.Size = new System.Drawing.Size(1828, 646);
            // 
            // FloatingNotes
            // 
            this.FloatingNotes.Appearance.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.FloatingNotes.Appearance.Options.UseFont = true;
            this.FloatingNotes.ToolTipLocation = DevExpress.Utils.ToolTipLocation.BottomLeft;
            // 
            // BangTuyChonSuKien
            // 
            this.BangTuyChonSuKien.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.HuyPhongPopup)});
            this.BangTuyChonSuKien.Manager = this.BarManager;
            this.BangTuyChonSuKien.Name = "BangTuyChonSuKien";
            // 
            // BangTuyChonPhongO
            // 
            this.BangTuyChonPhongO.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.DatPhongHienTai),
            new DevExpress.XtraBars.LinkPersistInfo(this.LayPhongHienTai),
            new DevExpress.XtraBars.LinkPersistInfo(this.NhatKyDatPhong)});
            this.BangTuyChonPhongO.Manager = this.BarManager;
            this.BangTuyChonPhongO.Name = "BangTuyChonPhongO";
            // 
            // Lock
            // 
            this.Lock.Interval = 500;
            this.Lock.Tick += new System.EventHandler(this.DatPhongSearchAfterTyping);
            // 
            // DatPhongForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1883, 741);
            this.Controls.Add(this.PhanTrang);
            this.Controls.Add(this.HideContainerLeft);
            this.Controls.Add(this.BarDockControlLeft);
            this.Controls.Add(this.BarDockControlRight);
            this.Controls.Add(this.BarDockControlBottom);
            this.Controls.Add(this.BarDockControlTop);
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.Name = "DatPhongForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ĐẶT PHÒNG";
            this.Load += new System.EventHandler(this.FormLoad);
            ((System.ComponentModel.ISupportInitialize)(this.BarManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DockManager)).EndInit();
            this.HideContainerLeft.ResumeLayout(false);
            this.ThanhPhanLoaiPhongO.ResumeLayout(false);
            this.ControlContainer1.ResumeLayout(false);
            this.ControlContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DangCoSan_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DangNgung_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DaDuocDat_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DaCoNguoi_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongPhong_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThai_RG.Properties)).EndInit();
            this.ThanhPhanLoaiSuKien.ResumeLayout(false);
            this.DockPanel1_Container.ResumeLayout(false);
            this.DockPanel1_Container.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DatPhongSearch.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PhongNghi_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KhachHang_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThai_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TimeLine_CBB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LoaiHinh_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangSuKien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PhanTrang)).EndInit();
            this.PhanTrang.ResumeLayout(false);
            this.TabSuKien.ResumeLayout(false);
            this.TabPhongO.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PGC)).EndInit();
            this.PGC.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BangTuyChonSuKien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangTuyChonPhongO)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.BarManager BarManager;
        private DevExpress.XtraBars.Bar Bar1;
        private DevExpress.XtraBars.BarButtonItem NutDatPhong;
        private DevExpress.XtraBars.BarButtonItem NutHuyPhong;
        private DevExpress.XtraBars.BarDockControl BarDockControlTop;
        private DevExpress.XtraBars.BarDockControl BarDockControlBottom;
        private DevExpress.XtraBars.BarDockControl BarDockControlLeft;
        private DevExpress.XtraBars.BarDockControl BarDockControlRight;
        private DevExpress.XtraBars.Docking.DockManager DockManager;
        private DevExpress.XtraBars.Docking.DockPanel ThanhPhanLoaiSuKien;
        private DevExpress.XtraBars.Docking.ControlContainer DockPanel1_Container;
        private Guna.UI2.WinForms.Guna2DataGridView BangSuKien;
        private DevExpress.XtraEditors.ComboBoxEdit TimeLine_CBB;
        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private DevExpress.XtraEditors.SearchLookUpEdit TrangThai_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView4;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn7;
        private DevExpress.XtraEditors.SearchLookUpEdit LoaiHinh_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView2;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn5;
        private DevExpress.XtraEditors.LabelControl LabelControl3;
        private DevExpress.XtraEditors.LabelControl LabelControl2;
        private DevExpress.XtraEditors.SearchLookUpEdit KhachHang_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView1;
        private DevExpress.XtraEditors.LabelControl LabelControl4;
        private DevExpress.XtraEditors.SearchLookUpEdit PhongNghi_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView3;
        private DevExpress.XtraEditors.LabelControl LabelControl5;
        private DevExpress.XtraEditors.SearchControl DatPhongSearch;
        private DevExpress.XtraEditors.LabelControl LabelControl6;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONGDAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDKHACH;
        private System.Windows.Forms.DataGridViewTextBoxColumn HOVATEN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYDAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYLAY;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYTRA;
        private System.Windows.Forms.DataGridViewTextBoxColumn GIAPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn MALOAIHINH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENLOAIHINH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MATRANGTHAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENTRANGTHAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn GHICHU;
        private System.Windows.Forms.DataGridViewTextBoxColumn THOIHAN;
        private DevExpress.XtraTab.XtraTabControl PhanTrang;
        private DevExpress.XtraTab.XtraTabPage TabSuKien;
        private DevExpress.XtraTab.XtraTabPage TabPhongO;
        private DevExpress.XtraBars.Ribbon.GalleryControl PGC;
        private DevExpress.XtraBars.Ribbon.GalleryControlClient GalleryControlClient1;
        private DevExpress.Utils.ToolTipController FloatingNotes;
        private DevExpress.XtraBars.Docking.DockPanel ThanhPhanLoaiPhongO;
        private DevExpress.XtraBars.Docking.ControlContainer ControlContainer1;
        private DevExpress.XtraEditors.RadioGroup TrangThai_RG;
        private DevExpress.XtraBars.Docking.AutoHideContainer HideContainerLeft;
        private DevExpress.XtraEditors.LabelControl LabelControl7;
        private DevExpress.XtraEditors.LabelControl LabelControl8;
        private DevExpress.XtraEditors.LabelControl LabelControl11;
        private DevExpress.XtraEditors.LabelControl LabelControl10;
        private DevExpress.XtraEditors.LabelControl LabelControl9;
        private DevExpress.XtraEditors.LabelControl LabelControl12;
        private DevExpress.XtraEditors.SpinEdit DangNgung_SE;
        private DevExpress.XtraEditors.SpinEdit DaDuocDat_SE;
        private DevExpress.XtraEditors.SpinEdit DaCoNguoi_SE;
        private DevExpress.XtraEditors.SpinEdit TongPhong_SE;
        private DevExpress.XtraEditors.SpinEdit DangCoSan_SE;
        private DevExpress.XtraEditors.LabelControl LabelControl13;
        private DevExpress.XtraBars.PopupMenu BangTuyChonSuKien;
        private DevExpress.XtraBars.BarButtonItem HuyPhongPopup;
        private DevExpress.XtraBars.BarButtonItem DatPhongHienTai;
        private DevExpress.XtraBars.BarButtonItem NhatKyDatPhong;
        private DevExpress.XtraBars.PopupMenu BangTuyChonPhongO;
        private DevExpress.XtraBars.BarButtonItem LayPhongHienTai;
        private System.Windows.Forms.Timer Lock;
    }
}