﻿namespace GUILAYER
{
    partial class ThongTinLoaiPhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinLoaiPhong));
            this.GroupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.MoTa = new DevExpress.XtraEditors.MemoEdit();
            this.LabelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.TienTrongNgay = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.TienNgoaiNgay = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.Giuong = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.SucChua = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.TenLoai = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.MaSoLoai = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.NutOK = new DevExpress.XtraEditors.SimpleButton();
            this.NutHuy = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).BeginInit();
            this.GroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MoTa.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TienTrongNgay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TienNgoaiNgay.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Giuong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SucChua.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TenLoai.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaSoLoai.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // GroupControl1
            // 
            this.GroupControl1.Controls.Add(this.MoTa);
            this.GroupControl1.Controls.Add(this.LabelControl8);
            this.GroupControl1.Controls.Add(this.LabelControl9);
            this.GroupControl1.Controls.Add(this.LabelControl7);
            this.GroupControl1.Controls.Add(this.TienTrongNgay);
            this.GroupControl1.Controls.Add(this.LabelControl4);
            this.GroupControl1.Controls.Add(this.TienNgoaiNgay);
            this.GroupControl1.Controls.Add(this.LabelControl5);
            this.GroupControl1.Controls.Add(this.Giuong);
            this.GroupControl1.Controls.Add(this.LabelControl6);
            this.GroupControl1.Controls.Add(this.SucChua);
            this.GroupControl1.Controls.Add(this.LabelControl3);
            this.GroupControl1.Controls.Add(this.TenLoai);
            this.GroupControl1.Controls.Add(this.LabelControl2);
            this.GroupControl1.Controls.Add(this.MaSoLoai);
            this.GroupControl1.Controls.Add(this.LabelControl1);
            this.GroupControl1.Location = new System.Drawing.Point(12, 12);
            this.GroupControl1.Name = "GroupControl1";
            this.GroupControl1.Size = new System.Drawing.Size(774, 474);
            this.GroupControl1.TabIndex = 0;
            this.GroupControl1.Text = "THÔNG TIN LOẠI PHÒNG";
            // 
            // MoTa
            // 
            this.MoTa.Location = new System.Drawing.Point(15, 344);
            this.MoTa.Name = "MoTa";
            this.MoTa.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MoTa.Properties.Appearance.Options.UseFont = true;
            this.MoTa.Properties.MaxLength = 99;
            this.MoTa.Size = new System.Drawing.Size(744, 116);
            this.MoTa.TabIndex = 17;
            // 
            // LabelControl8
            // 
            this.LabelControl8.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl8.Appearance.Options.UseFont = true;
            this.LabelControl8.Location = new System.Drawing.Point(494, 250);
            this.LabelControl8.Name = "LabelControl8";
            this.LabelControl8.Size = new System.Drawing.Size(45, 30);
            this.LabelControl8.TabIndex = 16;
            this.LabelControl8.Text = "VNĐ";
            // 
            // LabelControl9
            // 
            this.LabelControl9.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl9.Appearance.Options.UseFont = true;
            this.LabelControl9.Location = new System.Drawing.Point(494, 191);
            this.LabelControl9.Name = "LabelControl9";
            this.LabelControl9.Size = new System.Drawing.Size(45, 30);
            this.LabelControl9.TabIndex = 15;
            this.LabelControl9.Text = "VNĐ";
            // 
            // LabelControl7
            // 
            this.LabelControl7.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl7.Appearance.Options.UseFont = true;
            this.LabelControl7.Location = new System.Drawing.Point(15, 308);
            this.LabelControl7.Name = "LabelControl7";
            this.LabelControl7.Size = new System.Drawing.Size(62, 30);
            this.LabelControl7.TabIndex = 13;
            this.LabelControl7.Text = "Mô Tả";
            // 
            // TienTrongNgay
            // 
            this.TienTrongNgay.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TienTrongNgay.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.TienTrongNgay.Location = new System.Drawing.Point(230, 247);
            this.TienTrongNgay.Name = "TienTrongNgay";
            this.TienTrongNgay.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TienTrongNgay.Properties.Appearance.Options.UseFont = true;
            this.TienTrongNgay.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TienTrongNgay.Properties.IsFloatValue = false;
            this.TienTrongNgay.Properties.MaskSettings.Set("mask", "N00");
            this.TienTrongNgay.Size = new System.Drawing.Size(246, 36);
            this.TienTrongNgay.TabIndex = 12;
            // 
            // LabelControl4
            // 
            this.LabelControl4.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl4.Appearance.Options.UseFont = true;
            this.LabelControl4.Location = new System.Drawing.Point(15, 250);
            this.LabelControl4.Name = "LabelControl4";
            this.LabelControl4.Size = new System.Drawing.Size(193, 30);
            this.LabelControl4.TabIndex = 11;
            this.LabelControl4.Text = "Giá Tiền Theo Tiếng";
            // 
            // TienNgoaiNgay
            // 
            this.TienNgoaiNgay.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TienNgoaiNgay.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.TienNgoaiNgay.Location = new System.Drawing.Point(230, 188);
            this.TienNgoaiNgay.Name = "TienNgoaiNgay";
            this.TienNgoaiNgay.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TienNgoaiNgay.Properties.Appearance.Options.UseFont = true;
            this.TienNgoaiNgay.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TienNgoaiNgay.Properties.IsFloatValue = false;
            this.TienNgoaiNgay.Properties.MaskSettings.Set("mask", "N00");
            this.TienNgoaiNgay.Size = new System.Drawing.Size(246, 36);
            this.TienNgoaiNgay.TabIndex = 10;
            // 
            // LabelControl5
            // 
            this.LabelControl5.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl5.Appearance.Options.UseFont = true;
            this.LabelControl5.Location = new System.Drawing.Point(15, 191);
            this.LabelControl5.Name = "LabelControl5";
            this.LabelControl5.Size = new System.Drawing.Size(190, 30);
            this.LabelControl5.TabIndex = 9;
            this.LabelControl5.Text = "Giá Tiền Theo Ngày";
            // 
            // Giuong
            // 
            this.Giuong.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Giuong.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.Giuong.Location = new System.Drawing.Point(513, 110);
            this.Giuong.Name = "Giuong";
            this.Giuong.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.Giuong.Properties.Appearance.Options.UseFont = true;
            this.Giuong.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.Giuong.Properties.IsFloatValue = false;
            this.Giuong.Properties.MaskSettings.Set("mask", "N00");
            this.Giuong.Size = new System.Drawing.Size(246, 36);
            this.Giuong.TabIndex = 8;
            // 
            // LabelControl6
            // 
            this.LabelControl6.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl6.Appearance.Options.UseFont = true;
            this.LabelControl6.Location = new System.Drawing.Point(405, 113);
            this.LabelControl6.Name = "LabelControl6";
            this.LabelControl6.Size = new System.Drawing.Size(71, 30);
            this.LabelControl6.TabIndex = 7;
            this.LabelControl6.Text = "Giường";
            // 
            // SucChua
            // 
            this.SucChua.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SucChua.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SucChua.Location = new System.Drawing.Point(129, 110);
            this.SucChua.Name = "SucChua";
            this.SucChua.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SucChua.Properties.Appearance.Options.UseFont = true;
            this.SucChua.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SucChua.Properties.IsFloatValue = false;
            this.SucChua.Properties.MaskSettings.Set("mask", "N00");
            this.SucChua.Size = new System.Drawing.Size(246, 36);
            this.SucChua.TabIndex = 5;
            // 
            // LabelControl3
            // 
            this.LabelControl3.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl3.Appearance.Options.UseFont = true;
            this.LabelControl3.Location = new System.Drawing.Point(15, 113);
            this.LabelControl3.Name = "LabelControl3";
            this.LabelControl3.Size = new System.Drawing.Size(91, 30);
            this.LabelControl3.TabIndex = 4;
            this.LabelControl3.Text = "Sức Chứa";
            // 
            // TenLoai
            // 
            this.TenLoai.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TenLoai.Location = new System.Drawing.Point(513, 44);
            this.TenLoai.Name = "TenLoai";
            this.TenLoai.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TenLoai.Properties.Appearance.Options.UseFont = true;
            this.TenLoai.Size = new System.Drawing.Size(246, 36);
            this.TenLoai.TabIndex = 3;
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Location = new System.Drawing.Point(405, 47);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(79, 30);
            this.LabelControl2.TabIndex = 2;
            this.LabelControl2.Text = "Tên Loại";
            // 
            // MaSoLoai
            // 
            this.MaSoLoai.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaSoLoai.Location = new System.Drawing.Point(129, 41);
            this.MaSoLoai.Name = "MaSoLoai";
            this.MaSoLoai.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.MaSoLoai.Properties.Appearance.Options.UseFont = true;
            this.MaSoLoai.Size = new System.Drawing.Size(246, 36);
            this.MaSoLoai.TabIndex = 1;
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(15, 44);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(76, 30);
            this.LabelControl1.TabIndex = 0;
            this.LabelControl1.Text = "Mã Loại";
            // 
            // NutOK
            // 
            this.NutOK.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutOK.Appearance.Options.UseFont = true;
            this.NutOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutOK.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutOK.ImageOptions.SvgImage")));
            this.NutOK.Location = new System.Drawing.Point(692, 502);
            this.NutOK.Name = "NutOK";
            this.NutOK.Size = new System.Drawing.Size(94, 46);
            this.NutOK.TabIndex = 1;
            this.NutOK.Text = "OK";
            this.NutOK.Click += new System.EventHandler(this.NutOK_Click);
            // 
            // NutHuy
            // 
            this.NutHuy.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutHuy.Appearance.Options.UseFont = true;
            this.NutHuy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutHuy.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.NutHuy.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutHuy.ImageOptions.SvgImage")));
            this.NutHuy.Location = new System.Drawing.Point(580, 502);
            this.NutHuy.Name = "NutHuy";
            this.NutHuy.Size = new System.Drawing.Size(94, 46);
            this.NutHuy.TabIndex = 2;
            this.NutHuy.Text = "HỦY";
            // 
            // ThongTinLoaiPhong
            // 
            this.AcceptButton = this.NutOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.NutHuy;
            this.ClientSize = new System.Drawing.Size(800, 563);
            this.Controls.Add(this.NutHuy);
            this.Controls.Add(this.NutOK);
            this.Controls.Add(this.GroupControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ThongTinLoaiPhong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "THÊM LOẠI PHÒNG NGHỈ";
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).EndInit();
            this.GroupControl1.ResumeLayout(false);
            this.GroupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MoTa.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TienTrongNgay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TienNgoaiNgay.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Giuong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SucChua.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TenLoai.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaSoLoai.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl GroupControl1;
        private DevExpress.XtraEditors.LabelControl LabelControl2;
        private DevExpress.XtraEditors.TextEdit MaSoLoai;
        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private DevExpress.XtraEditors.TextEdit TenLoai;
        private DevExpress.XtraEditors.SpinEdit Giuong;
        private DevExpress.XtraEditors.LabelControl LabelControl6;
        private DevExpress.XtraEditors.SpinEdit SucChua;
        private DevExpress.XtraEditors.LabelControl LabelControl3;
        private DevExpress.XtraEditors.SpinEdit TienTrongNgay;
        private DevExpress.XtraEditors.LabelControl LabelControl4;
        private DevExpress.XtraEditors.SpinEdit TienNgoaiNgay;
        private DevExpress.XtraEditors.LabelControl LabelControl5;
        private DevExpress.XtraEditors.LabelControl LabelControl7;
        private DevExpress.XtraEditors.SimpleButton NutOK;
        private DevExpress.XtraEditors.SimpleButton NutHuy;
        private DevExpress.XtraEditors.LabelControl LabelControl8;
        private DevExpress.XtraEditors.LabelControl LabelControl9;
        private DevExpress.XtraEditors.MemoEdit MoTa;
    }
}