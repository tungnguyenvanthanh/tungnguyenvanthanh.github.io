﻿namespace GUILAYER
{
    partial class ThongTinKhachHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinKhachHang));
            this.GroupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.QueQuan = new DevExpress.XtraEditors.MemoEdit();
            this.LabelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.Email = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.SoLienHe = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.QuocTich_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.SearchLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GioiTinh_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.HoVaTen = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.IDKhach = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.NutHuy = new DevExpress.XtraEditors.SimpleButton();
            this.NutOK = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).BeginInit();
            this.GroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QueQuan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Email.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoLienHe.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.QuocTich_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GioiTinh_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HoVaTen.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDKhach.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // GroupControl1
            // 
            this.GroupControl1.Controls.Add(this.QueQuan);
            this.GroupControl1.Controls.Add(this.LabelControl7);
            this.GroupControl1.Controls.Add(this.Email);
            this.GroupControl1.Controls.Add(this.LabelControl6);
            this.GroupControl1.Controls.Add(this.SoLienHe);
            this.GroupControl1.Controls.Add(this.LabelControl5);
            this.GroupControl1.Controls.Add(this.LabelControl4);
            this.GroupControl1.Controls.Add(this.QuocTich_SLUE);
            this.GroupControl1.Controls.Add(this.GioiTinh_SLUE);
            this.GroupControl1.Controls.Add(this.LabelControl3);
            this.GroupControl1.Controls.Add(this.HoVaTen);
            this.GroupControl1.Controls.Add(this.LabelControl2);
            this.GroupControl1.Controls.Add(this.IDKhach);
            this.GroupControl1.Controls.Add(this.LabelControl1);
            this.GroupControl1.Location = new System.Drawing.Point(12, 12);
            this.GroupControl1.Name = "GroupControl1";
            this.GroupControl1.Size = new System.Drawing.Size(776, 430);
            this.GroupControl1.TabIndex = 0;
            this.GroupControl1.Text = "THÔNG TIN KHÁCH HÀNG";
            // 
            // QueQuan
            // 
            this.QueQuan.Location = new System.Drawing.Point(18, 267);
            this.QueQuan.Name = "QueQuan";
            this.QueQuan.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QueQuan.Properties.Appearance.Options.UseFont = true;
            this.QueQuan.Properties.MaxLength = 99;
            this.QueQuan.Size = new System.Drawing.Size(741, 148);
            this.QueQuan.TabIndex = 28;
            // 
            // LabelControl7
            // 
            this.LabelControl7.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl7.Appearance.Options.UseFont = true;
            this.LabelControl7.Location = new System.Drawing.Point(15, 231);
            this.LabelControl7.Name = "LabelControl7";
            this.LabelControl7.Size = new System.Drawing.Size(99, 30);
            this.LabelControl7.TabIndex = 27;
            this.LabelControl7.Text = "Quê Quán";
            // 
            // Email
            // 
            this.Email.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.Email.Location = new System.Drawing.Point(513, 170);
            this.Email.Name = "Email";
            this.Email.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.Email.Properties.Appearance.Options.UseFont = true;
            this.Email.Size = new System.Drawing.Size(246, 36);
            this.Email.TabIndex = 26;
            // 
            // LabelControl6
            // 
            this.LabelControl6.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl6.Appearance.Options.UseFont = true;
            this.LabelControl6.Location = new System.Drawing.Point(405, 173);
            this.LabelControl6.Name = "LabelControl6";
            this.LabelControl6.Size = new System.Drawing.Size(51, 30);
            this.LabelControl6.TabIndex = 25;
            this.LabelControl6.Text = "Email";
            // 
            // SoLienHe
            // 
            this.SoLienHe.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.SoLienHe.Location = new System.Drawing.Point(129, 170);
            this.SoLienHe.Name = "SoLienHe";
            this.SoLienHe.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoLienHe.Properties.Appearance.Options.UseFont = true;
            this.SoLienHe.Properties.MaxLength = 11;
            this.SoLienHe.Size = new System.Drawing.Size(246, 36);
            this.SoLienHe.TabIndex = 24;
            // 
            // LabelControl5
            // 
            this.LabelControl5.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl5.Appearance.Options.UseFont = true;
            this.LabelControl5.Location = new System.Drawing.Point(15, 173);
            this.LabelControl5.Name = "LabelControl5";
            this.LabelControl5.Size = new System.Drawing.Size(103, 30);
            this.LabelControl5.TabIndex = 23;
            this.LabelControl5.Text = "Điện Thoại";
            // 
            // LabelControl4
            // 
            this.LabelControl4.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl4.Appearance.Options.UseFont = true;
            this.LabelControl4.Location = new System.Drawing.Point(405, 110);
            this.LabelControl4.Name = "LabelControl4";
            this.LabelControl4.Size = new System.Drawing.Size(97, 30);
            this.LabelControl4.TabIndex = 22;
            this.LabelControl4.Text = "Quốc Tịch";
            // 
            // QuocTich_SLUE
            // 
            this.QuocTich_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.QuocTich_SLUE.Location = new System.Drawing.Point(513, 107);
            this.QuocTich_SLUE.Name = "QuocTich_SLUE";
            this.QuocTich_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.QuocTich_SLUE.Properties.Appearance.Options.UseFont = true;
            this.QuocTich_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.QuocTich_SLUE.Properties.DisplayMember = "QUOCTICH";
            this.QuocTich_SLUE.Properties.PopupView = this.SearchLookUpEdit1View;
            this.QuocTich_SLUE.Properties.ValueMember = "MAQT";
            this.QuocTich_SLUE.Size = new System.Drawing.Size(246, 36);
            this.QuocTich_SLUE.TabIndex = 21;
            // 
            // SearchLookUpEdit1View
            // 
            this.SearchLookUpEdit1View.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.SearchLookUpEdit1View.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.SearchLookUpEdit1View.Appearance.FocusedRow.Options.UseBackColor = true;
            this.SearchLookUpEdit1View.Appearance.FocusedRow.Options.UseForeColor = true;
            this.SearchLookUpEdit1View.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.SearchLookUpEdit1View.Appearance.Row.Options.UseFont = true;
            this.SearchLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn1,
            this.GridColumn2});
            this.SearchLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.SearchLookUpEdit1View.Name = "SearchLookUpEdit1View";
            this.SearchLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.SearchLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            this.SearchLookUpEdit1View.OptionsView.ShowIndicator = false;
            this.SearchLookUpEdit1View.RowHeight = 40;
            // 
            // GridColumn1
            // 
            this.GridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn1.AppearanceHeader.Options.UseFont = true;
            this.GridColumn1.Caption = "MÃ QT";
            this.GridColumn1.FieldName = "MAQT";
            this.GridColumn1.Name = "GridColumn1";
            this.GridColumn1.Visible = true;
            this.GridColumn1.VisibleIndex = 0;
            // 
            // GridColumn2
            // 
            this.GridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn2.AppearanceHeader.Options.UseFont = true;
            this.GridColumn2.Caption = "QUỐC TỊCH";
            this.GridColumn2.FieldName = "QUOCTICH";
            this.GridColumn2.Name = "GridColumn2";
            this.GridColumn2.Visible = true;
            this.GridColumn2.VisibleIndex = 1;
            // 
            // GioiTinh_SLUE
            // 
            this.GioiTinh_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GioiTinh_SLUE.Location = new System.Drawing.Point(129, 107);
            this.GioiTinh_SLUE.Name = "GioiTinh_SLUE";
            this.GioiTinh_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.GioiTinh_SLUE.Properties.Appearance.Options.UseFont = true;
            this.GioiTinh_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.GioiTinh_SLUE.Properties.DisplayMember = "GIOITINH";
            this.GioiTinh_SLUE.Properties.PopupView = this.GridView1;
            this.GioiTinh_SLUE.Properties.ValueMember = "MAGT";
            this.GioiTinh_SLUE.Size = new System.Drawing.Size(246, 36);
            this.GioiTinh_SLUE.TabIndex = 20;
            // 
            // GridView1
            // 
            this.GridView1.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView1.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView1.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView1.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView1.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView1.Appearance.Row.Options.UseFont = true;
            this.GridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn3,
            this.GridColumn4});
            this.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView1.Name = "GridView1";
            this.GridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView1.OptionsView.ShowGroupPanel = false;
            this.GridView1.OptionsView.ShowIndicator = false;
            this.GridView1.RowHeight = 40;
            // 
            // GridColumn3
            // 
            this.GridColumn3.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn3.AppearanceHeader.Options.UseFont = true;
            this.GridColumn3.Caption = "MÃ GIỐNG";
            this.GridColumn3.FieldName = "MAGT";
            this.GridColumn3.Name = "GridColumn3";
            this.GridColumn3.Visible = true;
            this.GridColumn3.VisibleIndex = 0;
            // 
            // GridColumn4
            // 
            this.GridColumn4.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn4.AppearanceHeader.Options.UseFont = true;
            this.GridColumn4.Caption = "GIỚI TÍNH";
            this.GridColumn4.FieldName = "GIOITINH";
            this.GridColumn4.Name = "GridColumn4";
            this.GridColumn4.Visible = true;
            this.GridColumn4.VisibleIndex = 1;
            // 
            // LabelControl3
            // 
            this.LabelControl3.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl3.Appearance.Options.UseFont = true;
            this.LabelControl3.Location = new System.Drawing.Point(15, 110);
            this.LabelControl3.Name = "LabelControl3";
            this.LabelControl3.Size = new System.Drawing.Size(85, 30);
            this.LabelControl3.TabIndex = 8;
            this.LabelControl3.Text = "Giới Tính";
            // 
            // HoVaTen
            // 
            this.HoVaTen.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.HoVaTen.Location = new System.Drawing.Point(513, 39);
            this.HoVaTen.Name = "HoVaTen";
            this.HoVaTen.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.HoVaTen.Properties.Appearance.Options.UseFont = true;
            this.HoVaTen.Size = new System.Drawing.Size(246, 36);
            this.HoVaTen.TabIndex = 7;
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Location = new System.Drawing.Point(405, 42);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(100, 30);
            this.LabelControl2.TabIndex = 6;
            this.LabelControl2.Text = "Tên Khách";
            // 
            // IDKhach
            // 
            this.IDKhach.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.IDKhach.Location = new System.Drawing.Point(129, 36);
            this.IDKhach.Name = "IDKhach";
            this.IDKhach.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.IDKhach.Properties.Appearance.Options.UseFont = true;
            this.IDKhach.Size = new System.Drawing.Size(246, 36);
            this.IDKhach.TabIndex = 5;
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(15, 39);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(95, 30);
            this.LabelControl1.TabIndex = 4;
            this.LabelControl1.Text = "Mã Khách";
            // 
            // NutHuy
            // 
            this.NutHuy.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutHuy.Appearance.Options.UseFont = true;
            this.NutHuy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutHuy.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.NutHuy.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutHuy.ImageOptions.SvgImage")));
            this.NutHuy.Location = new System.Drawing.Point(583, 462);
            this.NutHuy.Name = "NutHuy";
            this.NutHuy.Size = new System.Drawing.Size(94, 46);
            this.NutHuy.TabIndex = 6;
            this.NutHuy.Text = "HỦY";
            // 
            // NutOK
            // 
            this.NutOK.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutOK.Appearance.Options.UseFont = true;
            this.NutOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutOK.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutOK.ImageOptions.SvgImage")));
            this.NutOK.Location = new System.Drawing.Point(693, 462);
            this.NutOK.Name = "NutOK";
            this.NutOK.Size = new System.Drawing.Size(94, 46);
            this.NutOK.TabIndex = 5;
            this.NutOK.Text = "OK";
            this.NutOK.Click += new System.EventHandler(this.NutOK_Click);
            // 
            // ThongTinKhachHang
            // 
            this.AcceptButton = this.NutOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.NutHuy;
            this.ClientSize = new System.Drawing.Size(800, 523);
            this.Controls.Add(this.NutHuy);
            this.Controls.Add(this.NutOK);
            this.Controls.Add(this.GroupControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ThongTinKhachHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "THÔNG TIN KHÁCH HÀNG";
            this.Load += new System.EventHandler(this.ThongTinKhachHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).EndInit();
            this.GroupControl1.ResumeLayout(false);
            this.GroupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.QueQuan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Email.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoLienHe.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.QuocTich_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SearchLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GioiTinh_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HoVaTen.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.IDKhach.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl GroupControl1;
        private DevExpress.XtraEditors.TextEdit HoVaTen;
        private DevExpress.XtraEditors.LabelControl LabelControl2;
        private DevExpress.XtraEditors.TextEdit IDKhach;
        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private DevExpress.XtraEditors.LabelControl LabelControl3;
        private DevExpress.XtraEditors.SearchLookUpEdit GioiTinh_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView1;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn4;
        private DevExpress.XtraEditors.LabelControl LabelControl4;
        private DevExpress.XtraEditors.SearchLookUpEdit QuocTich_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView SearchLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn2;
        private DevExpress.XtraEditors.TextEdit SoLienHe;
        private DevExpress.XtraEditors.LabelControl LabelControl5;
        private DevExpress.XtraEditors.TextEdit Email;
        private DevExpress.XtraEditors.LabelControl LabelControl6;
        private DevExpress.XtraEditors.LabelControl LabelControl7;
        private DevExpress.XtraEditors.SimpleButton NutHuy;
        private DevExpress.XtraEditors.SimpleButton NutOK;
        private DevExpress.XtraEditors.MemoEdit QueQuan;
    }
}