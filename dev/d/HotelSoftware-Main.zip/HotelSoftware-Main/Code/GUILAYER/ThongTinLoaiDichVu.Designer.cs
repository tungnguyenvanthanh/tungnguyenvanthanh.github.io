﻿namespace GUILAYER
{
    partial class ThongTinLoaiDichVu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinLoaiDichVu));
            this.GroupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.LabelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.MoTaDV = new DevExpress.XtraEditors.TextEdit();
            this.MaSoLoaiDV = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.TenLoaiDV = new DevExpress.XtraEditors.TextEdit();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.NutHuy = new DevExpress.XtraEditors.SimpleButton();
            this.NutOK = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).BeginInit();
            this.GroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MoTaDV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaSoLoaiDV.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TenLoaiDV.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // GroupControl1
            // 
            this.GroupControl1.Controls.Add(this.LabelControl3);
            this.GroupControl1.Controls.Add(this.MoTaDV);
            this.GroupControl1.Controls.Add(this.MaSoLoaiDV);
            this.GroupControl1.Controls.Add(this.LabelControl2);
            this.GroupControl1.Controls.Add(this.TenLoaiDV);
            this.GroupControl1.Controls.Add(this.LabelControl1);
            this.GroupControl1.Location = new System.Drawing.Point(12, 12);
            this.GroupControl1.Name = "GroupControl1";
            this.GroupControl1.Size = new System.Drawing.Size(474, 279);
            this.GroupControl1.TabIndex = 1;
            this.GroupControl1.Text = "THÔNG TIN LOẠI DỊCH VỤ";
            // 
            // LabelControl3
            // 
            this.LabelControl3.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl3.Appearance.Options.UseFont = true;
            this.LabelControl3.Location = new System.Drawing.Point(20, 206);
            this.LabelControl3.Name = "LabelControl3";
            this.LabelControl3.Size = new System.Drawing.Size(62, 30);
            this.LabelControl3.TabIndex = 6;
            this.LabelControl3.Text = "Mô Tả";
            // 
            // MoTaDV
            // 
            this.MoTaDV.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MoTaDV.Location = new System.Drawing.Point(142, 203);
            this.MoTaDV.Name = "MoTaDV";
            this.MoTaDV.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.MoTaDV.Properties.Appearance.Options.UseFont = true;
            this.MoTaDV.Properties.MaxLength = 99;
            this.MoTaDV.Size = new System.Drawing.Size(303, 36);
            this.MoTaDV.TabIndex = 5;
            // 
            // MaSoLoaiDV
            // 
            this.MaSoLoaiDV.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.MaSoLoaiDV.Location = new System.Drawing.Point(142, 51);
            this.MaSoLoaiDV.Name = "MaSoLoaiDV";
            this.MaSoLoaiDV.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.MaSoLoaiDV.Properties.Appearance.Options.UseFont = true;
            this.MaSoLoaiDV.Size = new System.Drawing.Size(303, 36);
            this.MaSoLoaiDV.TabIndex = 2;
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Location = new System.Drawing.Point(20, 132);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(79, 30);
            this.LabelControl2.TabIndex = 3;
            this.LabelControl2.Text = "Tên Loại";
            // 
            // TenLoaiDV
            // 
            this.TenLoaiDV.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TenLoaiDV.Location = new System.Drawing.Point(142, 129);
            this.TenLoaiDV.Name = "TenLoaiDV";
            this.TenLoaiDV.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TenLoaiDV.Properties.Appearance.Options.UseFont = true;
            this.TenLoaiDV.Size = new System.Drawing.Size(303, 36);
            this.TenLoaiDV.TabIndex = 4;
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(20, 54);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(76, 30);
            this.LabelControl1.TabIndex = 0;
            this.LabelControl1.Text = "Mã Loại";
            // 
            // NutHuy
            // 
            this.NutHuy.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutHuy.Appearance.Options.UseFont = true;
            this.NutHuy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutHuy.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.NutHuy.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutHuy.ImageOptions.SvgImage")));
            this.NutHuy.Location = new System.Drawing.Point(281, 314);
            this.NutHuy.Name = "NutHuy";
            this.NutHuy.Size = new System.Drawing.Size(94, 46);
            this.NutHuy.TabIndex = 6;
            this.NutHuy.Text = "HỦY";
            // 
            // NutOK
            // 
            this.NutOK.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutOK.Appearance.Options.UseFont = true;
            this.NutOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutOK.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutOK.ImageOptions.SvgImage")));
            this.NutOK.Location = new System.Drawing.Point(393, 314);
            this.NutOK.Name = "NutOK";
            this.NutOK.Size = new System.Drawing.Size(94, 46);
            this.NutOK.TabIndex = 5;
            this.NutOK.Text = "OK";
            this.NutOK.Click += new System.EventHandler(this.NutOK_Click);
            // 
            // ThongTinLoaiDichVu
            // 
            this.AcceptButton = this.NutOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.NutHuy;
            this.ClientSize = new System.Drawing.Size(498, 384);
            this.Controls.Add(this.NutHuy);
            this.Controls.Add(this.NutOK);
            this.Controls.Add(this.GroupControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ThongTinLoaiDichVu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "THÔNG TIN LOẠI DỊCH VỤ";
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).EndInit();
            this.GroupControl1.ResumeLayout(false);
            this.GroupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.MoTaDV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MaSoLoaiDV.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TenLoaiDV.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl GroupControl1;
        private DevExpress.XtraEditors.LabelControl LabelControl2;
        private DevExpress.XtraEditors.TextEdit TenLoaiDV;
        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private DevExpress.XtraEditors.SimpleButton NutHuy;
        private DevExpress.XtraEditors.SimpleButton NutOK;
        private DevExpress.XtraEditors.TextEdit MaSoLoaiDV;
        private DevExpress.XtraEditors.LabelControl LabelControl3;
        private DevExpress.XtraEditors.TextEdit MoTaDV;
    }
}