﻿namespace GUILAYER
{
    partial class LayVaTraPhongForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LayVaTraPhongForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            this.BarManager = new DevExpress.XtraBars.BarManager(this.components);
            this.Bar1 = new DevExpress.XtraBars.Bar();
            this.NutLayPhong = new DevExpress.XtraBars.BarButtonItem();
            this.NutTraPhong = new DevExpress.XtraBars.BarButtonItem();
            this.NutHuyPhong = new DevExpress.XtraBars.BarButtonItem();
            this.BarDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.DockManager = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.ThanhPhanLoai = new DevExpress.XtraBars.Docking.DockPanel();
            this.DockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.SoPhongCho_SE = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.TrangThai_RG = new DevExpress.XtraEditors.RadioGroup();
            this.LabelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.SoDangDung_SE = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.TongPhong_SE = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.HuyPhongPopOn = new DevExpress.XtraBars.BarButtonItem();
            this.LayPhongPopOn = new DevExpress.XtraBars.BarButtonItem();
            this.TraPhongPopOn = new DevExpress.XtraBars.BarButtonItem();
            this.LayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.PanelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.BangDatPhong = new Guna.UI2.WinForms.Guna2DataGridView();
            this.MAPHONGDAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MAPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYDAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYLAY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYTRA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GIAPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MALOAIHINH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENLOAIHINH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MATRANGTHAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENTRANGTHAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GHICHU = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.THOIHAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PanelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.BangKhachDat = new Guna.UI2.WinForms.Guna2DataGridView();
            this.IDKHACH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.HOVATEN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MAGT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENGIONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SOLIENHE = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.EMAIL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.QUEQUAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MAQT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENNUOC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BangTuyChonKhachHang = new DevExpress.XtraBars.PopupMenu(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.BarManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DockManager)).BeginInit();
            this.ThanhPhanLoai.SuspendLayout();
            this.DockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SoPhongCho_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThai_RG.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoDangDung_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongPhong_SE.Properties)).BeginInit();
            this.LayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl2)).BeginInit();
            this.PanelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BangDatPhong)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl1)).BeginInit();
            this.PanelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BangKhachDat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangTuyChonKhachHang)).BeginInit();
            this.SuspendLayout();
            // 
            // BarManager
            // 
            this.BarManager.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.Bar1});
            this.BarManager.DockControls.Add(this.BarDockControlTop);
            this.BarManager.DockControls.Add(this.BarDockControlBottom);
            this.BarManager.DockControls.Add(this.BarDockControlLeft);
            this.BarManager.DockControls.Add(this.BarDockControlRight);
            this.BarManager.DockManager = this.DockManager;
            this.BarManager.Form = this;
            this.BarManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.NutLayPhong,
            this.NutHuyPhong,
            this.HuyPhongPopOn,
            this.LayPhongPopOn,
            this.NutTraPhong,
            this.TraPhongPopOn});
            this.BarManager.MainMenu = this.Bar1;
            this.BarManager.MaxItemId = 23;
            // 
            // Bar1
            // 
            this.Bar1.BarName = "Main menu";
            this.Bar1.DockCol = 0;
            this.Bar1.DockRow = 0;
            this.Bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.Bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.NutLayPhong, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.NutTraPhong, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.NutHuyPhong, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.Bar1.OptionsBar.MultiLine = true;
            this.Bar1.OptionsBar.UseWholeRow = true;
            this.Bar1.Text = "Main menu";
            // 
            // NutLayPhong
            // 
            this.NutLayPhong.ActAsDropDown = true;
            this.NutLayPhong.Caption = "LẤY PHÒNG";
            this.NutLayPhong.Enabled = false;
            this.NutLayPhong.Hint = "Cho khách nhận tất cả các phòng đang đặt";
            this.NutLayPhong.Id = 11;
            this.NutLayPhong.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutLayPhong.ImageOptions.SvgImage")));
            this.NutLayPhong.Name = "NutLayPhong";
            this.NutLayPhong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutLayPhong_ItemClick);
            // 
            // NutTraPhong
            // 
            this.NutTraPhong.Caption = "TRẢ PHÒNG";
            this.NutTraPhong.Enabled = false;
            this.NutTraPhong.Hint = "Nhận lại tất cả các phòng từ khách hàng";
            this.NutTraPhong.Id = 21;
            this.NutTraPhong.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutTraPhong.ImageOptions.SvgImage")));
            this.NutTraPhong.Name = "NutTraPhong";
            this.NutTraPhong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutTraPhong_ItemClick);
            // 
            // NutHuyPhong
            // 
            this.NutHuyPhong.Caption = "HỦY PHÒNG";
            this.NutHuyPhong.Enabled = false;
            this.NutHuyPhong.Hint = "Hủy tất cả các phòng của khách đang đặt";
            this.NutHuyPhong.Id = 12;
            this.NutHuyPhong.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutHuyPhong.ImageOptions.SvgImage")));
            this.NutHuyPhong.Name = "NutHuyPhong";
            this.NutHuyPhong.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutHuyPhong_ItemClick);
            // 
            // BarDockControlTop
            // 
            this.BarDockControlTop.CausesValidation = false;
            this.BarDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.BarDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.BarDockControlTop.Manager = this.BarManager;
            this.BarDockControlTop.Size = new System.Drawing.Size(1883, 35);
            // 
            // BarDockControlBottom
            // 
            this.BarDockControlBottom.CausesValidation = false;
            this.BarDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BarDockControlBottom.Location = new System.Drawing.Point(0, 741);
            this.BarDockControlBottom.Manager = this.BarManager;
            this.BarDockControlBottom.Size = new System.Drawing.Size(1883, 0);
            // 
            // BarDockControlLeft
            // 
            this.BarDockControlLeft.CausesValidation = false;
            this.BarDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.BarDockControlLeft.Location = new System.Drawing.Point(0, 35);
            this.BarDockControlLeft.Manager = this.BarManager;
            this.BarDockControlLeft.Size = new System.Drawing.Size(0, 706);
            // 
            // BarDockControlRight
            // 
            this.BarDockControlRight.CausesValidation = false;
            this.BarDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.BarDockControlRight.Location = new System.Drawing.Point(1883, 35);
            this.BarDockControlRight.Manager = this.BarManager;
            this.BarDockControlRight.Size = new System.Drawing.Size(0, 706);
            // 
            // DockManager
            // 
            this.DockManager.Form = this;
            this.DockManager.MenuManager = this.BarManager;
            this.DockManager.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.ThanhPhanLoai});
            this.DockManager.Style = DevExpress.XtraBars.Docking2010.Views.DockingViewStyle.Light;
            this.DockManager.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane",
            "DevExpress.XtraBars.TabFormControl",
            "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl",
            "DevExpress.XtraBars.ToolbarForm.ToolbarFormControl"});
            // 
            // ThanhPhanLoai
            // 
            this.ThanhPhanLoai.Controls.Add(this.DockPanel1_Container);
            this.ThanhPhanLoai.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.ThanhPhanLoai.FloatSize = new System.Drawing.Size(310, 706);
            this.ThanhPhanLoai.ID = new System.Guid("00299be8-766b-4b18-96e5-1b0f3410b0b6");
            this.ThanhPhanLoai.Location = new System.Drawing.Point(0, 35);
            this.ThanhPhanLoai.Name = "ThanhPhanLoai";
            this.ThanhPhanLoai.Options.ShowCloseButton = false;
            this.ThanhPhanLoai.OriginalSize = new System.Drawing.Size(310, 200);
            this.ThanhPhanLoai.Size = new System.Drawing.Size(310, 706);
            this.ThanhPhanLoai.Text = "THANH BỘ LỌC";
            // 
            // DockPanel1_Container
            // 
            this.DockPanel1_Container.Controls.Add(this.SoPhongCho_SE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl1);
            this.DockPanel1_Container.Controls.Add(this.TrangThai_RG);
            this.DockPanel1_Container.Controls.Add(this.LabelControl13);
            this.DockPanel1_Container.Controls.Add(this.LabelControl8);
            this.DockPanel1_Container.Controls.Add(this.SoDangDung_SE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl9);
            this.DockPanel1_Container.Controls.Add(this.TongPhong_SE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl10);
            this.DockPanel1_Container.Location = new System.Drawing.Point(0, 33);
            this.DockPanel1_Container.Name = "DockPanel1_Container";
            this.DockPanel1_Container.Size = new System.Drawing.Size(309, 673);
            this.DockPanel1_Container.TabIndex = 0;
            // 
            // SoPhongCho_SE
            // 
            this.SoPhongCho_SE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.SoPhongCho_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SoPhongCho_SE.Enabled = false;
            this.SoPhongCho_SE.Location = new System.Drawing.Point(200, 318);
            this.SoPhongCho_SE.MenuManager = this.BarManager;
            this.SoPhongCho_SE.Name = "SoPhongCho_SE";
            this.SoPhongCho_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoPhongCho_SE.Properties.Appearance.Options.UseFont = true;
            this.SoPhongCho_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SoPhongCho_SE.Properties.IsFloatValue = false;
            this.SoPhongCho_SE.Properties.MaskSettings.Set("mask", "N00");
            this.SoPhongCho_SE.Size = new System.Drawing.Size(100, 36);
            this.SoPhongCho_SE.TabIndex = 30;
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(10, 14);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(100, 30);
            this.LabelControl1.TabIndex = 14;
            this.LabelControl1.Text = "Trạng Thái";
            // 
            // TrangThai_RG
            // 
            this.TrangThai_RG.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TrangThai_RG.Location = new System.Drawing.Point(10, 57);
            this.TrangThai_RG.Name = "TrangThai_RG";
            this.TrangThai_RG.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TrangThai_RG.Properties.Appearance.Options.UseFont = true;
            this.TrangThai_RG.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Far;
            this.TrangThai_RG.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem(null, "ALL"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("RESERVED", "Đang Chờ"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("CHECKEDIN", "Đang Lấy")});
            this.TrangThai_RG.Size = new System.Drawing.Size(290, 135);
            this.TrangThai_RG.TabIndex = 19;
            this.TrangThai_RG.SelectedIndexChanged += new System.EventHandler(this.TrangThai_EditValueChanged);
            // 
            // LabelControl13
            // 
            this.LabelControl13.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl13.Appearance.Options.UseFont = true;
            this.LabelControl13.Location = new System.Drawing.Point(50, 321);
            this.LabelControl13.Name = "LabelControl13";
            this.LabelControl13.Size = new System.Drawing.Size(103, 30);
            this.LabelControl13.TabIndex = 32;
            this.LabelControl13.Text = "Phòng chờ";
            // 
            // LabelControl8
            // 
            this.LabelControl8.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl8.Appearance.Options.UseFont = true;
            this.LabelControl8.Location = new System.Drawing.Point(10, 215);
            this.LabelControl8.Name = "LabelControl8";
            this.LabelControl8.Size = new System.Drawing.Size(93, 30);
            this.LabelControl8.TabIndex = 23;
            this.LabelControl8.Text = "Thông Số";
            // 
            // SoDangDung_SE
            // 
            this.SoDangDung_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SoDangDung_SE.Enabled = false;
            this.SoDangDung_SE.Location = new System.Drawing.Point(200, 373);
            this.SoDangDung_SE.MenuManager = this.BarManager;
            this.SoDangDung_SE.Name = "SoDangDung_SE";
            this.SoDangDung_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoDangDung_SE.Properties.Appearance.Options.UseFont = true;
            this.SoDangDung_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SoDangDung_SE.Properties.IsFloatValue = false;
            this.SoDangDung_SE.Properties.MaskSettings.Set("mask", "N00");
            this.SoDangDung_SE.Size = new System.Drawing.Size(100, 36);
            this.SoDangDung_SE.TabIndex = 25;
            // 
            // LabelControl9
            // 
            this.LabelControl9.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl9.Appearance.Options.UseFont = true;
            this.LabelControl9.Location = new System.Drawing.Point(50, 267);
            this.LabelControl9.Name = "LabelControl9";
            this.LabelControl9.Size = new System.Drawing.Size(62, 30);
            this.LabelControl9.TabIndex = 26;
            this.LabelControl9.Text = "Tất cả:";
            // 
            // TongPhong_SE
            // 
            this.TongPhong_SE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TongPhong_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.TongPhong_SE.Enabled = false;
            this.TongPhong_SE.Location = new System.Drawing.Point(200, 264);
            this.TongPhong_SE.MenuManager = this.BarManager;
            this.TongPhong_SE.Name = "TongPhong_SE";
            this.TongPhong_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TongPhong_SE.Properties.Appearance.Options.UseFont = true;
            this.TongPhong_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TongPhong_SE.Properties.IsFloatValue = false;
            this.TongPhong_SE.Properties.MaskSettings.Set("mask", "N00");
            this.TongPhong_SE.Size = new System.Drawing.Size(100, 36);
            this.TongPhong_SE.TabIndex = 22;
            // 
            // LabelControl10
            // 
            this.LabelControl10.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl10.Appearance.Options.UseFont = true;
            this.LabelControl10.Location = new System.Drawing.Point(50, 376);
            this.LabelControl10.Name = "LabelControl10";
            this.LabelControl10.Size = new System.Drawing.Size(107, 30);
            this.LabelControl10.TabIndex = 29;
            this.LabelControl10.Text = "Đang dùng";
            // 
            // HuyPhongPopOn
            // 
            this.HuyPhongPopOn.Caption = "HỦY PHÒNG";
            this.HuyPhongPopOn.Id = 19;
            this.HuyPhongPopOn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("HuyPhongPopOn.ImageOptions.SvgImage")));
            this.HuyPhongPopOn.Name = "HuyPhongPopOn";
            this.HuyPhongPopOn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutHuyPhong_ItemClick);
            // 
            // LayPhongPopOn
            // 
            this.LayPhongPopOn.Caption = "LẤY PHÒNG";
            this.LayPhongPopOn.Id = 20;
            this.LayPhongPopOn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("LayPhongPopOn.ImageOptions.SvgImage")));
            this.LayPhongPopOn.Name = "LayPhongPopOn";
            this.LayPhongPopOn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutLayPhong_ItemClick);
            // 
            // TraPhongPopOn
            // 
            this.TraPhongPopOn.Caption = "TRẢ PHÒNG";
            this.TraPhongPopOn.Id = 22;
            this.TraPhongPopOn.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("TraPhongPopOn.ImageOptions.SvgImage")));
            this.TraPhongPopOn.Name = "TraPhongPopOn";
            this.TraPhongPopOn.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutTraPhong_ItemClick);
            // 
            // LayoutPanel
            // 
            this.LayoutPanel.ColumnCount = 2;
            this.LayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.LayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.LayoutPanel.Controls.Add(this.PanelControl2, 1, 0);
            this.LayoutPanel.Controls.Add(this.PanelControl1, 0, 0);
            this.LayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LayoutPanel.Location = new System.Drawing.Point(310, 35);
            this.LayoutPanel.Name = "LayoutPanel";
            this.LayoutPanel.RowCount = 1;
            this.LayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.LayoutPanel.Size = new System.Drawing.Size(1573, 706);
            this.LayoutPanel.TabIndex = 0;
            // 
            // PanelControl2
            // 
            this.PanelControl2.Controls.Add(this.BangDatPhong);
            this.PanelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl2.Location = new System.Drawing.Point(789, 3);
            this.PanelControl2.Name = "PanelControl2";
            this.PanelControl2.Size = new System.Drawing.Size(781, 700);
            this.PanelControl2.TabIndex = 1;
            // 
            // BangDatPhong
            // 
            this.BangDatPhong.AllowUserToAddRows = false;
            this.BangDatPhong.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.BangDatPhong.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.BangDatPhong.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BangDatPhong.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangDatPhong.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BangDatPhong.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangDatPhong.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BangDatPhong.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.BangDatPhong.ColumnHeadersHeight = 40;
            this.BangDatPhong.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MAPHONGDAT,
            this.TextBoxColumn1,
            this.TextBoxColumn2,
            this.MAPHONG,
            this.TENPHONG,
            this.NGAYDAT,
            this.NGAYLAY,
            this.NGAYTRA,
            this.GIAPHONG,
            this.MALOAIHINH,
            this.TENLOAIHINH,
            this.MATRANGTHAI,
            this.TENTRANGTHAI,
            this.GHICHU,
            this.THOIHAN});
            this.BangDatPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BangDatPhong.DefaultCellStyle = dataGridViewCellStyle8;
            this.BangDatPhong.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BangDatPhong.EnableHeadersVisualStyles = false;
            this.BangDatPhong.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangDatPhong.Location = new System.Drawing.Point(2, 2);
            this.BangDatPhong.Margin = new System.Windows.Forms.Padding(185, 175, 185, 175);
            this.BangDatPhong.MultiSelect = false;
            this.BangDatPhong.Name = "BangDatPhong";
            this.BangDatPhong.ReadOnly = true;
            this.BangDatPhong.RowHeadersVisible = false;
            this.BangDatPhong.RowHeadersWidth = 51;
            this.BangDatPhong.RowTemplate.Height = 40;
            this.BangDatPhong.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.BangDatPhong.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BangDatPhong.Size = new System.Drawing.Size(777, 696);
            this.BangDatPhong.TabIndex = 6;
            this.BangDatPhong.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.LightGrid;
            this.BangDatPhong.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.BangDatPhong.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.BangDatPhong.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.BangDatPhong.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.BangDatPhong.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.BangDatPhong.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangDatPhong.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangDatPhong.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.BangDatPhong.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.BangDatPhong.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangDatPhong.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.BangDatPhong.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.BangDatPhong.ThemeStyle.HeaderStyle.Height = 40;
            this.BangDatPhong.ThemeStyle.ReadOnly = true;
            this.BangDatPhong.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.BangDatPhong.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangDatPhong.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangDatPhong.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.BangDatPhong.ThemeStyle.RowsStyle.Height = 40;
            this.BangDatPhong.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.BangDatPhong.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            // 
            // MAPHONGDAT
            // 
            this.MAPHONGDAT.DataPropertyName = "MAPHONGDAT";
            this.MAPHONGDAT.HeaderText = "MÃ ĐẶT";
            this.MAPHONGDAT.MinimumWidth = 6;
            this.MAPHONGDAT.Name = "MAPHONGDAT";
            this.MAPHONGDAT.ReadOnly = true;
            this.MAPHONGDAT.Visible = false;
            // 
            // TextBoxColumn1
            // 
            this.TextBoxColumn1.DataPropertyName = "IDKHACH";
            this.TextBoxColumn1.HeaderText = "ID KHÁCH";
            this.TextBoxColumn1.MinimumWidth = 6;
            this.TextBoxColumn1.Name = "TextBoxColumn1";
            this.TextBoxColumn1.ReadOnly = true;
            this.TextBoxColumn1.Visible = false;
            // 
            // TextBoxColumn2
            // 
            this.TextBoxColumn2.DataPropertyName = "HOVATEN";
            this.TextBoxColumn2.HeaderText = "HỌ TÊN";
            this.TextBoxColumn2.MinimumWidth = 6;
            this.TextBoxColumn2.Name = "TextBoxColumn2";
            this.TextBoxColumn2.ReadOnly = true;
            this.TextBoxColumn2.Visible = false;
            // 
            // MAPHONG
            // 
            this.MAPHONG.DataPropertyName = "MAPHONG";
            this.MAPHONG.HeaderText = "MÃ PHÒNG";
            this.MAPHONG.MinimumWidth = 6;
            this.MAPHONG.Name = "MAPHONG";
            this.MAPHONG.ReadOnly = true;
            this.MAPHONG.Visible = false;
            // 
            // TENPHONG
            // 
            this.TENPHONG.DataPropertyName = "TENPHONG";
            this.TENPHONG.HeaderText = "TÊN PHÒNG";
            this.TENPHONG.MinimumWidth = 6;
            this.TENPHONG.Name = "TENPHONG";
            this.TENPHONG.ReadOnly = true;
            // 
            // NGAYDAT
            // 
            this.NGAYDAT.DataPropertyName = "NGAYDAT";
            dataGridViewCellStyle3.Format = "g";
            dataGridViewCellStyle3.NullValue = null;
            this.NGAYDAT.DefaultCellStyle = dataGridViewCellStyle3;
            this.NGAYDAT.HeaderText = "NGÀY ĐẶT";
            this.NGAYDAT.MinimumWidth = 6;
            this.NGAYDAT.Name = "NGAYDAT";
            this.NGAYDAT.ReadOnly = true;
            this.NGAYDAT.Visible = false;
            // 
            // NGAYLAY
            // 
            this.NGAYLAY.DataPropertyName = "NGAYLAY";
            dataGridViewCellStyle4.Format = "g";
            dataGridViewCellStyle4.NullValue = null;
            this.NGAYLAY.DefaultCellStyle = dataGridViewCellStyle4;
            this.NGAYLAY.HeaderText = "NGÀY LẤY";
            this.NGAYLAY.MinimumWidth = 6;
            this.NGAYLAY.Name = "NGAYLAY";
            this.NGAYLAY.ReadOnly = true;
            // 
            // NGAYTRA
            // 
            this.NGAYTRA.DataPropertyName = "NGAYTRA";
            dataGridViewCellStyle5.Format = "g";
            dataGridViewCellStyle5.NullValue = null;
            this.NGAYTRA.DefaultCellStyle = dataGridViewCellStyle5;
            this.NGAYTRA.HeaderText = "NGÀY TRẢ";
            this.NGAYTRA.MinimumWidth = 6;
            this.NGAYTRA.Name = "NGAYTRA";
            this.NGAYTRA.ReadOnly = true;
            // 
            // GIAPHONG
            // 
            this.GIAPHONG.DataPropertyName = "GIAPHONG";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = null;
            this.GIAPHONG.DefaultCellStyle = dataGridViewCellStyle6;
            this.GIAPHONG.HeaderText = "GIÁ PHÒNG";
            this.GIAPHONG.MinimumWidth = 6;
            this.GIAPHONG.Name = "GIAPHONG";
            this.GIAPHONG.ReadOnly = true;
            this.GIAPHONG.Visible = false;
            // 
            // MALOAIHINH
            // 
            this.MALOAIHINH.DataPropertyName = "MALOAIHINH";
            this.MALOAIHINH.HeaderText = "MÃ LOẠI HÌNH";
            this.MALOAIHINH.MinimumWidth = 6;
            this.MALOAIHINH.Name = "MALOAIHINH";
            this.MALOAIHINH.ReadOnly = true;
            this.MALOAIHINH.Visible = false;
            // 
            // TENLOAIHINH
            // 
            this.TENLOAIHINH.DataPropertyName = "TENLOAIHINH";
            this.TENLOAIHINH.HeaderText = "LOẠI HÌNH";
            this.TENLOAIHINH.MinimumWidth = 6;
            this.TENLOAIHINH.Name = "TENLOAIHINH";
            this.TENLOAIHINH.ReadOnly = true;
            this.TENLOAIHINH.Visible = false;
            // 
            // MATRANGTHAI
            // 
            this.MATRANGTHAI.DataPropertyName = "MATRANGTHAI";
            this.MATRANGTHAI.HeaderText = "MÃ TRẠNG THÁI";
            this.MATRANGTHAI.MinimumWidth = 6;
            this.MATRANGTHAI.Name = "MATRANGTHAI";
            this.MATRANGTHAI.ReadOnly = true;
            this.MATRANGTHAI.Visible = false;
            // 
            // TENTRANGTHAI
            // 
            this.TENTRANGTHAI.DataPropertyName = "TENTRANGTHAI";
            this.TENTRANGTHAI.HeaderText = "TRẠNG THÁI";
            this.TENTRANGTHAI.MinimumWidth = 6;
            this.TENTRANGTHAI.Name = "TENTRANGTHAI";
            this.TENTRANGTHAI.ReadOnly = true;
            // 
            // GHICHU
            // 
            this.GHICHU.DataPropertyName = "GHICHU";
            this.GHICHU.HeaderText = "GHI CHÚ";
            this.GHICHU.MinimumWidth = 6;
            this.GHICHU.Name = "GHICHU";
            this.GHICHU.ReadOnly = true;
            this.GHICHU.Visible = false;
            // 
            // THOIHAN
            // 
            this.THOIHAN.DataPropertyName = "THOIHAN";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N2";
            dataGridViewCellStyle7.NullValue = null;
            this.THOIHAN.DefaultCellStyle = dataGridViewCellStyle7;
            this.THOIHAN.HeaderText = "THỜI HẠN";
            this.THOIHAN.MinimumWidth = 6;
            this.THOIHAN.Name = "THOIHAN";
            this.THOIHAN.ReadOnly = true;
            this.THOIHAN.Visible = false;
            // 
            // PanelControl1
            // 
            this.PanelControl1.Controls.Add(this.BangKhachDat);
            this.PanelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl1.Location = new System.Drawing.Point(3, 3);
            this.PanelControl1.Name = "PanelControl1";
            this.PanelControl1.Size = new System.Drawing.Size(780, 700);
            this.PanelControl1.TabIndex = 0;
            // 
            // BangKhachDat
            // 
            this.BangKhachDat.AllowUserToAddRows = false;
            this.BangKhachDat.AllowUserToDeleteRows = false;
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.White;
            this.BangKhachDat.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.BangKhachDat.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BangKhachDat.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangKhachDat.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BangKhachDat.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangKhachDat.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BangKhachDat.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.BangKhachDat.ColumnHeadersHeight = 40;
            this.BangKhachDat.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IDKHACH,
            this.HOVATEN,
            this.MAGT,
            this.TENGIONG,
            this.SOLIENHE,
            this.EMAIL,
            this.QUEQUAN,
            this.MAQT,
            this.TENNUOC});
            this.BangKhachDat.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BangKhachDat.DefaultCellStyle = dataGridViewCellStyle11;
            this.BangKhachDat.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BangKhachDat.EnableHeadersVisualStyles = false;
            this.BangKhachDat.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangKhachDat.Location = new System.Drawing.Point(2, 2);
            this.BangKhachDat.Name = "BangKhachDat";
            this.BangKhachDat.ReadOnly = true;
            this.BangKhachDat.RowHeadersVisible = false;
            this.BangKhachDat.RowHeadersWidth = 51;
            this.BangKhachDat.RowTemplate.Height = 40;
            this.BangKhachDat.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.BangKhachDat.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BangKhachDat.Size = new System.Drawing.Size(776, 696);
            this.BangKhachDat.TabIndex = 13;
            this.BangKhachDat.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.LightGrid;
            this.BangKhachDat.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.BangKhachDat.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.BangKhachDat.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.BangKhachDat.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.BangKhachDat.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.BangKhachDat.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangKhachDat.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangKhachDat.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.BangKhachDat.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.BangKhachDat.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangKhachDat.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.BangKhachDat.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.BangKhachDat.ThemeStyle.HeaderStyle.Height = 40;
            this.BangKhachDat.ThemeStyle.ReadOnly = true;
            this.BangKhachDat.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.BangKhachDat.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangKhachDat.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangKhachDat.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(38)))), ((int)(((byte)(38)))));
            this.BangKhachDat.ThemeStyle.RowsStyle.Height = 40;
            this.BangKhachDat.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.BangKhachDat.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.BangKhachDat.DataSourceChanged += new System.EventHandler(this.KhachDataSourceChanged);
            this.BangKhachDat.SelectionChanged += new System.EventHandler(this.BangKhach_SelectionChanged);
            this.BangKhachDat.MouseClick += new System.Windows.Forms.MouseEventHandler(this.BangKhachDat_MouseClick);
            // 
            // IDKHACH
            // 
            this.IDKHACH.DataPropertyName = "IDKHACH";
            this.IDKHACH.HeaderText = "MÃ KHÁCH";
            this.IDKHACH.MinimumWidth = 6;
            this.IDKHACH.Name = "IDKHACH";
            this.IDKHACH.ReadOnly = true;
            // 
            // HOVATEN
            // 
            this.HOVATEN.DataPropertyName = "HOVATEN";
            this.HOVATEN.HeaderText = "HỌ VÀ TÊN";
            this.HOVATEN.MinimumWidth = 6;
            this.HOVATEN.Name = "HOVATEN";
            this.HOVATEN.ReadOnly = true;
            // 
            // MAGT
            // 
            this.MAGT.DataPropertyName = "MAGT";
            this.MAGT.HeaderText = "MÃ GIỚI TÍNH";
            this.MAGT.MinimumWidth = 6;
            this.MAGT.Name = "MAGT";
            this.MAGT.ReadOnly = true;
            this.MAGT.Visible = false;
            // 
            // TENGIONG
            // 
            this.TENGIONG.DataPropertyName = "GIOITINH";
            this.TENGIONG.HeaderText = "GIỚI TÍNH";
            this.TENGIONG.MinimumWidth = 6;
            this.TENGIONG.Name = "TENGIONG";
            this.TENGIONG.ReadOnly = true;
            this.TENGIONG.Visible = false;
            // 
            // SOLIENHE
            // 
            this.SOLIENHE.DataPropertyName = "SOLIENHE";
            this.SOLIENHE.HeaderText = "SỐ LIÊN HỆ";
            this.SOLIENHE.MinimumWidth = 6;
            this.SOLIENHE.Name = "SOLIENHE";
            this.SOLIENHE.ReadOnly = true;
            // 
            // EMAIL
            // 
            this.EMAIL.DataPropertyName = "EMAIL";
            this.EMAIL.HeaderText = "EMAIL";
            this.EMAIL.MinimumWidth = 6;
            this.EMAIL.Name = "EMAIL";
            this.EMAIL.ReadOnly = true;
            // 
            // QUEQUAN
            // 
            this.QUEQUAN.DataPropertyName = "QUEQUAN";
            this.QUEQUAN.HeaderText = "QUÊN QUÁN";
            this.QUEQUAN.MinimumWidth = 6;
            this.QUEQUAN.Name = "QUEQUAN";
            this.QUEQUAN.ReadOnly = true;
            this.QUEQUAN.Visible = false;
            // 
            // MAQT
            // 
            this.MAQT.DataPropertyName = "MAQT";
            this.MAQT.HeaderText = "MÃ QUỐC TỊCH";
            this.MAQT.MinimumWidth = 6;
            this.MAQT.Name = "MAQT";
            this.MAQT.ReadOnly = true;
            this.MAQT.Visible = false;
            // 
            // TENNUOC
            // 
            this.TENNUOC.DataPropertyName = "QUOCTICH";
            this.TENNUOC.HeaderText = "QUỐC TỊCH";
            this.TENNUOC.MinimumWidth = 6;
            this.TENNUOC.Name = "TENNUOC";
            this.TENNUOC.ReadOnly = true;
            this.TENNUOC.Visible = false;
            // 
            // BangTuyChonKhachHang
            // 
            this.BangTuyChonKhachHang.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.HuyPhongPopOn),
            new DevExpress.XtraBars.LinkPersistInfo(this.LayPhongPopOn),
            new DevExpress.XtraBars.LinkPersistInfo(this.TraPhongPopOn)});
            this.BangTuyChonKhachHang.Manager = this.BarManager;
            this.BangTuyChonKhachHang.Name = "BangTuyChonKhachHang";
            // 
            // NhanPhongForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1883, 741);
            this.Controls.Add(this.LayoutPanel);
            this.Controls.Add(this.ThanhPhanLoai);
            this.Controls.Add(this.BarDockControlLeft);
            this.Controls.Add(this.BarDockControlRight);
            this.Controls.Add(this.BarDockControlBottom);
            this.Controls.Add(this.BarDockControlTop);
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.Name = "NhanPhongForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "NHẬN - TRẢ PHÒNG";
            this.Load += new System.EventHandler(this.FormLoad);
            ((System.ComponentModel.ISupportInitialize)(this.BarManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DockManager)).EndInit();
            this.ThanhPhanLoai.ResumeLayout(false);
            this.DockPanel1_Container.ResumeLayout(false);
            this.DockPanel1_Container.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SoPhongCho_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThai_RG.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoDangDung_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongPhong_SE.Properties)).EndInit();
            this.LayoutPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl2)).EndInit();
            this.PanelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BangDatPhong)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl1)).EndInit();
            this.PanelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BangKhachDat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangTuyChonKhachHang)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.BarManager BarManager;
        private DevExpress.XtraBars.Bar Bar1;
        private DevExpress.XtraBars.BarDockControl BarDockControlTop;
        private DevExpress.XtraBars.BarDockControl BarDockControlBottom;
        private DevExpress.XtraBars.BarDockControl BarDockControlLeft;
        private DevExpress.XtraBars.BarDockControl BarDockControlRight;
        private DevExpress.XtraBars.BarButtonItem NutLayPhong;
        private DevExpress.XtraBars.Docking.DockManager DockManager;
        private DevExpress.XtraBars.Docking.DockPanel ThanhPhanLoai;
        private DevExpress.XtraBars.Docking.ControlContainer DockPanel1_Container;
        private System.Windows.Forms.TableLayoutPanel LayoutPanel;
        private DevExpress.XtraEditors.PanelControl PanelControl1;
        private DevExpress.XtraEditors.PanelControl PanelControl2;
        private Guna.UI2.WinForms.Guna2DataGridView BangKhachDat;
        private Guna.UI2.WinForms.Guna2DataGridView BangDatPhong;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDKHACH;
        private System.Windows.Forms.DataGridViewTextBoxColumn HOVATEN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAGT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENGIONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn SOLIENHE;
        private System.Windows.Forms.DataGridViewTextBoxColumn EMAIL;
        private System.Windows.Forms.DataGridViewTextBoxColumn QUEQUAN;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAQT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENNUOC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONGDAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYDAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYLAY;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYTRA;
        private System.Windows.Forms.DataGridViewTextBoxColumn GIAPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn MALOAIHINH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENLOAIHINH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MATRANGTHAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENTRANGTHAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn GHICHU;
        private System.Windows.Forms.DataGridViewTextBoxColumn THOIHAN;
        private DevExpress.XtraBars.BarButtonItem NutHuyPhong;
        private DevExpress.XtraEditors.RadioGroup TrangThai_RG;
        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private DevExpress.XtraEditors.SpinEdit SoPhongCho_SE;
        private DevExpress.XtraEditors.LabelControl LabelControl13;
        private DevExpress.XtraEditors.LabelControl LabelControl8;
        private DevExpress.XtraEditors.SpinEdit SoDangDung_SE;
        private DevExpress.XtraEditors.LabelControl LabelControl9;
        private DevExpress.XtraEditors.SpinEdit TongPhong_SE;
        private DevExpress.XtraEditors.LabelControl LabelControl10;
        private DevExpress.XtraBars.BarButtonItem HuyPhongPopOn;
        private DevExpress.XtraBars.BarButtonItem LayPhongPopOn;
        private DevExpress.XtraBars.PopupMenu BangTuyChonKhachHang;
        private DevExpress.XtraBars.BarButtonItem NutTraPhong;
        private DevExpress.XtraBars.BarButtonItem TraPhongPopOn;
    }
}