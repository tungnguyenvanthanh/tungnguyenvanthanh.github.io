﻿namespace GUILAYER
{
    partial class ThongTinDatPhong
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PanelControl7 = new DevExpress.XtraEditors.PanelControl();
            this.PanelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.GiamGia = new DevExpress.XtraEditors.SpinEdit();
            this.TongThanhToan = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.DonViTinh_LC = new DevExpress.XtraEditors.LabelControl();
            this.NutHuyBo = new DevExpress.XtraEditors.PictureEdit();
            this.NutDatPhong = new DevExpress.XtraEditors.PictureEdit();
            this.TienThanhToan = new DevExpress.XtraEditors.SpinEdit();
            this.ThoiHanPhongO = new DevExpress.XtraEditors.SpinEdit();
            this.TongGiaPhongO = new DevExpress.XtraEditors.SpinEdit();
            this.SoLuongPhongO = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.BangPhongODaChon = new Guna.UI2.WinForms.Guna2DataGridView();
            this.MAPHONGODC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENPHONGODC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENLOAIPHONGDC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIENTHEODDC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIENTHEOHDC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PanelControl8 = new DevExpress.XtraEditors.PanelControl();
            this.PanelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.BangPhongOBanDau = new Guna.UI2.WinForms.Guna2DataGridView();
            this.MAPHONGOBD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENPHONGOBD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherColumns01 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherColumns02 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherColumns03 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENLOAIPHONGBD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherColmns05 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherColumns06 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MATRANGTHAIPO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OtherColumns08 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIENTHEODBD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIENTHEOHBD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PanelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.PhongSearch = new DevExpress.XtraEditors.SearchControl();
            this.LabelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.TrangThaiPN_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.TinhTrangPN_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.Loai_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.Tang_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.LayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.PanelControl4 = new DevExpress.XtraEditors.PanelControl();
            this.GroupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.TimeOfPayment = new DevExpress.XtraEditors.RadioGroup();
            this.GroupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.ThongBaoDichVu = new DevExpress.XtraEditors.RadioGroup();
            this.GroupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.ChuThich = new DevExpress.XtraEditors.MemoEdit();
            this.SoPhut_SE = new DevExpress.XtraEditors.SpinEdit();
            this.SoGio_SE = new DevExpress.XtraEditors.SpinEdit();
            this.SoNgay_SE = new DevExpress.XtraEditors.SpinEdit();
            this.NutThemKhachHang = new DevExpress.XtraEditors.PictureEdit();
            this.KhachHang_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView9 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GioTra_TE = new DevExpress.XtraEditors.TimeEdit();
            this.GioLay_TE = new DevExpress.XtraEditors.TimeEdit();
            this.NgayTra_DE = new DevExpress.XtraEditors.DateEdit();
            this.NgayLay_DE = new DevExpress.XtraEditors.DateEdit();
            this.LabelControl26 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl25 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl24 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl23 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl22 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl21 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.LoaiHinh_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView8 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn16 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.GroupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.LoaiDatPhong = new DevExpress.XtraEditors.RadioGroup();
            this.Time = new System.Windows.Forms.Timer(this.components);
            this.ThongBaoDatPhong = new DevExpress.XtraBars.Alerter.AlertControl(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl7)).BeginInit();
            this.PanelControl7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl3)).BeginInit();
            this.PanelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GiamGia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongThanhToan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NutHuyBo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NutDatPhong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TienThanhToan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThoiHanPhongO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongGiaPhongO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoLuongPhongO.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangPhongODaChon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl8)).BeginInit();
            this.PanelControl8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl1)).BeginInit();
            this.PanelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BangPhongOBanDau)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl2)).BeginInit();
            this.PanelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PhongSearch.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThaiPN_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TinhTrangPN_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Loai_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tang_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).BeginInit();
            this.LayoutPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl4)).BeginInit();
            this.PanelControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl3)).BeginInit();
            this.GroupControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.TimeOfPayment.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl4)).BeginInit();
            this.GroupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ThongBaoDichVu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl2)).BeginInit();
            this.GroupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChuThich.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoPhut_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoGio_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoNgay_SE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NutThemKhachHang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.KhachHang_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GioTra_TE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GioLay_TE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NgayTra_DE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NgayTra_DE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NgayLay_DE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.NgayLay_DE.Properties.CalendarTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.LoaiHinh_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).BeginInit();
            this.GroupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LoaiDatPhong.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // PanelControl7
            // 
            this.PanelControl7.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.PanelControl7.Controls.Add(this.PanelControl3);
            this.PanelControl7.Controls.Add(this.BangPhongODaChon);
            this.PanelControl7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl7.Location = new System.Drawing.Point(0, 0);
            this.PanelControl7.Name = "PanelControl7";
            this.PanelControl7.Size = new System.Drawing.Size(634, 977);
            this.PanelControl7.TabIndex = 2;
            // 
            // PanelControl3
            // 
            this.PanelControl3.Controls.Add(this.GiamGia);
            this.PanelControl3.Controls.Add(this.TongThanhToan);
            this.PanelControl3.Controls.Add(this.LabelControl10);
            this.PanelControl3.Controls.Add(this.LabelControl9);
            this.PanelControl3.Controls.Add(this.DonViTinh_LC);
            this.PanelControl3.Controls.Add(this.NutHuyBo);
            this.PanelControl3.Controls.Add(this.NutDatPhong);
            this.PanelControl3.Controls.Add(this.TienThanhToan);
            this.PanelControl3.Controls.Add(this.ThoiHanPhongO);
            this.PanelControl3.Controls.Add(this.TongGiaPhongO);
            this.PanelControl3.Controls.Add(this.SoLuongPhongO);
            this.PanelControl3.Controls.Add(this.LabelControl8);
            this.PanelControl3.Controls.Add(this.LabelControl7);
            this.PanelControl3.Controls.Add(this.LabelControl6);
            this.PanelControl3.Controls.Add(this.LabelControl13);
            this.PanelControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl3.Location = new System.Drawing.Point(0, 450);
            this.PanelControl3.Name = "PanelControl3";
            this.PanelControl3.Size = new System.Drawing.Size(634, 527);
            this.PanelControl3.TabIndex = 15;
            // 
            // GiamGia
            // 
            this.GiamGia.Cursor = System.Windows.Forms.Cursors.No;
            this.GiamGia.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.GiamGia.Location = new System.Drawing.Point(289, 246);
            this.GiamGia.Name = "GiamGia";
            this.GiamGia.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.GiamGia.Properties.Appearance.Options.UseFont = true;
            this.GiamGia.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.GiamGia.Properties.IsFloatValue = false;
            this.GiamGia.Properties.MaskSettings.Set("mask", "N00");
            this.GiamGia.Size = new System.Drawing.Size(336, 36);
            this.GiamGia.TabIndex = 74;
            this.GiamGia.EditValueChanged += new System.EventHandler(this.GiamGiaPhong_EditValueChanged);
            // 
            // TongThanhToan
            // 
            this.TongThanhToan.Cursor = System.Windows.Forms.Cursors.No;
            this.TongThanhToan.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.TongThanhToan.Enabled = false;
            this.TongThanhToan.Location = new System.Drawing.Point(289, 304);
            this.TongThanhToan.Name = "TongThanhToan";
            this.TongThanhToan.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TongThanhToan.Properties.Appearance.Options.UseFont = true;
            this.TongThanhToan.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TongThanhToan.Properties.IsFloatValue = false;
            this.TongThanhToan.Properties.MaskSettings.Set("mask", "N00");
            this.TongThanhToan.Size = new System.Drawing.Size(336, 36);
            this.TongThanhToan.TabIndex = 73;
            // 
            // LabelControl10
            // 
            this.LabelControl10.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.LabelControl10.Appearance.ForeColor = System.Drawing.Color.Red;
            this.LabelControl10.Appearance.Options.UseFont = true;
            this.LabelControl10.Appearance.Options.UseForeColor = true;
            this.LabelControl10.Location = new System.Drawing.Point(8, 307);
            this.LabelControl10.Name = "LabelControl10";
            this.LabelControl10.Size = new System.Drawing.Size(178, 30);
            this.LabelControl10.TabIndex = 72;
            this.LabelControl10.Text = "Tổng Thanh Toán";
            // 
            // LabelControl9
            // 
            this.LabelControl9.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.LabelControl9.Appearance.ForeColor = System.Drawing.Color.Green;
            this.LabelControl9.Appearance.Options.UseFont = true;
            this.LabelControl9.Appearance.Options.UseForeColor = true;
            this.LabelControl9.Location = new System.Drawing.Point(8, 249);
            this.LabelControl9.Name = "LabelControl9";
            this.LabelControl9.Size = new System.Drawing.Size(129, 30);
            this.LabelControl9.TabIndex = 70;
            this.LabelControl9.Text = "Giảm Giá(%)";
            // 
            // DonViTinh_LC
            // 
            this.DonViTinh_LC.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.DonViTinh_LC.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.DonViTinh_LC.Appearance.Options.UseFont = true;
            this.DonViTinh_LC.Appearance.Options.UseForeColor = true;
            this.DonViTinh_LC.Location = new System.Drawing.Point(105, 139);
            this.DonViTinh_LC.Name = "DonViTinh_LC";
            this.DonViTinh_LC.Size = new System.Drawing.Size(7, 30);
            this.DonViTinh_LC.TabIndex = 69;
            this.DonViTinh_LC.Text = "!";
            // 
            // NutHuyBo
            // 
            this.NutHuyBo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutHuyBo.EditValue = global::GUILAYER.Properties.Resources.Cancellation;
            this.NutHuyBo.Location = new System.Drawing.Point(289, 361);
            this.NutHuyBo.Margin = new System.Windows.Forms.Padding(6);
            this.NutHuyBo.Name = "NutHuyBo";
            this.NutHuyBo.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.NutHuyBo.Properties.ShowMenu = false;
            this.NutHuyBo.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Zoom;
            this.NutHuyBo.Size = new System.Drawing.Size(150, 150);
            this.NutHuyBo.TabIndex = 68;
            this.NutHuyBo.Click += new System.EventHandler(this.NutHuyBo_Click);
            // 
            // NutDatPhong
            // 
            this.NutDatPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutDatPhong.EditValue = global::GUILAYER.Properties.Resources.Reservation;
            this.NutDatPhong.Location = new System.Drawing.Point(473, 362);
            this.NutDatPhong.Margin = new System.Windows.Forms.Padding(5);
            this.NutDatPhong.Name = "NutDatPhong";
            this.NutDatPhong.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.NutDatPhong.Properties.ShowMenu = false;
            this.NutDatPhong.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Zoom;
            this.NutDatPhong.Size = new System.Drawing.Size(150, 150);
            this.NutDatPhong.TabIndex = 67;
            this.NutDatPhong.Click += new System.EventHandler(this.NutDatPhong_Click);
            // 
            // TienThanhToan
            // 
            this.TienThanhToan.Cursor = System.Windows.Forms.Cursors.No;
            this.TienThanhToan.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.TienThanhToan.Enabled = false;
            this.TienThanhToan.Location = new System.Drawing.Point(289, 193);
            this.TienThanhToan.Name = "TienThanhToan";
            this.TienThanhToan.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TienThanhToan.Properties.Appearance.Options.UseFont = true;
            this.TienThanhToan.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TienThanhToan.Properties.IsFloatValue = false;
            this.TienThanhToan.Properties.MaskSettings.Set("mask", "N00");
            this.TienThanhToan.Size = new System.Drawing.Size(336, 36);
            this.TienThanhToan.TabIndex = 66;
            this.TienThanhToan.EditValueChanged += new System.EventHandler(this.TienThanhToan_EditValueChanged);
            // 
            // ThoiHanPhongO
            // 
            this.ThoiHanPhongO.Cursor = System.Windows.Forms.Cursors.No;
            this.ThoiHanPhongO.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.ThoiHanPhongO.Enabled = false;
            this.ThoiHanPhongO.Location = new System.Drawing.Point(289, 136);
            this.ThoiHanPhongO.Name = "ThoiHanPhongO";
            this.ThoiHanPhongO.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.ThoiHanPhongO.Properties.Appearance.Options.UseFont = true;
            this.ThoiHanPhongO.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.ThoiHanPhongO.Properties.MaskSettings.Set("mask", "");
            this.ThoiHanPhongO.Size = new System.Drawing.Size(336, 36);
            this.ThoiHanPhongO.TabIndex = 65;
            this.ThoiHanPhongO.EditValueChanged += new System.EventHandler(this.ThoiHanPhongO_EditValueChanged);
            // 
            // TongGiaPhongO
            // 
            this.TongGiaPhongO.Cursor = System.Windows.Forms.Cursors.No;
            this.TongGiaPhongO.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.TongGiaPhongO.Enabled = false;
            this.TongGiaPhongO.Location = new System.Drawing.Point(289, 80);
            this.TongGiaPhongO.Name = "TongGiaPhongO";
            this.TongGiaPhongO.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TongGiaPhongO.Properties.Appearance.Options.UseFont = true;
            this.TongGiaPhongO.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TongGiaPhongO.Properties.IsFloatValue = false;
            this.TongGiaPhongO.Properties.MaskSettings.Set("mask", "N00");
            this.TongGiaPhongO.Size = new System.Drawing.Size(336, 36);
            this.TongGiaPhongO.TabIndex = 64;
            this.TongGiaPhongO.EditValueChanged += new System.EventHandler(this.TongGiaPhongO_EditValueChanged);
            // 
            // SoLuongPhongO
            // 
            this.SoLuongPhongO.Cursor = System.Windows.Forms.Cursors.No;
            this.SoLuongPhongO.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SoLuongPhongO.Enabled = false;
            this.SoLuongPhongO.Location = new System.Drawing.Point(289, 26);
            this.SoLuongPhongO.Name = "SoLuongPhongO";
            this.SoLuongPhongO.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoLuongPhongO.Properties.Appearance.Options.UseFont = true;
            this.SoLuongPhongO.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SoLuongPhongO.Properties.IsFloatValue = false;
            this.SoLuongPhongO.Properties.MaskSettings.Set("mask", "N00");
            this.SoLuongPhongO.Size = new System.Drawing.Size(336, 36);
            this.SoLuongPhongO.TabIndex = 63;
            // 
            // LabelControl8
            // 
            this.LabelControl8.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.LabelControl8.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LabelControl8.Appearance.Options.UseFont = true;
            this.LabelControl8.Appearance.Options.UseForeColor = true;
            this.LabelControl8.Location = new System.Drawing.Point(7, 196);
            this.LabelControl8.Name = "LabelControl8";
            this.LabelControl8.Size = new System.Drawing.Size(176, 30);
            this.LabelControl8.TabIndex = 61;
            this.LabelControl8.Text = "Tổng Tiền Phòng";
            // 
            // LabelControl7
            // 
            this.LabelControl7.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.LabelControl7.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LabelControl7.Appearance.Options.UseFont = true;
            this.LabelControl7.Appearance.Options.UseForeColor = true;
            this.LabelControl7.Location = new System.Drawing.Point(5, 139);
            this.LabelControl7.Name = "LabelControl7";
            this.LabelControl7.Size = new System.Drawing.Size(94, 30);
            this.LabelControl7.TabIndex = 60;
            this.LabelControl7.Text = "Thời Hạn";
            // 
            // LabelControl6
            // 
            this.LabelControl6.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.LabelControl6.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LabelControl6.Appearance.Options.UseFont = true;
            this.LabelControl6.Appearance.Options.UseForeColor = true;
            this.LabelControl6.Location = new System.Drawing.Point(5, 23);
            this.LabelControl6.Name = "LabelControl6";
            this.LabelControl6.Size = new System.Drawing.Size(171, 30);
            this.LabelControl6.TabIndex = 19;
            this.LabelControl6.Text = "Số Lượng Phòng";
            // 
            // LabelControl13
            // 
            this.LabelControl13.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.LabelControl13.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LabelControl13.Appearance.Options.UseFont = true;
            this.LabelControl13.Appearance.Options.UseForeColor = true;
            this.LabelControl13.Location = new System.Drawing.Point(5, 83);
            this.LabelControl13.Name = "LabelControl13";
            this.LabelControl13.Size = new System.Drawing.Size(173, 30);
            this.LabelControl13.TabIndex = 17;
            this.LabelControl13.Text = "Tiền Phòng Nghỉ";
            // 
            // BangPhongODaChon
            // 
            this.BangPhongODaChon.AllowDrop = true;
            this.BangPhongODaChon.AllowUserToAddRows = false;
            this.BangPhongODaChon.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.BangPhongODaChon.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.BangPhongODaChon.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BangPhongODaChon.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangPhongODaChon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.BangPhongODaChon.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangPhongODaChon.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BangPhongODaChon.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.BangPhongODaChon.ColumnHeadersHeight = 40;
            this.BangPhongODaChon.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MAPHONGODC,
            this.TENPHONGODC,
            this.TENLOAIPHONGDC,
            this.TIENTHEODDC,
            this.TIENTHEOHDC});
            this.BangPhongODaChon.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(41)))), ((int)(((byte)(62)))));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BangPhongODaChon.DefaultCellStyle = dataGridViewCellStyle5;
            this.BangPhongODaChon.Dock = System.Windows.Forms.DockStyle.Top;
            this.BangPhongODaChon.EnableHeadersVisualStyles = false;
            this.BangPhongODaChon.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangPhongODaChon.Location = new System.Drawing.Point(0, 0);
            this.BangPhongODaChon.MultiSelect = false;
            this.BangPhongODaChon.Name = "BangPhongODaChon";
            this.BangPhongODaChon.ReadOnly = true;
            this.BangPhongODaChon.RowHeadersVisible = false;
            this.BangPhongODaChon.RowHeadersWidth = 51;
            this.BangPhongODaChon.RowTemplate.Height = 40;
            this.BangPhongODaChon.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.BangPhongODaChon.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BangPhongODaChon.Size = new System.Drawing.Size(634, 450);
            this.BangPhongODaChon.TabIndex = 14;
            this.BangPhongODaChon.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.LightGrid;
            this.BangPhongODaChon.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.BangPhongODaChon.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.BangPhongODaChon.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.BangPhongODaChon.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.BangPhongODaChon.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.BangPhongODaChon.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangPhongODaChon.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangPhongODaChon.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.BangPhongODaChon.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.BangPhongODaChon.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangPhongODaChon.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.BangPhongODaChon.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.BangPhongODaChon.ThemeStyle.HeaderStyle.Height = 40;
            this.BangPhongODaChon.ThemeStyle.ReadOnly = true;
            this.BangPhongODaChon.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.BangPhongODaChon.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangPhongODaChon.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangPhongODaChon.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(41)))), ((int)(((byte)(62)))));
            this.BangPhongODaChon.ThemeStyle.RowsStyle.Height = 40;
            this.BangPhongODaChon.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.BangPhongODaChon.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.BangPhongODaChon.DragDrop += new System.Windows.Forms.DragEventHandler(this.BangPhongODaChon_DragDrop);
            this.BangPhongODaChon.DragEnter += new System.Windows.Forms.DragEventHandler(this.BangPhongODaChon_DragEnter);
            this.BangPhongODaChon.MouseDown += new System.Windows.Forms.MouseEventHandler(this.BangPhongODaChon_MouseDown);
            // 
            // MAPHONGODC
            // 
            this.MAPHONGODC.DataPropertyName = "MAPHONG";
            this.MAPHONGODC.HeaderText = "MÃ PHÒNG";
            this.MAPHONGODC.MinimumWidth = 6;
            this.MAPHONGODC.Name = "MAPHONGODC";
            this.MAPHONGODC.ReadOnly = true;
            // 
            // TENPHONGODC
            // 
            this.TENPHONGODC.DataPropertyName = "TENPHONG";
            this.TENPHONGODC.HeaderText = "TÊN PHÒNG";
            this.TENPHONGODC.MinimumWidth = 6;
            this.TENPHONGODC.Name = "TENPHONGODC";
            this.TENPHONGODC.ReadOnly = true;
            // 
            // TENLOAIPHONGDC
            // 
            this.TENLOAIPHONGDC.DataPropertyName = "TENLOAIPHONG";
            this.TENLOAIPHONGDC.HeaderText = "LOẠI PHÒNG";
            this.TENLOAIPHONGDC.MinimumWidth = 6;
            this.TENLOAIPHONGDC.Name = "TENLOAIPHONGDC";
            this.TENLOAIPHONGDC.ReadOnly = true;
            // 
            // TIENTHEODDC
            // 
            this.TIENTHEODDC.DataPropertyName = "TIENTHEOD";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle3.Format = "N0";
            dataGridViewCellStyle3.NullValue = null;
            this.TIENTHEODDC.DefaultCellStyle = dataGridViewCellStyle3;
            this.TIENTHEODDC.HeaderText = "TIỀN NGÀY";
            this.TIENTHEODDC.MinimumWidth = 6;
            this.TIENTHEODDC.Name = "TIENTHEODDC";
            this.TIENTHEODDC.ReadOnly = true;
            this.TIENTHEODDC.Visible = false;
            // 
            // TIENTHEOHDC
            // 
            this.TIENTHEOHDC.DataPropertyName = "TIENTHEOH";
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle4.Format = "N0";
            dataGridViewCellStyle4.NullValue = null;
            this.TIENTHEOHDC.DefaultCellStyle = dataGridViewCellStyle4;
            this.TIENTHEOHDC.HeaderText = "TIỀN GIỜ";
            this.TIENTHEOHDC.MinimumWidth = 6;
            this.TIENTHEOHDC.Name = "TIENTHEOHDC";
            this.TIENTHEOHDC.ReadOnly = true;
            this.TIENTHEOHDC.Visible = false;
            // 
            // PanelControl8
            // 
            this.PanelControl8.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.PanelControl8.Controls.Add(this.PanelControl7);
            this.PanelControl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl8.Location = new System.Drawing.Point(1283, 3);
            this.PanelControl8.Name = "PanelControl8";
            this.PanelControl8.Size = new System.Drawing.Size(634, 977);
            this.PanelControl8.TabIndex = 2;
            // 
            // PanelControl1
            // 
            this.PanelControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.PanelControl1.Controls.Add(this.BangPhongOBanDau);
            this.PanelControl1.Controls.Add(this.PanelControl2);
            this.PanelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl1.Location = new System.Drawing.Point(643, 3);
            this.PanelControl1.Name = "PanelControl1";
            this.PanelControl1.Size = new System.Drawing.Size(634, 977);
            this.PanelControl1.TabIndex = 4;
            // 
            // BangPhongOBanDau
            // 
            this.BangPhongOBanDau.AllowUserToAddRows = false;
            this.BangPhongOBanDau.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            this.BangPhongOBanDau.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.BangPhongOBanDau.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BangPhongOBanDau.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangPhongOBanDau.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.BangPhongOBanDau.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangPhongOBanDau.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BangPhongOBanDau.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.BangPhongOBanDau.ColumnHeadersHeight = 40;
            this.BangPhongOBanDau.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MAPHONGOBD,
            this.TENPHONGOBD,
            this.OtherColumns01,
            this.OtherColumns02,
            this.OtherColumns03,
            this.TENLOAIPHONGBD,
            this.OtherColmns05,
            this.OtherColumns06,
            this.MATRANGTHAIPO,
            this.OtherColumns08,
            this.TIENTHEODBD,
            this.TIENTHEOHBD});
            this.BangPhongOBanDau.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(41)))), ((int)(((byte)(62)))));
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BangPhongOBanDau.DefaultCellStyle = dataGridViewCellStyle10;
            this.BangPhongOBanDau.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BangPhongOBanDau.EnableHeadersVisualStyles = false;
            this.BangPhongOBanDau.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangPhongOBanDau.Location = new System.Drawing.Point(0, 259);
            this.BangPhongOBanDau.MultiSelect = false;
            this.BangPhongOBanDau.Name = "BangPhongOBanDau";
            this.BangPhongOBanDau.ReadOnly = true;
            this.BangPhongOBanDau.RowHeadersVisible = false;
            this.BangPhongOBanDau.RowHeadersWidth = 51;
            this.BangPhongOBanDau.RowTemplate.Height = 40;
            this.BangPhongOBanDau.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.BangPhongOBanDau.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BangPhongOBanDau.Size = new System.Drawing.Size(634, 718);
            this.BangPhongOBanDau.TabIndex = 13;
            this.BangPhongOBanDau.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.LightGrid;
            this.BangPhongOBanDau.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.BangPhongOBanDau.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.BangPhongOBanDau.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.BangPhongOBanDau.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.BangPhongOBanDau.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.BangPhongOBanDau.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangPhongOBanDau.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangPhongOBanDau.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.BangPhongOBanDau.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.BangPhongOBanDau.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangPhongOBanDau.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.BangPhongOBanDau.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.BangPhongOBanDau.ThemeStyle.HeaderStyle.Height = 40;
            this.BangPhongOBanDau.ThemeStyle.ReadOnly = true;
            this.BangPhongOBanDau.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.BangPhongOBanDau.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangPhongOBanDau.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangPhongOBanDau.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(41)))), ((int)(((byte)(62)))));
            this.BangPhongOBanDau.ThemeStyle.RowsStyle.Height = 40;
            this.BangPhongOBanDau.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.BangPhongOBanDau.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.BangPhongOBanDau.MouseDown += new System.Windows.Forms.MouseEventHandler(this.BangPhongOBanDau_MouseDown);
            // 
            // MAPHONGOBD
            // 
            this.MAPHONGOBD.DataPropertyName = "MAPHONG";
            this.MAPHONGOBD.HeaderText = "MÃ PHÒNG";
            this.MAPHONGOBD.MinimumWidth = 6;
            this.MAPHONGOBD.Name = "MAPHONGOBD";
            this.MAPHONGOBD.ReadOnly = true;
            // 
            // TENPHONGOBD
            // 
            this.TENPHONGOBD.DataPropertyName = "TENPHONG";
            this.TENPHONGOBD.HeaderText = "TÊN PHÒNG";
            this.TENPHONGOBD.MinimumWidth = 6;
            this.TENPHONGOBD.Name = "TENPHONGOBD";
            this.TENPHONGOBD.ReadOnly = true;
            // 
            // OtherColumns01
            // 
            this.OtherColumns01.DataPropertyName = "TENTANG";
            this.OtherColumns01.HeaderText = "TÊN TẦNG";
            this.OtherColumns01.MinimumWidth = 6;
            this.OtherColumns01.Name = "OtherColumns01";
            this.OtherColumns01.ReadOnly = true;
            this.OtherColumns01.Visible = false;
            // 
            // OtherColumns02
            // 
            this.OtherColumns02.DataPropertyName = "TANGTHU";
            this.OtherColumns02.HeaderText = "TẦNG THỨ";
            this.OtherColumns02.MinimumWidth = 6;
            this.OtherColumns02.Name = "OtherColumns02";
            this.OtherColumns02.ReadOnly = true;
            this.OtherColumns02.Visible = false;
            // 
            // OtherColumns03
            // 
            this.OtherColumns03.DataPropertyName = "MALOAIPHONG";
            this.OtherColumns03.HeaderText = "MÃ LOẠI PHÒNG";
            this.OtherColumns03.MinimumWidth = 6;
            this.OtherColumns03.Name = "OtherColumns03";
            this.OtherColumns03.ReadOnly = true;
            this.OtherColumns03.Visible = false;
            // 
            // TENLOAIPHONGBD
            // 
            this.TENLOAIPHONGBD.DataPropertyName = "TENLOAIPHONG";
            this.TENLOAIPHONGBD.HeaderText = "LOẠI PHÒNG";
            this.TENLOAIPHONGBD.MinimumWidth = 6;
            this.TENLOAIPHONGBD.Name = "TENLOAIPHONGBD";
            this.TENLOAIPHONGBD.ReadOnly = true;
            // 
            // OtherColmns05
            // 
            this.OtherColmns05.DataPropertyName = "MATINHTRANG";
            this.OtherColmns05.HeaderText = "MÃ TÌNH TRẠNG";
            this.OtherColmns05.MinimumWidth = 6;
            this.OtherColmns05.Name = "OtherColmns05";
            this.OtherColmns05.ReadOnly = true;
            this.OtherColmns05.Visible = false;
            // 
            // OtherColumns06
            // 
            this.OtherColumns06.DataPropertyName = "TENTINHTRANG";
            this.OtherColumns06.HeaderText = "TÌNH TRẠNG";
            this.OtherColumns06.MinimumWidth = 6;
            this.OtherColumns06.Name = "OtherColumns06";
            this.OtherColumns06.ReadOnly = true;
            this.OtherColumns06.Visible = false;
            // 
            // MATRANGTHAIPO
            // 
            this.MATRANGTHAIPO.DataPropertyName = "MATRANGTHAI";
            this.MATRANGTHAIPO.HeaderText = "MÃ TRẠNG THÁI";
            this.MATRANGTHAIPO.MinimumWidth = 6;
            this.MATRANGTHAIPO.Name = "MATRANGTHAIPO";
            this.MATRANGTHAIPO.ReadOnly = true;
            this.MATRANGTHAIPO.Visible = false;
            // 
            // OtherColumns08
            // 
            this.OtherColumns08.DataPropertyName = "TENTRANGTHAI";
            this.OtherColumns08.HeaderText = "TRẠNG THÁI";
            this.OtherColumns08.MinimumWidth = 6;
            this.OtherColumns08.Name = "OtherColumns08";
            this.OtherColumns08.ReadOnly = true;
            this.OtherColumns08.Visible = false;
            // 
            // TIENTHEODBD
            // 
            this.TIENTHEODBD.DataPropertyName = "TIENTHEOD";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "N0";
            dataGridViewCellStyle8.NullValue = null;
            this.TIENTHEODBD.DefaultCellStyle = dataGridViewCellStyle8;
            this.TIENTHEODBD.HeaderText = "TIỀN NGÀY";
            this.TIENTHEODBD.MinimumWidth = 6;
            this.TIENTHEODBD.Name = "TIENTHEODBD";
            this.TIENTHEODBD.ReadOnly = true;
            this.TIENTHEODBD.Visible = false;
            // 
            // TIENTHEOHBD
            // 
            this.TIENTHEOHBD.DataPropertyName = "TIENTHEOH";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N0";
            dataGridViewCellStyle9.NullValue = null;
            this.TIENTHEOHBD.DefaultCellStyle = dataGridViewCellStyle9;
            this.TIENTHEOHBD.HeaderText = "TIỀN GIỜ";
            this.TIENTHEOHBD.MinimumWidth = 6;
            this.TIENTHEOHBD.Name = "TIENTHEOHBD";
            this.TIENTHEOHBD.ReadOnly = true;
            this.TIENTHEOHBD.Visible = false;
            // 
            // PanelControl2
            // 
            this.PanelControl2.Controls.Add(this.PhongSearch);
            this.PanelControl2.Controls.Add(this.LabelControl5);
            this.PanelControl2.Controls.Add(this.TrangThaiPN_SLUE);
            this.PanelControl2.Controls.Add(this.LabelControl4);
            this.PanelControl2.Controls.Add(this.TinhTrangPN_SLUE);
            this.PanelControl2.Controls.Add(this.LabelControl3);
            this.PanelControl2.Controls.Add(this.Loai_SLUE);
            this.PanelControl2.Controls.Add(this.LabelControl2);
            this.PanelControl2.Controls.Add(this.Tang_SLUE);
            this.PanelControl2.Controls.Add(this.LabelControl1);
            this.PanelControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.PanelControl2.Location = new System.Drawing.Point(0, 0);
            this.PanelControl2.Name = "PanelControl2";
            this.PanelControl2.Size = new System.Drawing.Size(634, 259);
            this.PanelControl2.TabIndex = 1;
            // 
            // PhongSearch
            // 
            this.PhongSearch.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.PhongSearch.EditValue = "";
            this.PhongSearch.Location = new System.Drawing.Point(5, 208);
            this.PhongSearch.Name = "PhongSearch";
            this.PhongSearch.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.PhongSearch.Properties.Appearance.Options.UseFont = true;
            this.PhongSearch.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Repository.ClearButton(),
            new DevExpress.XtraEditors.Repository.SearchButton()});
            this.PhongSearch.Size = new System.Drawing.Size(290, 36);
            this.PhongSearch.TabIndex = 22;
            this.PhongSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.PhongNghiSearch_KeyDown);
            // 
            // LabelControl5
            // 
            this.LabelControl5.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl5.Appearance.Options.UseFont = true;
            this.LabelControl5.Location = new System.Drawing.Point(5, 172);
            this.LabelControl5.Name = "LabelControl5";
            this.LabelControl5.Size = new System.Drawing.Size(91, 30);
            this.LabelControl5.TabIndex = 23;
            this.LabelControl5.Text = "Tìm Kiếm";
            // 
            // TrangThaiPN_SLUE
            // 
            this.TrangThaiPN_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TrangThaiPN_SLUE.Location = new System.Drawing.Point(335, 124);
            this.TrangThaiPN_SLUE.Name = "TrangThaiPN_SLUE";
            this.TrangThaiPN_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TrangThaiPN_SLUE.Properties.Appearance.Options.UseFont = true;
            this.TrangThaiPN_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TrangThaiPN_SLUE.Properties.DisplayMember = "TENTRANGTHAI";
            this.TrangThaiPN_SLUE.Properties.NullText = "ALL";
            this.TrangThaiPN_SLUE.Properties.PopupView = this.GridView4;
            this.TrangThaiPN_SLUE.Properties.ValueMember = "MATRANGTHAI";
            this.TrangThaiPN_SLUE.Size = new System.Drawing.Size(290, 36);
            this.TrangThaiPN_SLUE.TabIndex = 20;
            this.TrangThaiPN_SLUE.EditValueChanged += new System.EventHandler(this.TrangThaiPN_EditValueChanged);
            // 
            // GridView4
            // 
            this.GridView4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView4.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView4.Appearance.Row.Options.UseFont = true;
            this.GridView4.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn7,
            this.GridColumn8});
            this.GridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView4.Name = "GridView4";
            this.GridView4.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView4.OptionsView.ShowGroupPanel = false;
            this.GridView4.OptionsView.ShowIndicator = false;
            this.GridView4.RowHeight = 40;
            // 
            // GridColumn7
            // 
            this.GridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn7.AppearanceHeader.Options.UseFont = true;
            this.GridColumn7.Caption = "TÊN TRẠNG THÁI";
            this.GridColumn7.FieldName = "TENTRANGTHAI";
            this.GridColumn7.Name = "GridColumn7";
            this.GridColumn7.Visible = true;
            this.GridColumn7.VisibleIndex = 0;
            // 
            // GridColumn8
            // 
            this.GridColumn8.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn8.AppearanceHeader.Options.UseFont = true;
            this.GridColumn8.Caption = "MÔ TẢ";
            this.GridColumn8.FieldName = "MOTA";
            this.GridColumn8.Name = "GridColumn8";
            this.GridColumn8.Visible = true;
            this.GridColumn8.VisibleIndex = 1;
            // 
            // LabelControl4
            // 
            this.LabelControl4.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl4.Appearance.Options.UseFont = true;
            this.LabelControl4.Location = new System.Drawing.Point(335, 88);
            this.LabelControl4.Name = "LabelControl4";
            this.LabelControl4.Size = new System.Drawing.Size(100, 30);
            this.LabelControl4.TabIndex = 21;
            this.LabelControl4.Text = "Trạng Thái";
            // 
            // TinhTrangPN_SLUE
            // 
            this.TinhTrangPN_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TinhTrangPN_SLUE.Location = new System.Drawing.Point(335, 40);
            this.TinhTrangPN_SLUE.Name = "TinhTrangPN_SLUE";
            this.TinhTrangPN_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TinhTrangPN_SLUE.Properties.Appearance.Options.UseFont = true;
            this.TinhTrangPN_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TinhTrangPN_SLUE.Properties.DisplayMember = "TENTINHTRANG";
            this.TinhTrangPN_SLUE.Properties.NullText = "ALL";
            this.TinhTrangPN_SLUE.Properties.PopupView = this.GridView3;
            this.TinhTrangPN_SLUE.Properties.ValueMember = "MATINHTRANG";
            this.TinhTrangPN_SLUE.Size = new System.Drawing.Size(290, 36);
            this.TinhTrangPN_SLUE.TabIndex = 18;
            this.TinhTrangPN_SLUE.EditValueChanged += new System.EventHandler(this.TinhTrangPN_EditValueChanged);
            // 
            // GridView3
            // 
            this.GridView3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView3.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView3.Appearance.Row.Options.UseFont = true;
            this.GridView3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn5,
            this.GridColumn6});
            this.GridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView3.Name = "GridView3";
            this.GridView3.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView3.OptionsView.ShowGroupPanel = false;
            this.GridView3.OptionsView.ShowIndicator = false;
            this.GridView3.RowHeight = 40;
            // 
            // GridColumn5
            // 
            this.GridColumn5.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn5.AppearanceHeader.Options.UseFont = true;
            this.GridColumn5.Caption = "TÊN TÌNH TRẠNG";
            this.GridColumn5.FieldName = "TENTINHTRANG";
            this.GridColumn5.Name = "GridColumn5";
            this.GridColumn5.Visible = true;
            this.GridColumn5.VisibleIndex = 0;
            // 
            // GridColumn6
            // 
            this.GridColumn6.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn6.AppearanceHeader.Options.UseFont = true;
            this.GridColumn6.Caption = "MÔ TẢ";
            this.GridColumn6.FieldName = "MOTA";
            this.GridColumn6.Name = "GridColumn6";
            this.GridColumn6.Visible = true;
            this.GridColumn6.VisibleIndex = 1;
            // 
            // LabelControl3
            // 
            this.LabelControl3.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl3.Appearance.Options.UseFont = true;
            this.LabelControl3.Location = new System.Drawing.Point(335, 4);
            this.LabelControl3.Name = "LabelControl3";
            this.LabelControl3.Size = new System.Drawing.Size(101, 30);
            this.LabelControl3.TabIndex = 19;
            this.LabelControl3.Text = "Tình Trạng";
            // 
            // Loai_SLUE
            // 
            this.Loai_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Loai_SLUE.Location = new System.Drawing.Point(5, 122);
            this.Loai_SLUE.Name = "Loai_SLUE";
            this.Loai_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.Loai_SLUE.Properties.Appearance.Options.UseFont = true;
            this.Loai_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.Loai_SLUE.Properties.DisplayMember = "TENLOAIPHONG";
            this.Loai_SLUE.Properties.NullText = "ALL";
            this.Loai_SLUE.Properties.PopupView = this.GridView2;
            this.Loai_SLUE.Properties.ValueMember = "MALOAIPHONG";
            this.Loai_SLUE.Size = new System.Drawing.Size(290, 36);
            this.Loai_SLUE.TabIndex = 16;
            this.Loai_SLUE.EditValueChanged += new System.EventHandler(this.Loai_SLUE_EditValueChanged);
            // 
            // GridView2
            // 
            this.GridView2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView2.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView2.Appearance.Row.Options.UseFont = true;
            this.GridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn3,
            this.GridColumn4});
            this.GridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView2.Name = "GridView2";
            this.GridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView2.OptionsView.ShowGroupPanel = false;
            this.GridView2.OptionsView.ShowIndicator = false;
            this.GridView2.RowHeight = 40;
            // 
            // GridColumn3
            // 
            this.GridColumn3.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn3.AppearanceHeader.Options.UseFont = true;
            this.GridColumn3.Caption = "TÊN LOẠI";
            this.GridColumn3.FieldName = "TENLOAIPHONG";
            this.GridColumn3.Name = "GridColumn3";
            this.GridColumn3.Visible = true;
            this.GridColumn3.VisibleIndex = 0;
            // 
            // GridColumn4
            // 
            this.GridColumn4.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn4.AppearanceHeader.Options.UseFont = true;
            this.GridColumn4.Caption = "MÔ TẢ";
            this.GridColumn4.FieldName = "MOTA";
            this.GridColumn4.Name = "GridColumn4";
            this.GridColumn4.Visible = true;
            this.GridColumn4.VisibleIndex = 1;
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Location = new System.Drawing.Point(5, 86);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(39, 30);
            this.LabelControl2.TabIndex = 17;
            this.LabelControl2.Text = "Loại";
            // 
            // Tang_SLUE
            // 
            this.Tang_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Tang_SLUE.Location = new System.Drawing.Point(5, 40);
            this.Tang_SLUE.Name = "Tang_SLUE";
            this.Tang_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.Tang_SLUE.Properties.Appearance.Options.UseFont = true;
            this.Tang_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.Tang_SLUE.Properties.DisplayMember = "TENTANG";
            this.Tang_SLUE.Properties.NullText = "ALL";
            this.Tang_SLUE.Properties.PopupView = this.GridView1;
            this.Tang_SLUE.Properties.ValueMember = "TANGTHU";
            this.Tang_SLUE.Size = new System.Drawing.Size(290, 36);
            this.Tang_SLUE.TabIndex = 14;
            this.Tang_SLUE.EditValueChanged += new System.EventHandler(this.Tang_SLUE_EditValueChanged);
            // 
            // GridView1
            // 
            this.GridView1.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView1.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView1.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView1.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView1.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView1.Appearance.Row.Options.UseFont = true;
            this.GridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn1,
            this.GridColumn2});
            this.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView1.Name = "GridView1";
            this.GridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView1.OptionsView.ShowGroupPanel = false;
            this.GridView1.OptionsView.ShowIndicator = false;
            this.GridView1.RowHeight = 40;
            // 
            // GridColumn1
            // 
            this.GridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn1.AppearanceHeader.Options.UseFont = true;
            this.GridColumn1.Caption = "TÊN TẦNG";
            this.GridColumn1.FieldName = "TENTANG";
            this.GridColumn1.Name = "GridColumn1";
            this.GridColumn1.Visible = true;
            this.GridColumn1.VisibleIndex = 0;
            // 
            // GridColumn2
            // 
            this.GridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn2.AppearanceHeader.Options.UseFont = true;
            this.GridColumn2.Caption = "TẦNG THỨ";
            this.GridColumn2.FieldName = "TANGTHU";
            this.GridColumn2.Name = "GridColumn2";
            this.GridColumn2.Visible = true;
            this.GridColumn2.VisibleIndex = 1;
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(5, 5);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(48, 30);
            this.LabelControl1.TabIndex = 15;
            this.LabelControl1.Text = "Tầng";
            // 
            // LayoutPanel
            // 
            this.LayoutPanel.ColumnCount = 3;
            this.LayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.LayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.LayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.LayoutPanel.Controls.Add(this.PanelControl1, 1, 0);
            this.LayoutPanel.Controls.Add(this.PanelControl4, 0, 0);
            this.LayoutPanel.Controls.Add(this.PanelControl8, 2, 0);
            this.LayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.LayoutPanel.Name = "LayoutPanel";
            this.LayoutPanel.RowCount = 1;
            this.LayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.LayoutPanel.Size = new System.Drawing.Size(1920, 983);
            this.LayoutPanel.TabIndex = 1;
            // 
            // PanelControl4
            // 
            this.PanelControl4.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.PanelControl4.Controls.Add(this.GroupControl3);
            this.PanelControl4.Controls.Add(this.GroupControl4);
            this.PanelControl4.Controls.Add(this.GroupControl2);
            this.PanelControl4.Controls.Add(this.GroupControl1);
            this.PanelControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl4.Location = new System.Drawing.Point(3, 3);
            this.PanelControl4.Name = "PanelControl4";
            this.PanelControl4.Size = new System.Drawing.Size(634, 977);
            this.PanelControl4.TabIndex = 3;
            // 
            // GroupControl3
            // 
            this.GroupControl3.Controls.Add(this.TimeOfPayment);
            this.GroupControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GroupControl3.Location = new System.Drawing.Point(0, 867);
            this.GroupControl3.Name = "GroupControl3";
            this.GroupControl3.Size = new System.Drawing.Size(634, 110);
            this.GroupControl3.TabIndex = 4;
            this.GroupControl3.Text = "LOẠI THANH TOÁN";
            // 
            // TimeOfPayment
            // 
            this.TimeOfPayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TimeOfPayment.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TimeOfPayment.EditValue = "PAYNOW";
            this.TimeOfPayment.Location = new System.Drawing.Point(2, 33);
            this.TimeOfPayment.Name = "TimeOfPayment";
            this.TimeOfPayment.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TimeOfPayment.Properties.Appearance.Options.UseFont = true;
            this.TimeOfPayment.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.TimeOfPayment.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Default;
            this.TimeOfPayment.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("PAYNOW", "THANH TOÁN KHI LẤY PHÒNG"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("PAYLATER", "THANH TOÁN KHI TRẢ PHÒNG")});
            this.TimeOfPayment.Properties.Padding = new System.Windows.Forms.Padding(10, 4, 4, 4);
            this.TimeOfPayment.Size = new System.Drawing.Size(630, 75);
            this.TimeOfPayment.TabIndex = 1;
            // 
            // GroupControl4
            // 
            this.GroupControl4.Controls.Add(this.ThongBaoDichVu);
            this.GroupControl4.Dock = System.Windows.Forms.DockStyle.Top;
            this.GroupControl4.Location = new System.Drawing.Point(0, 780);
            this.GroupControl4.Name = "GroupControl4";
            this.GroupControl4.Size = new System.Drawing.Size(634, 87);
            this.GroupControl4.TabIndex = 3;
            this.GroupControl4.Text = "LOẠI THÔNG BÁO";
            // 
            // ThongBaoDichVu
            // 
            this.ThongBaoDichVu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ThongBaoDichVu.EditValue = "GMAILBOX";
            this.ThongBaoDichVu.Location = new System.Drawing.Point(2, 33);
            this.ThongBaoDichVu.Margin = new System.Windows.Forms.Padding(4);
            this.ThongBaoDichVu.Name = "ThongBaoDichVu";
            this.ThongBaoDichVu.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThongBaoDichVu.Properties.Appearance.Options.UseFont = true;
            this.ThongBaoDichVu.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.ThongBaoDichVu.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("GMAILBOX", "THÔNG BÁO GMAIL"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("NONE", "KHÔNG THÔNG BÁO")});
            this.ThongBaoDichVu.Properties.Padding = new System.Windows.Forms.Padding(10, 4, 4, 4);
            this.ThongBaoDichVu.Size = new System.Drawing.Size(630, 52);
            this.ThongBaoDichVu.TabIndex = 0;
            // 
            // GroupControl2
            // 
            this.GroupControl2.Controls.Add(this.ChuThich);
            this.GroupControl2.Controls.Add(this.SoPhut_SE);
            this.GroupControl2.Controls.Add(this.SoGio_SE);
            this.GroupControl2.Controls.Add(this.SoNgay_SE);
            this.GroupControl2.Controls.Add(this.NutThemKhachHang);
            this.GroupControl2.Controls.Add(this.KhachHang_SLUE);
            this.GroupControl2.Controls.Add(this.GioTra_TE);
            this.GroupControl2.Controls.Add(this.GioLay_TE);
            this.GroupControl2.Controls.Add(this.NgayTra_DE);
            this.GroupControl2.Controls.Add(this.NgayLay_DE);
            this.GroupControl2.Controls.Add(this.LabelControl26);
            this.GroupControl2.Controls.Add(this.LabelControl25);
            this.GroupControl2.Controls.Add(this.LabelControl24);
            this.GroupControl2.Controls.Add(this.LabelControl23);
            this.GroupControl2.Controls.Add(this.LabelControl22);
            this.GroupControl2.Controls.Add(this.LabelControl20);
            this.GroupControl2.Controls.Add(this.LabelControl21);
            this.GroupControl2.Controls.Add(this.LabelControl19);
            this.GroupControl2.Controls.Add(this.LoaiHinh_SLUE);
            this.GroupControl2.Controls.Add(this.LabelControl18);
            this.GroupControl2.Controls.Add(this.LabelControl17);
            this.GroupControl2.Controls.Add(this.LabelControl16);
            this.GroupControl2.Dock = System.Windows.Forms.DockStyle.Top;
            this.GroupControl2.Location = new System.Drawing.Point(0, 76);
            this.GroupControl2.Name = "GroupControl2";
            this.GroupControl2.Size = new System.Drawing.Size(634, 704);
            this.GroupControl2.TabIndex = 1;
            this.GroupControl2.Text = "THÔNG TIN ĐẶT";
            // 
            // ChuThich
            // 
            this.ChuThich.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.ChuThich.Location = new System.Drawing.Point(14, 491);
            this.ChuThich.Name = "ChuThich";
            this.ChuThich.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 13.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChuThich.Properties.Appearance.Options.UseFont = true;
            this.ChuThich.Properties.MaxLength = 99;
            this.ChuThich.Size = new System.Drawing.Size(609, 180);
            this.ChuThich.TabIndex = 59;
            // 
            // SoPhut_SE
            // 
            this.SoPhut_SE.Cursor = System.Windows.Forms.Cursors.No;
            this.SoPhut_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SoPhut_SE.Enabled = false;
            this.SoPhut_SE.Location = new System.Drawing.Point(499, 402);
            this.SoPhut_SE.Name = "SoPhut_SE";
            this.SoPhut_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoPhut_SE.Properties.Appearance.Options.UseFont = true;
            this.SoPhut_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SoPhut_SE.Size = new System.Drawing.Size(75, 36);
            this.SoPhut_SE.TabIndex = 58;
            // 
            // SoGio_SE
            // 
            this.SoGio_SE.Cursor = System.Windows.Forms.Cursors.No;
            this.SoGio_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SoGio_SE.Enabled = false;
            this.SoGio_SE.Location = new System.Drawing.Point(333, 402);
            this.SoGio_SE.Name = "SoGio_SE";
            this.SoGio_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoGio_SE.Properties.Appearance.Options.UseFont = true;
            this.SoGio_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SoGio_SE.Size = new System.Drawing.Size(75, 36);
            this.SoGio_SE.TabIndex = 57;
            // 
            // SoNgay_SE
            // 
            this.SoNgay_SE.Cursor = System.Windows.Forms.Cursors.No;
            this.SoNgay_SE.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SoNgay_SE.Enabled = false;
            this.SoNgay_SE.Location = new System.Drawing.Point(151, 402);
            this.SoNgay_SE.Name = "SoNgay_SE";
            this.SoNgay_SE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoNgay_SE.Properties.Appearance.Options.UseFont = true;
            this.SoNgay_SE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SoNgay_SE.Size = new System.Drawing.Size(75, 36);
            this.SoNgay_SE.TabIndex = 56;
            // 
            // NutThemKhachHang
            // 
            this.NutThemKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutThemKhachHang.EditValue = global::GUILAYER.Properties.Resources.AddGuest;
            this.NutThemKhachHang.Location = new System.Drawing.Point(391, 46);
            this.NutThemKhachHang.Margin = new System.Windows.Forms.Padding(4);
            this.NutThemKhachHang.Name = "NutThemKhachHang";
            this.NutThemKhachHang.Properties.ShowCameraMenuItem = DevExpress.XtraEditors.Controls.CameraMenuItemVisibility.Auto;
            this.NutThemKhachHang.Properties.ShowMenu = false;
            this.NutThemKhachHang.Properties.SizeMode = DevExpress.XtraEditors.Controls.PictureSizeMode.Zoom;
            this.NutThemKhachHang.Size = new System.Drawing.Size(150, 150);
            this.NutThemKhachHang.TabIndex = 55;
            this.NutThemKhachHang.Click += new System.EventHandler(this.NutThemKhachHang_Click);
            // 
            // KhachHang_SLUE
            // 
            this.KhachHang_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.KhachHang_SLUE.Location = new System.Drawing.Point(14, 74);
            this.KhachHang_SLUE.Name = "KhachHang_SLUE";
            this.KhachHang_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.KhachHang_SLUE.Properties.Appearance.Options.UseFont = true;
            this.KhachHang_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.KhachHang_SLUE.Properties.DisplayMember = "HOVATEN";
            this.KhachHang_SLUE.Properties.PopupView = this.GridView9;
            this.KhachHang_SLUE.Properties.ValueMember = "IDKHACH";
            this.KhachHang_SLUE.Size = new System.Drawing.Size(290, 36);
            this.KhachHang_SLUE.TabIndex = 17;
            // 
            // GridView9
            // 
            this.GridView9.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView9.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView9.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView9.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView9.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView9.Appearance.Row.Options.UseFont = true;
            this.GridView9.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn17,
            this.GridColumn18});
            this.GridView9.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView9.Name = "GridView9";
            this.GridView9.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView9.OptionsView.ShowGroupPanel = false;
            this.GridView9.OptionsView.ShowIndicator = false;
            this.GridView9.RowHeight = 40;
            // 
            // GridColumn17
            // 
            this.GridColumn17.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn17.AppearanceHeader.Options.UseFont = true;
            this.GridColumn17.Caption = "ID KHÁCH";
            this.GridColumn17.FieldName = "IDKHACH";
            this.GridColumn17.Name = "GridColumn17";
            this.GridColumn17.Visible = true;
            this.GridColumn17.VisibleIndex = 0;
            // 
            // GridColumn18
            // 
            this.GridColumn18.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn18.AppearanceHeader.Options.UseFont = true;
            this.GridColumn18.Caption = "HỌ VÀ TÊN";
            this.GridColumn18.FieldName = "HOVATEN";
            this.GridColumn18.Name = "GridColumn18";
            this.GridColumn18.Visible = true;
            this.GridColumn18.VisibleIndex = 1;
            // 
            // GioTra_TE
            // 
            this.GioTra_TE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GioTra_TE.EditValue = new System.DateTime(2024, 9, 28, 0, 0, 0, 0);
            this.GioTra_TE.Location = new System.Drawing.Point(333, 346);
            this.GioTra_TE.Name = "GioTra_TE";
            this.GioTra_TE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.GioTra_TE.Properties.Appearance.Options.UseFont = true;
            this.GioTra_TE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.GioTra_TE.Properties.MaskSettings.Set("mask", "t");
            this.GioTra_TE.Properties.UseMaskAsDisplayFormat = true;
            this.GioTra_TE.Size = new System.Drawing.Size(290, 36);
            this.GioTra_TE.TabIndex = 51;
            this.GioTra_TE.EditValueChanged += new System.EventHandler(this.GioTra_TE_EditValueChanged);
            // 
            // GioLay_TE
            // 
            this.GioLay_TE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.GioLay_TE.EditValue = new System.DateTime(2024, 9, 28, 0, 0, 0, 0);
            this.GioLay_TE.Location = new System.Drawing.Point(333, 253);
            this.GioLay_TE.Name = "GioLay_TE";
            this.GioLay_TE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.GioLay_TE.Properties.Appearance.Options.UseFont = true;
            this.GioLay_TE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.GioLay_TE.Properties.MaskSettings.Set("mask", "t");
            this.GioLay_TE.Properties.UseMaskAsDisplayFormat = true;
            this.GioLay_TE.Size = new System.Drawing.Size(290, 36);
            this.GioLay_TE.TabIndex = 50;
            this.GioLay_TE.EditValueChanged += new System.EventHandler(this.GioLay_TE_EditValueChanged);
            // 
            // NgayTra_DE
            // 
            this.NgayTra_DE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NgayTra_DE.EditValue = new System.DateOnly(2024, 9, 28);
            this.NgayTra_DE.Location = new System.Drawing.Point(14, 346);
            this.NgayTra_DE.Name = "NgayTra_DE";
            this.NgayTra_DE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NgayTra_DE.Properties.Appearance.Options.UseFont = true;
            this.NgayTra_DE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.NgayTra_DE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.NgayTra_DE.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Fluent;
            this.NgayTra_DE.Properties.MaskSettings.Set("mask", "d");
            this.NgayTra_DE.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.NgayTra_DE.Properties.UseMaskAsDisplayFormat = true;
            this.NgayTra_DE.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.False;
            this.NgayTra_DE.Size = new System.Drawing.Size(290, 36);
            this.NgayTra_DE.TabIndex = 49;
            this.NgayTra_DE.EditValueChanged += new System.EventHandler(this.NgayTra_DE_EditValueChanged);
            // 
            // NgayLay_DE
            // 
            this.NgayLay_DE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NgayLay_DE.EditValue = new System.DateOnly(2024, 9, 28);
            this.NgayLay_DE.Location = new System.Drawing.Point(14, 253);
            this.NgayLay_DE.Name = "NgayLay_DE";
            this.NgayLay_DE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NgayLay_DE.Properties.Appearance.Options.UseFont = true;
            this.NgayLay_DE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.NgayLay_DE.Properties.CalendarTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.NgayLay_DE.Properties.CalendarView = DevExpress.XtraEditors.Repository.CalendarView.Fluent;
            this.NgayLay_DE.Properties.MaskSettings.Set("mask", "d");
            this.NgayLay_DE.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.NgayLay_DE.Properties.UseMaskAsDisplayFormat = true;
            this.NgayLay_DE.Properties.VistaDisplayMode = DevExpress.Utils.DefaultBoolean.False;
            this.NgayLay_DE.Size = new System.Drawing.Size(290, 36);
            this.NgayLay_DE.TabIndex = 48;
            this.NgayLay_DE.EditValueChanged += new System.EventHandler(this.NgayLay_DE_EditValueChanged);
            // 
            // LabelControl26
            // 
            this.LabelControl26.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl26.Appearance.Options.UseFont = true;
            this.LabelControl26.Location = new System.Drawing.Point(580, 405);
            this.LabelControl26.Name = "LabelControl26";
            this.LabelControl26.Size = new System.Drawing.Size(43, 30);
            this.LabelControl26.TabIndex = 47;
            this.LabelControl26.Text = "Phút";
            // 
            // LabelControl25
            // 
            this.LabelControl25.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl25.Appearance.Options.UseFont = true;
            this.LabelControl25.Location = new System.Drawing.Point(415, 405);
            this.LabelControl25.Name = "LabelControl25";
            this.LabelControl25.Size = new System.Drawing.Size(33, 30);
            this.LabelControl25.TabIndex = 45;
            this.LabelControl25.Text = "Giờ";
            // 
            // LabelControl24
            // 
            this.LabelControl24.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl24.Appearance.Options.UseFont = true;
            this.LabelControl24.Location = new System.Drawing.Point(232, 405);
            this.LabelControl24.Name = "LabelControl24";
            this.LabelControl24.Size = new System.Drawing.Size(51, 30);
            this.LabelControl24.TabIndex = 43;
            this.LabelControl24.Text = "Ngày";
            // 
            // LabelControl23
            // 
            this.LabelControl23.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl23.Appearance.Options.UseFont = true;
            this.LabelControl23.Location = new System.Drawing.Point(14, 405);
            this.LabelControl23.Name = "LabelControl23";
            this.LabelControl23.Size = new System.Drawing.Size(92, 30);
            this.LabelControl23.TabIndex = 40;
            this.LabelControl23.Text = "Thời Hạn:";
            // 
            // LabelControl22
            // 
            this.LabelControl22.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl22.Appearance.Options.UseFont = true;
            this.LabelControl22.Location = new System.Drawing.Point(333, 307);
            this.LabelControl22.Name = "LabelControl22";
            this.LabelControl22.Size = new System.Drawing.Size(136, 30);
            this.LabelControl22.TabIndex = 37;
            this.LabelControl22.Text = "Giờ Trả Phòng";
            // 
            // LabelControl20
            // 
            this.LabelControl20.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl20.Appearance.Options.UseFont = true;
            this.LabelControl20.Location = new System.Drawing.Point(333, 217);
            this.LabelControl20.Name = "LabelControl20";
            this.LabelControl20.Size = new System.Drawing.Size(139, 30);
            this.LabelControl20.TabIndex = 36;
            this.LabelControl20.Text = "Giờ Lấy Phòng";
            // 
            // LabelControl21
            // 
            this.LabelControl21.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl21.Appearance.Options.UseFont = true;
            this.LabelControl21.Location = new System.Drawing.Point(14, 450);
            this.LabelControl21.Name = "LabelControl21";
            this.LabelControl21.Size = new System.Drawing.Size(76, 30);
            this.LabelControl21.TabIndex = 34;
            this.LabelControl21.Text = "Ghi Chú";
            // 
            // LabelControl19
            // 
            this.LabelControl19.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl19.Appearance.Options.UseFont = true;
            this.LabelControl19.Location = new System.Drawing.Point(14, 307);
            this.LabelControl19.Name = "LabelControl19";
            this.LabelControl19.Size = new System.Drawing.Size(154, 30);
            this.LabelControl19.TabIndex = 30;
            this.LabelControl19.Text = "Ngày Trả Phòng";
            // 
            // LoaiHinh_SLUE
            // 
            this.LoaiHinh_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LoaiHinh_SLUE.Location = new System.Drawing.Point(14, 160);
            this.LoaiHinh_SLUE.Name = "LoaiHinh_SLUE";
            this.LoaiHinh_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LoaiHinh_SLUE.Properties.Appearance.Options.UseFont = true;
            this.LoaiHinh_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.LoaiHinh_SLUE.Properties.DisplayMember = "TENLOAIHINH";
            this.LoaiHinh_SLUE.Properties.PopupView = this.GridView8;
            this.LoaiHinh_SLUE.Properties.ValueMember = "MALOAIHINH";
            this.LoaiHinh_SLUE.Size = new System.Drawing.Size(290, 36);
            this.LoaiHinh_SLUE.TabIndex = 28;
            this.LoaiHinh_SLUE.EditValueChanged += new System.EventHandler(this.LoaiHinhDP_SLUE_EditValueChanged);
            // 
            // GridView8
            // 
            this.GridView8.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView8.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView8.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView8.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView8.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView8.Appearance.Row.Options.UseFont = true;
            this.GridView8.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn15,
            this.GridColumn16});
            this.GridView8.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView8.Name = "GridView8";
            this.GridView8.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView8.OptionsView.ShowGroupPanel = false;
            this.GridView8.OptionsView.ShowIndicator = false;
            this.GridView8.RowHeight = 40;
            // 
            // GridColumn15
            // 
            this.GridColumn15.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn15.AppearanceHeader.Options.UseFont = true;
            this.GridColumn15.Caption = "TÊN LOẠI HÌNH";
            this.GridColumn15.FieldName = "TENLOAIHINH";
            this.GridColumn15.Name = "GridColumn15";
            this.GridColumn15.Visible = true;
            this.GridColumn15.VisibleIndex = 0;
            // 
            // GridColumn16
            // 
            this.GridColumn16.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn16.AppearanceHeader.Options.UseFont = true;
            this.GridColumn16.Caption = "MÔ TẢ";
            this.GridColumn16.FieldName = "MOTA";
            this.GridColumn16.Name = "GridColumn16";
            this.GridColumn16.Visible = true;
            this.GridColumn16.VisibleIndex = 1;
            // 
            // LabelControl18
            // 
            this.LabelControl18.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl18.Appearance.Options.UseFont = true;
            this.LabelControl18.Location = new System.Drawing.Point(14, 124);
            this.LabelControl18.Name = "LabelControl18";
            this.LabelControl18.Size = new System.Drawing.Size(100, 30);
            this.LabelControl18.TabIndex = 29;
            this.LabelControl18.Text = "Hạng Mục";
            // 
            // LabelControl17
            // 
            this.LabelControl17.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl17.Appearance.Options.UseFont = true;
            this.LabelControl17.Location = new System.Drawing.Point(14, 217);
            this.LabelControl17.Name = "LabelControl17";
            this.LabelControl17.Size = new System.Drawing.Size(157, 30);
            this.LabelControl17.TabIndex = 18;
            this.LabelControl17.Text = "Ngày Lấy Phòng";
            // 
            // LabelControl16
            // 
            this.LabelControl16.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl16.Appearance.Options.UseFont = true;
            this.LabelControl16.Location = new System.Drawing.Point(14, 38);
            this.LabelControl16.Name = "LabelControl16";
            this.LabelControl16.Size = new System.Drawing.Size(116, 30);
            this.LabelControl16.TabIndex = 16;
            this.LabelControl16.Text = "Khách Hàng";
            // 
            // GroupControl1
            // 
            this.GroupControl1.Controls.Add(this.LoaiDatPhong);
            this.GroupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.GroupControl1.Location = new System.Drawing.Point(0, 0);
            this.GroupControl1.Name = "GroupControl1";
            this.GroupControl1.Size = new System.Drawing.Size(634, 76);
            this.GroupControl1.TabIndex = 0;
            this.GroupControl1.Text = "LOẠI ĐẶT PHÒNG";
            // 
            // LoaiDatPhong
            // 
            this.LoaiDatPhong.Cursor = System.Windows.Forms.Cursors.Hand;
            this.LoaiDatPhong.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LoaiDatPhong.EditValue = "RESERVATION";
            this.LoaiDatPhong.Location = new System.Drawing.Point(2, 33);
            this.LoaiDatPhong.Name = "LoaiDatPhong";
            this.LoaiDatPhong.Properties.Appearance.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoaiDatPhong.Properties.Appearance.Options.UseFont = true;
            this.LoaiDatPhong.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.LoaiDatPhong.Properties.GlyphAlignment = DevExpress.Utils.HorzAlignment.Default;
            this.LoaiDatPhong.Properties.Items.AddRange(new DevExpress.XtraEditors.Controls.RadioGroupItem[] {
            new DevExpress.XtraEditors.Controls.RadioGroupItem("RESERVATION", "ĐẶT TRƯỚC"),
            new DevExpress.XtraEditors.Controls.RadioGroupItem("IMMEDIATE", "LẤY NGAY")});
            this.LoaiDatPhong.Properties.Padding = new System.Windows.Forms.Padding(10, 4, 4, 4);
            this.LoaiDatPhong.Size = new System.Drawing.Size(630, 41);
            this.LoaiDatPhong.TabIndex = 0;
            this.LoaiDatPhong.SelectedIndexChanged += new System.EventHandler(this.LoaiDatPhong_SelectedIndexChanged);
            // 
            // Time
            // 
            this.Time.Enabled = true;
            this.Time.Interval = 1000;
            // 
            // ThongBaoDatPhong
            // 
            this.ThongBaoDatPhong.AllowHotTrack = false;
            this.ThongBaoDatPhong.AppearanceCaption.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThongBaoDatPhong.AppearanceCaption.Options.UseFont = true;
            this.ThongBaoDatPhong.AppearanceText.Font = new System.Drawing.Font("Verdana", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThongBaoDatPhong.AppearanceText.Options.UseFont = true;
            this.ThongBaoDatPhong.BeforeFormShow += new DevExpress.XtraBars.Alerter.AlertFormEventHandler(this.DinhDangKhungThongBao_BeforeFormShow);
            // 
            // ThongTinDatPhong
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1920, 983);
            this.Controls.Add(this.LayoutPanel);
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.IsMdiContainer = true;
            this.Name = "ThongTinDatPhong";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "THÔNG TIN PHÒNG ĐẶT";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ThongTinPhongDat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl7)).EndInit();
            this.PanelControl7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl3)).EndInit();
            this.PanelControl3.ResumeLayout(false);
            this.PanelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GiamGia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongThanhToan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NutHuyBo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NutDatPhong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TienThanhToan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThoiHanPhongO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongGiaPhongO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoLuongPhongO.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangPhongODaChon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl8)).EndInit();
            this.PanelControl8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl1)).EndInit();
            this.PanelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BangPhongOBanDau)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl2)).EndInit();
            this.PanelControl2.ResumeLayout(false);
            this.PanelControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PhongSearch.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThaiPN_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TinhTrangPN_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Loai_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tang_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).EndInit();
            this.LayoutPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl4)).EndInit();
            this.PanelControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl3)).EndInit();
            this.GroupControl3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.TimeOfPayment.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl4)).EndInit();
            this.GroupControl4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.ThongBaoDichVu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl2)).EndInit();
            this.GroupControl2.ResumeLayout(false);
            this.GroupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ChuThich.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoPhut_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoGio_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoNgay_SE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NutThemKhachHang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.KhachHang_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GioTra_TE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GioLay_TE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NgayTra_DE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NgayTra_DE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NgayLay_DE.Properties.CalendarTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.NgayLay_DE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.LoaiHinh_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GroupControl1)).EndInit();
            this.GroupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.LoaiDatPhong.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl PanelControl7;
        private DevExpress.XtraEditors.PanelControl PanelControl8;
        private System.Windows.Forms.TableLayoutPanel LayoutPanel;
        private DevExpress.XtraEditors.PanelControl PanelControl4;
        private DevExpress.XtraEditors.GroupControl GroupControl4;
        private DevExpress.XtraEditors.RadioGroup TimeOfPayment;
        private DevExpress.XtraEditors.GroupControl GroupControl2;
        private DevExpress.XtraEditors.SearchLookUpEdit KhachHang_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView9;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn18;
        private DevExpress.XtraEditors.TimeEdit GioTra_TE;
        private DevExpress.XtraEditors.TimeEdit GioLay_TE;
        private DevExpress.XtraEditors.DateEdit NgayTra_DE;
        private DevExpress.XtraEditors.DateEdit NgayLay_DE;
        private DevExpress.XtraEditors.LabelControl LabelControl26;
        private DevExpress.XtraEditors.LabelControl LabelControl25;
        private DevExpress.XtraEditors.LabelControl LabelControl24;
        private DevExpress.XtraEditors.LabelControl LabelControl23;
        private DevExpress.XtraEditors.LabelControl LabelControl22;
        private DevExpress.XtraEditors.LabelControl LabelControl20;
        private DevExpress.XtraEditors.LabelControl LabelControl21;
        private DevExpress.XtraEditors.LabelControl LabelControl19;
        private DevExpress.XtraEditors.SearchLookUpEdit LoaiHinh_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView8;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn15;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn16;
        private DevExpress.XtraEditors.LabelControl LabelControl18;
        private DevExpress.XtraEditors.LabelControl LabelControl17;
        private DevExpress.XtraEditors.LabelControl LabelControl16;
        private DevExpress.XtraEditors.GroupControl GroupControl1;
        private DevExpress.XtraEditors.RadioGroup LoaiDatPhong;
        private DevExpress.XtraEditors.PanelControl PanelControl1;
        private DevExpress.XtraEditors.PanelControl PanelControl2;
        private DevExpress.XtraEditors.SearchControl PhongSearch;
        private DevExpress.XtraEditors.LabelControl LabelControl5;
        private DevExpress.XtraEditors.SearchLookUpEdit TrangThaiPN_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView4;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn8;
        private DevExpress.XtraEditors.LabelControl LabelControl4;
        private DevExpress.XtraEditors.SearchLookUpEdit TinhTrangPN_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView3;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn6;
        private DevExpress.XtraEditors.LabelControl LabelControl3;
        private DevExpress.XtraEditors.SearchLookUpEdit Loai_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView2;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn4;
        private DevExpress.XtraEditors.LabelControl LabelControl2;
        private DevExpress.XtraEditors.SearchLookUpEdit Tang_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView1;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn2;
        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private Guna.UI2.WinForms.Guna2DataGridView BangPhongOBanDau;
        private Guna.UI2.WinForms.Guna2DataGridView BangPhongODaChon;
        private DevExpress.XtraEditors.GroupControl GroupControl3;
        private DevExpress.XtraEditors.PanelControl PanelControl3;
        private DevExpress.XtraEditors.LabelControl LabelControl13;
        private DevExpress.XtraEditors.LabelControl LabelControl6;
        private DevExpress.XtraEditors.LabelControl LabelControl8;
        private DevExpress.XtraEditors.LabelControl LabelControl7;
        private DevExpress.XtraEditors.SpinEdit SoLuongPhongO;
        private DevExpress.XtraEditors.SpinEdit ThoiHanPhongO;
        private DevExpress.XtraEditors.SpinEdit TongGiaPhongO;
        private DevExpress.XtraEditors.SpinEdit TienThanhToan;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONGODC;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENPHONGODC;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENLOAIPHONGDC;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIENTHEODDC;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIENTHEOHDC;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONGOBD;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENPHONGOBD;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherColumns01;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherColumns02;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherColumns03;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENLOAIPHONGBD;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherColmns05;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherColumns06;
        private System.Windows.Forms.DataGridViewTextBoxColumn MATRANGTHAIPO;
        private System.Windows.Forms.DataGridViewTextBoxColumn OtherColumns08;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIENTHEODBD;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIENTHEOHBD;
        private DevExpress.XtraEditors.PictureEdit NutThemKhachHang;
        private DevExpress.XtraEditors.PictureEdit NutHuyBo;
        private DevExpress.XtraEditors.PictureEdit NutDatPhong;
        private DevExpress.XtraEditors.LabelControl DonViTinh_LC;
        private DevExpress.XtraEditors.SpinEdit SoPhut_SE;
        private DevExpress.XtraEditors.SpinEdit SoGio_SE;
        private DevExpress.XtraEditors.SpinEdit SoNgay_SE;
        private System.Windows.Forms.Timer Time;
        private DevExpress.XtraBars.Alerter.AlertControl ThongBaoDatPhong;
        private DevExpress.XtraEditors.MemoEdit ChuThich;
        private DevExpress.XtraEditors.LabelControl LabelControl9;
        private DevExpress.XtraEditors.SpinEdit TongThanhToan;
        private DevExpress.XtraEditors.LabelControl LabelControl10;
        private DevExpress.XtraEditors.SpinEdit GiamGia;
        private DevExpress.XtraEditors.RadioGroup ThongBaoDichVu;
    }
}