﻿namespace GUILAYER
{
    partial class ThongTinTraPhongO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThongTinTraPhongO));
            this.LayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.PanelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.BangDuLieu = new Guna.UI2.WinForms.Guna2DataGridView();
            this.MAPHONGDAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MAPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYDAT = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYLAY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NGAYTRA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GIAPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MALOAIHINH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENLOAIHINH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MATRANGTHAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENTRANGTHAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GHICHU = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.THOIHAN = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PanelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.KhachHang_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView9 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn17 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn18 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.NutHuy = new DevExpress.XtraEditors.SimpleButton();
            this.NutOK = new DevExpress.XtraEditors.SimpleButton();
            this.TongTienPhong = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.SoPhongThanhToan = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.SoPhongDangDung = new DevExpress.XtraEditors.SpinEdit();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.LayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl1)).BeginInit();
            this.PanelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.BangDuLieu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl2)).BeginInit();
            this.PanelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KhachHang_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongTienPhong.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoPhongThanhToan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoPhongDangDung.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // LayoutPanel1
            // 
            this.LayoutPanel1.ColumnCount = 2;
            this.LayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 63.5F));
            this.LayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 36.5F));
            this.LayoutPanel1.Controls.Add(this.PanelControl1, 0, 0);
            this.LayoutPanel1.Controls.Add(this.PanelControl2, 1, 0);
            this.LayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.LayoutPanel1.Name = "LayoutPanel1";
            this.LayoutPanel1.RowCount = 1;
            this.LayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.LayoutPanel1.Size = new System.Drawing.Size(1200, 663);
            this.LayoutPanel1.TabIndex = 0;
            // 
            // PanelControl1
            // 
            this.PanelControl1.Controls.Add(this.BangDuLieu);
            this.PanelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl1.Location = new System.Drawing.Point(3, 3);
            this.PanelControl1.Name = "PanelControl1";
            this.PanelControl1.Size = new System.Drawing.Size(756, 657);
            this.PanelControl1.TabIndex = 8;
            // 
            // BangDuLieu
            // 
            this.BangDuLieu.AllowUserToAddRows = false;
            this.BangDuLieu.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
            this.BangDuLieu.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.BangDuLieu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BangDuLieu.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangDuLieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BangDuLieu.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangDuLieu.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BangDuLieu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.BangDuLieu.ColumnHeadersHeight = 40;
            this.BangDuLieu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MAPHONGDAT,
            this.TextBoxColumn1,
            this.TextBoxColumn2,
            this.MAPHONG,
            this.TENPHONG,
            this.NGAYDAT,
            this.NGAYLAY,
            this.NGAYTRA,
            this.GIAPHONG,
            this.MALOAIHINH,
            this.TENLOAIHINH,
            this.MATRANGTHAI,
            this.TENTRANGTHAI,
            this.GHICHU,
            this.THOIHAN});
            this.BangDuLieu.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BangDuLieu.DefaultCellStyle = dataGridViewCellStyle8;
            this.BangDuLieu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BangDuLieu.EnableHeadersVisualStyles = false;
            this.BangDuLieu.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangDuLieu.Location = new System.Drawing.Point(2, 2);
            this.BangDuLieu.Margin = new System.Windows.Forms.Padding(185, 175, 185, 175);
            this.BangDuLieu.Name = "BangDuLieu";
            this.BangDuLieu.ReadOnly = true;
            this.BangDuLieu.RowHeadersVisible = false;
            this.BangDuLieu.RowHeadersWidth = 51;
            this.BangDuLieu.RowTemplate.Height = 40;
            this.BangDuLieu.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.BangDuLieu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BangDuLieu.Size = new System.Drawing.Size(752, 653);
            this.BangDuLieu.TabIndex = 7;
            this.BangDuLieu.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.LightGrid;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.BangDuLieu.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangDuLieu.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangDuLieu.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.BangDuLieu.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.BangDuLieu.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangDuLieu.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.BangDuLieu.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.BangDuLieu.ThemeStyle.HeaderStyle.Height = 40;
            this.BangDuLieu.ThemeStyle.ReadOnly = true;
            this.BangDuLieu.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.BangDuLieu.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangDuLieu.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangDuLieu.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.BangDuLieu.ThemeStyle.RowsStyle.Height = 40;
            this.BangDuLieu.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.BangDuLieu.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.BangDuLieu.SelectionChanged += new System.EventHandler(this.DanhSachCacPhongDaChon);
            // 
            // MAPHONGDAT
            // 
            this.MAPHONGDAT.DataPropertyName = "MAPHONGDAT";
            this.MAPHONGDAT.HeaderText = "MÃ ĐẶT";
            this.MAPHONGDAT.MinimumWidth = 6;
            this.MAPHONGDAT.Name = "MAPHONGDAT";
            this.MAPHONGDAT.ReadOnly = true;
            this.MAPHONGDAT.Visible = false;
            // 
            // TextBoxColumn1
            // 
            this.TextBoxColumn1.DataPropertyName = "IDKHACH";
            this.TextBoxColumn1.HeaderText = "ID KHÁCH";
            this.TextBoxColumn1.MinimumWidth = 6;
            this.TextBoxColumn1.Name = "TextBoxColumn1";
            this.TextBoxColumn1.ReadOnly = true;
            this.TextBoxColumn1.Visible = false;
            // 
            // TextBoxColumn2
            // 
            this.TextBoxColumn2.DataPropertyName = "HOVATEN";
            this.TextBoxColumn2.HeaderText = "HỌ TÊN";
            this.TextBoxColumn2.MinimumWidth = 6;
            this.TextBoxColumn2.Name = "TextBoxColumn2";
            this.TextBoxColumn2.ReadOnly = true;
            this.TextBoxColumn2.Visible = false;
            // 
            // MAPHONG
            // 
            this.MAPHONG.DataPropertyName = "MAPHONG";
            this.MAPHONG.HeaderText = "MÃ PHÒNG";
            this.MAPHONG.MinimumWidth = 6;
            this.MAPHONG.Name = "MAPHONG";
            this.MAPHONG.ReadOnly = true;
            this.MAPHONG.Visible = false;
            // 
            // TENPHONG
            // 
            this.TENPHONG.DataPropertyName = "TENPHONG";
            this.TENPHONG.HeaderText = "TÊN PHÒNG";
            this.TENPHONG.MinimumWidth = 6;
            this.TENPHONG.Name = "TENPHONG";
            this.TENPHONG.ReadOnly = true;
            // 
            // NGAYDAT
            // 
            this.NGAYDAT.DataPropertyName = "NGAYDAT";
            dataGridViewCellStyle3.Format = "g";
            dataGridViewCellStyle3.NullValue = null;
            this.NGAYDAT.DefaultCellStyle = dataGridViewCellStyle3;
            this.NGAYDAT.HeaderText = "NGÀY ĐẶT";
            this.NGAYDAT.MinimumWidth = 6;
            this.NGAYDAT.Name = "NGAYDAT";
            this.NGAYDAT.ReadOnly = true;
            this.NGAYDAT.Visible = false;
            // 
            // NGAYLAY
            // 
            this.NGAYLAY.DataPropertyName = "NGAYLAY";
            dataGridViewCellStyle4.Format = "g";
            dataGridViewCellStyle4.NullValue = null;
            this.NGAYLAY.DefaultCellStyle = dataGridViewCellStyle4;
            this.NGAYLAY.HeaderText = "NGÀY LẤY";
            this.NGAYLAY.MinimumWidth = 6;
            this.NGAYLAY.Name = "NGAYLAY";
            this.NGAYLAY.ReadOnly = true;
            // 
            // NGAYTRA
            // 
            this.NGAYTRA.DataPropertyName = "NGAYTRA";
            dataGridViewCellStyle5.Format = "g";
            dataGridViewCellStyle5.NullValue = null;
            this.NGAYTRA.DefaultCellStyle = dataGridViewCellStyle5;
            this.NGAYTRA.HeaderText = "NGÀY TRẢ";
            this.NGAYTRA.MinimumWidth = 6;
            this.NGAYTRA.Name = "NGAYTRA";
            this.NGAYTRA.ReadOnly = true;
            // 
            // GIAPHONG
            // 
            this.GIAPHONG.DataPropertyName = "GIAPHONG";
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle6.Format = "N0";
            dataGridViewCellStyle6.NullValue = null;
            this.GIAPHONG.DefaultCellStyle = dataGridViewCellStyle6;
            this.GIAPHONG.HeaderText = "GIÁ PHÒNG";
            this.GIAPHONG.MinimumWidth = 6;
            this.GIAPHONG.Name = "GIAPHONG";
            this.GIAPHONG.ReadOnly = true;
            this.GIAPHONG.Visible = false;
            // 
            // MALOAIHINH
            // 
            this.MALOAIHINH.DataPropertyName = "MALOAIHINH";
            this.MALOAIHINH.HeaderText = "MÃ LOẠI HÌNH";
            this.MALOAIHINH.MinimumWidth = 6;
            this.MALOAIHINH.Name = "MALOAIHINH";
            this.MALOAIHINH.ReadOnly = true;
            this.MALOAIHINH.Visible = false;
            // 
            // TENLOAIHINH
            // 
            this.TENLOAIHINH.DataPropertyName = "TENLOAIHINH";
            this.TENLOAIHINH.HeaderText = "LOẠI HÌNH";
            this.TENLOAIHINH.MinimumWidth = 6;
            this.TENLOAIHINH.Name = "TENLOAIHINH";
            this.TENLOAIHINH.ReadOnly = true;
            this.TENLOAIHINH.Visible = false;
            // 
            // MATRANGTHAI
            // 
            this.MATRANGTHAI.DataPropertyName = "MATRANGTHAI";
            this.MATRANGTHAI.HeaderText = "MÃ TRẠNG THÁI";
            this.MATRANGTHAI.MinimumWidth = 6;
            this.MATRANGTHAI.Name = "MATRANGTHAI";
            this.MATRANGTHAI.ReadOnly = true;
            this.MATRANGTHAI.Visible = false;
            // 
            // TENTRANGTHAI
            // 
            this.TENTRANGTHAI.DataPropertyName = "TENTRANGTHAI";
            this.TENTRANGTHAI.HeaderText = "TRẠNG THÁI";
            this.TENTRANGTHAI.MinimumWidth = 6;
            this.TENTRANGTHAI.Name = "TENTRANGTHAI";
            this.TENTRANGTHAI.ReadOnly = true;
            // 
            // GHICHU
            // 
            this.GHICHU.DataPropertyName = "GHICHU";
            this.GHICHU.HeaderText = "GHI CHÚ";
            this.GHICHU.MinimumWidth = 6;
            this.GHICHU.Name = "GHICHU";
            this.GHICHU.ReadOnly = true;
            this.GHICHU.Visible = false;
            // 
            // THOIHAN
            // 
            this.THOIHAN.DataPropertyName = "THOIHAN";
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle7.Format = "N2";
            dataGridViewCellStyle7.NullValue = null;
            this.THOIHAN.DefaultCellStyle = dataGridViewCellStyle7;
            this.THOIHAN.HeaderText = "THỜI HẠN";
            this.THOIHAN.MinimumWidth = 6;
            this.THOIHAN.Name = "THOIHAN";
            this.THOIHAN.ReadOnly = true;
            this.THOIHAN.Visible = false;
            // 
            // PanelControl2
            // 
            this.PanelControl2.Controls.Add(this.KhachHang_SLUE);
            this.PanelControl2.Controls.Add(this.NutHuy);
            this.PanelControl2.Controls.Add(this.NutOK);
            this.PanelControl2.Controls.Add(this.TongTienPhong);
            this.PanelControl2.Controls.Add(this.LabelControl5);
            this.PanelControl2.Controls.Add(this.SoPhongThanhToan);
            this.PanelControl2.Controls.Add(this.LabelControl4);
            this.PanelControl2.Controls.Add(this.SoPhongDangDung);
            this.PanelControl2.Controls.Add(this.LabelControl1);
            this.PanelControl2.Controls.Add(this.LabelControl2);
            this.PanelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.PanelControl2.Location = new System.Drawing.Point(765, 3);
            this.PanelControl2.Name = "PanelControl2";
            this.PanelControl2.Size = new System.Drawing.Size(432, 657);
            this.PanelControl2.TabIndex = 9;
            // 
            // KhachHang_SLUE
            // 
            this.KhachHang_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.KhachHang_SLUE.Enabled = false;
            this.KhachHang_SLUE.Location = new System.Drawing.Point(134, 7);
            this.KhachHang_SLUE.Name = "KhachHang_SLUE";
            this.KhachHang_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.KhachHang_SLUE.Properties.Appearance.Options.UseFont = true;
            this.KhachHang_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.KhachHang_SLUE.Properties.DisplayMember = "HOVATEN";
            this.KhachHang_SLUE.Properties.PopupView = this.GridView9;
            this.KhachHang_SLUE.Properties.ValueMember = "IDKHACH";
            this.KhachHang_SLUE.Size = new System.Drawing.Size(290, 36);
            this.KhachHang_SLUE.TabIndex = 20;
            // 
            // GridView9
            // 
            this.GridView9.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView9.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView9.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView9.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView9.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView9.Appearance.Row.Options.UseFont = true;
            this.GridView9.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn17,
            this.GridColumn18});
            this.GridView9.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView9.Name = "GridView9";
            this.GridView9.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView9.OptionsView.ShowGroupPanel = false;
            this.GridView9.OptionsView.ShowIndicator = false;
            // 
            // GridColumn17
            // 
            this.GridColumn17.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn17.AppearanceHeader.Options.UseFont = true;
            this.GridColumn17.Caption = "ID KHÁCH";
            this.GridColumn17.FieldName = "IDKHACH";
            this.GridColumn17.Name = "GridColumn17";
            this.GridColumn17.Visible = true;
            this.GridColumn17.VisibleIndex = 0;
            // 
            // GridColumn18
            // 
            this.GridColumn18.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn18.AppearanceHeader.Options.UseFont = true;
            this.GridColumn18.Caption = "HỌ VÀ TÊN";
            this.GridColumn18.FieldName = "HOVATEN";
            this.GridColumn18.Name = "GridColumn18";
            this.GridColumn18.Visible = true;
            this.GridColumn18.VisibleIndex = 1;
            // 
            // NutHuy
            // 
            this.NutHuy.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutHuy.Appearance.Options.UseFont = true;
            this.NutHuy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutHuy.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.NutHuy.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutHuy.ImageOptions.SvgImage")));
            this.NutHuy.Location = new System.Drawing.Point(230, 602);
            this.NutHuy.Name = "NutHuy";
            this.NutHuy.Size = new System.Drawing.Size(94, 46);
            this.NutHuy.TabIndex = 19;
            this.NutHuy.Text = "HỦY";
            // 
            // NutOK
            // 
            this.NutOK.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.NutOK.Appearance.Options.UseFont = true;
            this.NutOK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.NutOK.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutOK.ImageOptions.SvgImage")));
            this.NutOK.Location = new System.Drawing.Point(330, 602);
            this.NutOK.Name = "NutOK";
            this.NutOK.Size = new System.Drawing.Size(94, 46);
            this.NutOK.TabIndex = 18;
            this.NutOK.Text = "OK";
            this.NutOK.Click += new System.EventHandler(this.NutOK_Click);
            // 
            // TongTienPhong
            // 
            this.TongTienPhong.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.TongTienPhong.Enabled = false;
            this.TongTienPhong.Location = new System.Drawing.Point(245, 196);
            this.TongTienPhong.Name = "TongTienPhong";
            this.TongTienPhong.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TongTienPhong.Properties.Appearance.Options.UseFont = true;
            this.TongTienPhong.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TongTienPhong.Properties.IsFloatValue = false;
            this.TongTienPhong.Properties.MaskSettings.Set("mask", "N00");
            this.TongTienPhong.Size = new System.Drawing.Size(178, 36);
            this.TongTienPhong.TabIndex = 17;
            // 
            // LabelControl5
            // 
            this.LabelControl5.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.LabelControl5.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.LabelControl5.Appearance.Options.UseFont = true;
            this.LabelControl5.Appearance.Options.UseForeColor = true;
            this.LabelControl5.Location = new System.Drawing.Point(7, 199);
            this.LabelControl5.Name = "LabelControl5";
            this.LabelControl5.Size = new System.Drawing.Size(176, 30);
            this.LabelControl5.TabIndex = 16;
            this.LabelControl5.Text = "Tổng Tiền Phòng";
            // 
            // SoPhongThanhToan
            // 
            this.SoPhongThanhToan.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SoPhongThanhToan.Enabled = false;
            this.SoPhongThanhToan.Location = new System.Drawing.Point(245, 130);
            this.SoPhongThanhToan.Name = "SoPhongThanhToan";
            this.SoPhongThanhToan.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoPhongThanhToan.Properties.Appearance.Options.UseFont = true;
            this.SoPhongThanhToan.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SoPhongThanhToan.Properties.IsFloatValue = false;
            this.SoPhongThanhToan.Properties.MaskSettings.Set("mask", "N00");
            this.SoPhongThanhToan.Size = new System.Drawing.Size(178, 36);
            this.SoPhongThanhToan.TabIndex = 15;
            // 
            // LabelControl4
            // 
            this.LabelControl4.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl4.Appearance.Options.UseFont = true;
            this.LabelControl4.Location = new System.Drawing.Point(5, 133);
            this.LabelControl4.Name = "LabelControl4";
            this.LabelControl4.Size = new System.Drawing.Size(210, 30);
            this.LabelControl4.TabIndex = 14;
            this.LabelControl4.Text = "Số Phòng Thanh Toán";
            // 
            // SoPhongDangDung
            // 
            this.SoPhongDangDung.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.SoPhongDangDung.Enabled = false;
            this.SoPhongDangDung.Location = new System.Drawing.Point(245, 69);
            this.SoPhongDangDung.Name = "SoPhongDangDung";
            this.SoPhongDangDung.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.SoPhongDangDung.Properties.Appearance.Options.UseFont = true;
            this.SoPhongDangDung.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.SoPhongDangDung.Properties.IsFloatValue = false;
            this.SoPhongDangDung.Properties.MaskSettings.Set("mask", "N00");
            this.SoPhongDangDung.Size = new System.Drawing.Size(179, 36);
            this.SoPhongDangDung.TabIndex = 13;
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(6, 72);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(208, 30);
            this.LabelControl1.TabIndex = 12;
            this.LabelControl1.Text = "Số Phòng Đang Dùng";
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Location = new System.Drawing.Point(7, 10);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(116, 30);
            this.LabelControl2.TabIndex = 10;
            this.LabelControl2.Text = "Khách Hàng";
            // 
            // ThongTinTraPhongO
            // 
            this.AcceptButton = this.NutOK;
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.NutHuy;
            this.ClientSize = new System.Drawing.Size(1200, 663);
            this.Controls.Add(this.LayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "ThongTinTraPhongO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "THÔNG TIN TRẢ PHÒNG";
            this.Load += new System.EventHandler(this.FormLoading);
            this.LayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl1)).EndInit();
            this.PanelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.BangDuLieu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PanelControl2)).EndInit();
            this.PanelControl2.ResumeLayout(false);
            this.PanelControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.KhachHang_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TongTienPhong.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoPhongThanhToan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.SoPhongDangDung.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel LayoutPanel1;
        private DevExpress.XtraEditors.PanelControl PanelControl1;
        private Guna.UI2.WinForms.Guna2DataGridView BangDuLieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONGDAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn TextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn TextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYDAT;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYLAY;
        private System.Windows.Forms.DataGridViewTextBoxColumn NGAYTRA;
        private System.Windows.Forms.DataGridViewTextBoxColumn GIAPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn MALOAIHINH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENLOAIHINH;
        private System.Windows.Forms.DataGridViewTextBoxColumn MATRANGTHAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENTRANGTHAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn GHICHU;
        private System.Windows.Forms.DataGridViewTextBoxColumn THOIHAN;
        private DevExpress.XtraEditors.PanelControl PanelControl2;
        private DevExpress.XtraEditors.LabelControl LabelControl2;
        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private DevExpress.XtraEditors.SpinEdit SoPhongThanhToan;
        private DevExpress.XtraEditors.LabelControl LabelControl4;
        private DevExpress.XtraEditors.SpinEdit SoPhongDangDung;
        private DevExpress.XtraEditors.SpinEdit TongTienPhong;
        private DevExpress.XtraEditors.LabelControl LabelControl5;
        private DevExpress.XtraEditors.SimpleButton NutHuy;
        private DevExpress.XtraEditors.SimpleButton NutOK;
        private DevExpress.XtraEditors.SearchLookUpEdit KhachHang_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView9;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn17;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn18;
    }
}