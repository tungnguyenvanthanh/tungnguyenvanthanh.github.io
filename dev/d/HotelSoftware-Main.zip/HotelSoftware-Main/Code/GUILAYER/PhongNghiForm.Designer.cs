﻿namespace GUILAYER
{
    partial class PhongNghiForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PhongNghiForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this.BarManager = new DevExpress.XtraBars.BarManager(this.components);
            this.Bar1 = new DevExpress.XtraBars.Bar();
            this.NutThem = new DevExpress.XtraBars.BarButtonItem();
            this.NutSua = new DevExpress.XtraBars.BarButtonItem();
            this.NutXoa = new DevExpress.XtraBars.BarButtonItem();
            this.BarDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.BarDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.DockManager1 = new DevExpress.XtraBars.Docking.DockManager(this.components);
            this.ThanhPhanLoai = new DevExpress.XtraBars.Docking.DockPanel();
            this.DockPanel1_Container = new DevExpress.XtraBars.Docking.ControlContainer();
            this.PhongSearch = new DevExpress.XtraEditors.SearchControl();
            this.LabelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.TrangThai_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView4 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.TinhTrang_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView3 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Loai_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView2 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.LabelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.Tang_SLUE = new DevExpress.XtraEditors.SearchLookUpEdit();
            this.GridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.GridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.GridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.LabelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.BangDuLieu = new Guna.UI2.WinForms.Guna2DataGridView();
            this.MAPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENTANG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TANGTHU = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MALOAIPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENLOAIPHONG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MATINHTRANG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENTINHTRANG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MATRANGTHAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TENTRANGTHAI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIENTHEOH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TIENTHEOD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Lock = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.BarManager)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DockManager1)).BeginInit();
            this.ThanhPhanLoai.SuspendLayout();
            this.DockPanel1_Container.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PhongSearch.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThai_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TinhTrang_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Loai_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tang_SLUE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangDuLieu)).BeginInit();
            this.SuspendLayout();
            // 
            // BarManager
            // 
            this.BarManager.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.Bar1});
            this.BarManager.DockControls.Add(this.BarDockControlTop);
            this.BarManager.DockControls.Add(this.BarDockControlBottom);
            this.BarManager.DockControls.Add(this.BarDockControlLeft);
            this.BarManager.DockControls.Add(this.BarDockControlRight);
            this.BarManager.DockManager = this.DockManager1;
            this.BarManager.Form = this;
            this.BarManager.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.NutThem,
            this.NutXoa,
            this.NutSua});
            this.BarManager.MainMenu = this.Bar1;
            this.BarManager.MaxItemId = 6;
            // 
            // Bar1
            // 
            this.Bar1.BarName = "Main menu";
            this.Bar1.DockCol = 0;
            this.Bar1.DockRow = 0;
            this.Bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.Bar1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.NutThem, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.NutSua, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.NutXoa, "", true, true, true, 0, null, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.Bar1.OptionsBar.MultiLine = true;
            this.Bar1.OptionsBar.UseWholeRow = true;
            this.Bar1.Text = "Main menu";
            // 
            // NutThem
            // 
            this.NutThem.Caption = "THÊM";
            this.NutThem.Id = 0;
            this.NutThem.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutThem.ImageOptions.SvgImage")));
            this.NutThem.Name = "NutThem";
            this.NutThem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutThem_ItemClick);
            // 
            // NutSua
            // 
            this.NutSua.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            this.NutSua.Caption = "CẬP NHẬT";
            this.NutSua.Enabled = false;
            this.NutSua.Id = 3;
            this.NutSua.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutSua.ImageOptions.SvgImage")));
            this.NutSua.Name = "NutSua";
            this.NutSua.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutSua_ItemClick);
            // 
            // NutXoa
            // 
            this.NutXoa.Caption = "XÓA";
            this.NutXoa.Enabled = false;
            this.NutXoa.Id = 1;
            this.NutXoa.ImageOptions.SvgImage = ((DevExpress.Utils.Svg.SvgImage)(resources.GetObject("NutXoa.ImageOptions.SvgImage")));
            this.NutXoa.Name = "NutXoa";
            this.NutXoa.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.NutXoa_ItemClick);
            // 
            // BarDockControlTop
            // 
            this.BarDockControlTop.CausesValidation = false;
            this.BarDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.BarDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.BarDockControlTop.Manager = this.BarManager;
            this.BarDockControlTop.Size = new System.Drawing.Size(1883, 35);
            // 
            // BarDockControlBottom
            // 
            this.BarDockControlBottom.CausesValidation = false;
            this.BarDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.BarDockControlBottom.Location = new System.Drawing.Point(0, 741);
            this.BarDockControlBottom.Manager = this.BarManager;
            this.BarDockControlBottom.Size = new System.Drawing.Size(1883, 0);
            // 
            // BarDockControlLeft
            // 
            this.BarDockControlLeft.CausesValidation = false;
            this.BarDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.BarDockControlLeft.Location = new System.Drawing.Point(0, 35);
            this.BarDockControlLeft.Manager = this.BarManager;
            this.BarDockControlLeft.Size = new System.Drawing.Size(0, 706);
            // 
            // BarDockControlRight
            // 
            this.BarDockControlRight.CausesValidation = false;
            this.BarDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.BarDockControlRight.Location = new System.Drawing.Point(1883, 35);
            this.BarDockControlRight.Manager = this.BarManager;
            this.BarDockControlRight.Size = new System.Drawing.Size(0, 706);
            // 
            // DockManager1
            // 
            this.DockManager1.Form = this;
            this.DockManager1.MenuManager = this.BarManager;
            this.DockManager1.RootPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.ThanhPhanLoai});
            this.DockManager1.Style = DevExpress.XtraBars.Docking2010.Views.DockingViewStyle.Light;
            this.DockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "DevExpress.XtraBars.StandaloneBarDockControl",
            "System.Windows.Forms.MenuStrip",
            "System.Windows.Forms.StatusStrip",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl",
            "DevExpress.XtraBars.Navigation.OfficeNavigationBar",
            "DevExpress.XtraBars.Navigation.TileNavPane",
            "DevExpress.XtraBars.TabFormControl",
            "DevExpress.XtraBars.FluentDesignSystem.FluentDesignFormControl",
            "DevExpress.XtraBars.ToolbarForm.ToolbarFormControl"});
            // 
            // ThanhPhanLoai
            // 
            this.ThanhPhanLoai.Controls.Add(this.DockPanel1_Container);
            this.ThanhPhanLoai.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.ThanhPhanLoai.FloatSize = new System.Drawing.Size(310, 706);
            this.ThanhPhanLoai.ID = new System.Guid("7e32f08d-ae36-4781-9d15-af98623d8298");
            this.ThanhPhanLoai.Location = new System.Drawing.Point(0, 35);
            this.ThanhPhanLoai.Name = "ThanhPhanLoai";
            this.ThanhPhanLoai.Options.ShowCloseButton = false;
            this.ThanhPhanLoai.OriginalSize = new System.Drawing.Size(310, 200);
            this.ThanhPhanLoai.Size = new System.Drawing.Size(310, 706);
            this.ThanhPhanLoai.Text = "THANH PHÂN LOẠI";
            // 
            // DockPanel1_Container
            // 
            this.DockPanel1_Container.Controls.Add(this.PhongSearch);
            this.DockPanel1_Container.Controls.Add(this.LabelControl5);
            this.DockPanel1_Container.Controls.Add(this.TrangThai_SLUE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl4);
            this.DockPanel1_Container.Controls.Add(this.TinhTrang_SLUE);
            this.DockPanel1_Container.Controls.Add(this.Loai_SLUE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl3);
            this.DockPanel1_Container.Controls.Add(this.LabelControl2);
            this.DockPanel1_Container.Controls.Add(this.Tang_SLUE);
            this.DockPanel1_Container.Controls.Add(this.LabelControl1);
            this.DockPanel1_Container.Location = new System.Drawing.Point(0, 33);
            this.DockPanel1_Container.Name = "DockPanel1_Container";
            this.DockPanel1_Container.Size = new System.Drawing.Size(309, 673);
            this.DockPanel1_Container.TabIndex = 0;
            // 
            // PhongSearch
            // 
            this.PhongSearch.EditValue = "";
            this.PhongSearch.Location = new System.Drawing.Point(10, 434);
            this.PhongSearch.MenuManager = this.BarManager;
            this.PhongSearch.Name = "PhongSearch";
            this.PhongSearch.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.PhongSearch.Properties.Appearance.Options.UseFont = true;
            this.PhongSearch.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Repository.ClearButton(),
            new DevExpress.XtraEditors.Repository.SearchButton()});
            this.PhongSearch.Size = new System.Drawing.Size(290, 36);
            this.PhongSearch.TabIndex = 11;
            this.PhongSearch.TextChanged += new System.EventHandler(this.PhongSearch_TextChanged);
            // 
            // LabelControl5
            // 
            this.LabelControl5.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl5.Appearance.Options.UseFont = true;
            this.LabelControl5.Location = new System.Drawing.Point(10, 398);
            this.LabelControl5.Name = "LabelControl5";
            this.LabelControl5.Size = new System.Drawing.Size(91, 30);
            this.LabelControl5.TabIndex = 20;
            this.LabelControl5.Text = "Tìm Kiếm";
            // 
            // TrangThai_SLUE
            // 
            this.TrangThai_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TrangThai_SLUE.Location = new System.Drawing.Point(10, 327);
            this.TrangThai_SLUE.MenuManager = this.BarManager;
            this.TrangThai_SLUE.Name = "TrangThai_SLUE";
            this.TrangThai_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TrangThai_SLUE.Properties.Appearance.Options.UseFont = true;
            this.TrangThai_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TrangThai_SLUE.Properties.DisplayMember = "TENTRANGTHAI";
            this.TrangThai_SLUE.Properties.NullText = "ALL";
            this.TrangThai_SLUE.Properties.PopupView = this.GridView4;
            this.TrangThai_SLUE.Properties.ValueMember = "MATRANGTHAI";
            this.TrangThai_SLUE.Size = new System.Drawing.Size(291, 36);
            this.TrangThai_SLUE.TabIndex = 18;
            this.TrangThai_SLUE.EditValueChanged += new System.EventHandler(this.TrangThai_EditValueChanged);
            // 
            // GridView4
            // 
            this.GridView4.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView4.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView4.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView4.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView4.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView4.Appearance.Row.Options.UseFont = true;
            this.GridView4.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn8,
            this.GridColumn7});
            this.GridView4.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView4.Name = "GridView4";
            this.GridView4.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView4.OptionsView.ShowGroupPanel = false;
            this.GridView4.OptionsView.ShowIndicator = false;
            this.GridView4.RowHeight = 40;
            // 
            // GridColumn8
            // 
            this.GridColumn8.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn8.AppearanceHeader.Options.UseFont = true;
            this.GridColumn8.Caption = "TÊN TRẠNG THÁI";
            this.GridColumn8.FieldName = "TENTRANGTHAI";
            this.GridColumn8.Name = "GridColumn8";
            this.GridColumn8.Visible = true;
            this.GridColumn8.VisibleIndex = 0;
            // 
            // GridColumn7
            // 
            this.GridColumn7.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn7.AppearanceHeader.Options.UseFont = true;
            this.GridColumn7.Caption = "MÔ TẢ";
            this.GridColumn7.FieldName = "MOTA";
            this.GridColumn7.Name = "GridColumn7";
            this.GridColumn7.Visible = true;
            this.GridColumn7.VisibleIndex = 1;
            // 
            // LabelControl4
            // 
            this.LabelControl4.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl4.Appearance.Options.UseFont = true;
            this.LabelControl4.Location = new System.Drawing.Point(10, 291);
            this.LabelControl4.Name = "LabelControl4";
            this.LabelControl4.Size = new System.Drawing.Size(100, 30);
            this.LabelControl4.TabIndex = 19;
            this.LabelControl4.Text = "Trạng Thái";
            // 
            // TinhTrang_SLUE
            // 
            this.TinhTrang_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TinhTrang_SLUE.Location = new System.Drawing.Point(10, 229);
            this.TinhTrang_SLUE.MenuManager = this.BarManager;
            this.TinhTrang_SLUE.Name = "TinhTrang_SLUE";
            this.TinhTrang_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.TinhTrang_SLUE.Properties.Appearance.Options.UseFont = true;
            this.TinhTrang_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.TinhTrang_SLUE.Properties.DisplayMember = "TENTINHTRANG";
            this.TinhTrang_SLUE.Properties.NullText = "ALL";
            this.TinhTrang_SLUE.Properties.PopupView = this.GridView3;
            this.TinhTrang_SLUE.Properties.ValueMember = "MATINHTRANG";
            this.TinhTrang_SLUE.Size = new System.Drawing.Size(291, 36);
            this.TinhTrang_SLUE.TabIndex = 16;
            this.TinhTrang_SLUE.EditValueChanged += new System.EventHandler(this.TinhTrang_EditValueChanged);
            // 
            // GridView3
            // 
            this.GridView3.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView3.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView3.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView3.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView3.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView3.Appearance.Row.Options.UseFont = true;
            this.GridView3.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn6,
            this.GridColumn4});
            this.GridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView3.Name = "GridView3";
            this.GridView3.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView3.OptionsView.ShowGroupPanel = false;
            this.GridView3.OptionsView.ShowIndicator = false;
            this.GridView3.RowHeight = 40;
            // 
            // GridColumn6
            // 
            this.GridColumn6.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn6.AppearanceHeader.Options.UseFont = true;
            this.GridColumn6.Caption = "TÊN TÌNH TRẠNG";
            this.GridColumn6.FieldName = "TENTINHTRANG";
            this.GridColumn6.Name = "GridColumn6";
            this.GridColumn6.Visible = true;
            this.GridColumn6.VisibleIndex = 0;
            // 
            // GridColumn4
            // 
            this.GridColumn4.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn4.AppearanceHeader.Options.UseFont = true;
            this.GridColumn4.Caption = "MÔ TẢ";
            this.GridColumn4.FieldName = "MOTA";
            this.GridColumn4.Name = "GridColumn4";
            this.GridColumn4.Visible = true;
            this.GridColumn4.VisibleIndex = 1;
            // 
            // Loai_SLUE
            // 
            this.Loai_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Loai_SLUE.Location = new System.Drawing.Point(10, 136);
            this.Loai_SLUE.MenuManager = this.BarManager;
            this.Loai_SLUE.Name = "Loai_SLUE";
            this.Loai_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.Loai_SLUE.Properties.Appearance.Options.UseFont = true;
            this.Loai_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.Loai_SLUE.Properties.DisplayMember = "TENLOAIPHONG";
            this.Loai_SLUE.Properties.NullText = "ALL";
            this.Loai_SLUE.Properties.PopupView = this.GridView2;
            this.Loai_SLUE.Properties.ValueMember = "MALOAIPHONG";
            this.Loai_SLUE.Size = new System.Drawing.Size(291, 36);
            this.Loai_SLUE.TabIndex = 14;
            this.Loai_SLUE.EditValueChanged += new System.EventHandler(this.LoaiPhong_EditValueChanged);
            // 
            // GridView2
            // 
            this.GridView2.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView2.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView2.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView2.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView2.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F);
            this.GridView2.Appearance.Row.Options.UseFont = true;
            this.GridView2.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn3,
            this.GridColumn5});
            this.GridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView2.Name = "GridView2";
            this.GridView2.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView2.OptionsView.ShowGroupPanel = false;
            this.GridView2.OptionsView.ShowIndicator = false;
            this.GridView2.RowHeight = 40;
            // 
            // GridColumn3
            // 
            this.GridColumn3.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn3.AppearanceHeader.Options.UseFont = true;
            this.GridColumn3.Caption = "TÊN LOẠI";
            this.GridColumn3.FieldName = "TENLOAIPHONG";
            this.GridColumn3.Name = "GridColumn3";
            this.GridColumn3.Visible = true;
            this.GridColumn3.VisibleIndex = 0;
            // 
            // GridColumn5
            // 
            this.GridColumn5.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn5.AppearanceHeader.Options.UseFont = true;
            this.GridColumn5.Caption = "MÔ TẢ";
            this.GridColumn5.FieldName = "MOTA";
            this.GridColumn5.Name = "GridColumn5";
            this.GridColumn5.Visible = true;
            this.GridColumn5.VisibleIndex = 1;
            // 
            // LabelControl3
            // 
            this.LabelControl3.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl3.Appearance.Options.UseFont = true;
            this.LabelControl3.Location = new System.Drawing.Point(10, 193);
            this.LabelControl3.Name = "LabelControl3";
            this.LabelControl3.Size = new System.Drawing.Size(101, 30);
            this.LabelControl3.TabIndex = 17;
            this.LabelControl3.Text = "Tình Trạng";
            // 
            // LabelControl2
            // 
            this.LabelControl2.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl2.Appearance.Options.UseFont = true;
            this.LabelControl2.Location = new System.Drawing.Point(10, 100);
            this.LabelControl2.Name = "LabelControl2";
            this.LabelControl2.Size = new System.Drawing.Size(39, 30);
            this.LabelControl2.TabIndex = 15;
            this.LabelControl2.Text = "Loại";
            // 
            // Tang_SLUE
            // 
            this.Tang_SLUE.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Tang_SLUE.Location = new System.Drawing.Point(10, 39);
            this.Tang_SLUE.MenuManager = this.BarManager;
            this.Tang_SLUE.Name = "Tang_SLUE";
            this.Tang_SLUE.Properties.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.Tang_SLUE.Properties.Appearance.Options.UseFont = true;
            this.Tang_SLUE.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.Tang_SLUE.Properties.DisplayMember = "TENTANG";
            this.Tang_SLUE.Properties.NullText = "ALL";
            this.Tang_SLUE.Properties.PopupView = this.GridView1;
            this.Tang_SLUE.Properties.ValueMember = "TANGTHU";
            this.Tang_SLUE.Size = new System.Drawing.Size(291, 36);
            this.Tang_SLUE.TabIndex = 12;
            this.Tang_SLUE.EditValueChanged += new System.EventHandler(this.Tang_SLUE_EditValueChanged);
            // 
            // GridView1
            // 
            this.GridView1.Appearance.FocusedRow.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.GridView1.Appearance.FocusedRow.ForeColor = System.Drawing.Color.Black;
            this.GridView1.Appearance.FocusedRow.Options.UseBackColor = true;
            this.GridView1.Appearance.FocusedRow.Options.UseForeColor = true;
            this.GridView1.Appearance.Row.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GridView1.Appearance.Row.Options.UseFont = true;
            this.GridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.GridColumn2,
            this.GridColumn1});
            this.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.GridView1.Name = "GridView1";
            this.GridView1.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.GridView1.OptionsView.ShowGroupPanel = false;
            this.GridView1.OptionsView.ShowIndicator = false;
            this.GridView1.RowHeight = 40;
            // 
            // GridColumn2
            // 
            this.GridColumn2.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn2.AppearanceHeader.Options.UseFont = true;
            this.GridColumn2.Caption = "TẦNG THỨ";
            this.GridColumn2.FieldName = "TANGTHU";
            this.GridColumn2.Name = "GridColumn2";
            this.GridColumn2.Visible = true;
            this.GridColumn2.VisibleIndex = 0;
            // 
            // GridColumn1
            // 
            this.GridColumn1.AppearanceHeader.Font = new System.Drawing.Font("Segoe UI", 7.8F, System.Drawing.FontStyle.Bold);
            this.GridColumn1.AppearanceHeader.Options.UseFont = true;
            this.GridColumn1.Caption = "TÊN TẦNG";
            this.GridColumn1.FieldName = "TENTANG";
            this.GridColumn1.Name = "GridColumn1";
            this.GridColumn1.Visible = true;
            this.GridColumn1.VisibleIndex = 1;
            // 
            // LabelControl1
            // 
            this.LabelControl1.Appearance.Font = new System.Drawing.Font("Segoe UI", 13F);
            this.LabelControl1.Appearance.Options.UseFont = true;
            this.LabelControl1.Location = new System.Drawing.Point(10, 3);
            this.LabelControl1.Name = "LabelControl1";
            this.LabelControl1.Size = new System.Drawing.Size(48, 30);
            this.LabelControl1.TabIndex = 13;
            this.LabelControl1.Text = "Tầng";
            // 
            // BangDuLieu
            // 
            this.BangDuLieu.AllowUserToAddRows = false;
            this.BangDuLieu.AllowUserToDeleteRows = false;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.White;
            this.BangDuLieu.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle6;
            this.BangDuLieu.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.BangDuLieu.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangDuLieu.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.BangDuLieu.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangDuLieu.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.BangDuLieu.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.BangDuLieu.ColumnHeadersHeight = 40;
            this.BangDuLieu.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.MAPHONG,
            this.TENPHONG,
            this.TENTANG,
            this.TANGTHU,
            this.MALOAIPHONG,
            this.TENLOAIPHONG,
            this.MATINHTRANG,
            this.TENTINHTRANG,
            this.MATRANGTHAI,
            this.TENTRANGTHAI,
            this.TIENTHEOH,
            this.TIENTHEOD});
            this.BangDuLieu.Cursor = System.Windows.Forms.Cursors.Hand;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.Color.Black;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.BangDuLieu.DefaultCellStyle = dataGridViewCellStyle10;
            this.BangDuLieu.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BangDuLieu.EnableHeadersVisualStyles = false;
            this.BangDuLieu.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangDuLieu.Location = new System.Drawing.Point(310, 35);
            this.BangDuLieu.Name = "BangDuLieu";
            this.BangDuLieu.ReadOnly = true;
            this.BangDuLieu.RowHeadersVisible = false;
            this.BangDuLieu.RowHeadersWidth = 51;
            this.BangDuLieu.RowTemplate.Height = 40;
            this.BangDuLieu.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.BangDuLieu.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.BangDuLieu.Size = new System.Drawing.Size(1573, 706);
            this.BangDuLieu.TabIndex = 11;
            this.BangDuLieu.Theme = Guna.UI2.WinForms.Enums.DataGridViewPresetThemes.LightGrid;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.BackColor = System.Drawing.Color.White;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.Font = null;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.ForeColor = System.Drawing.Color.Empty;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.SelectionBackColor = System.Drawing.Color.Empty;
            this.BangDuLieu.ThemeStyle.AlternatingRowsStyle.SelectionForeColor = System.Drawing.Color.Empty;
            this.BangDuLieu.ThemeStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(214)))), ((int)(((byte)(219)))), ((int)(((byte)(233)))));
            this.BangDuLieu.ThemeStyle.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(239)))), ((int)(((byte)(241)))), ((int)(((byte)(243)))));
            this.BangDuLieu.ThemeStyle.HeaderStyle.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(93)))), ((int)(((byte)(107)))), ((int)(((byte)(153)))));
            this.BangDuLieu.ThemeStyle.HeaderStyle.BorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.BangDuLieu.ThemeStyle.HeaderStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangDuLieu.ThemeStyle.HeaderStyle.ForeColor = System.Drawing.Color.Black;
            this.BangDuLieu.ThemeStyle.HeaderStyle.HeaightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.EnableResizing;
            this.BangDuLieu.ThemeStyle.HeaderStyle.Height = 40;
            this.BangDuLieu.ThemeStyle.ReadOnly = true;
            this.BangDuLieu.ThemeStyle.RowsStyle.BackColor = System.Drawing.Color.White;
            this.BangDuLieu.ThemeStyle.RowsStyle.BorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.BangDuLieu.ThemeStyle.RowsStyle.Font = new System.Drawing.Font("Verdana", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BangDuLieu.ThemeStyle.RowsStyle.ForeColor = System.Drawing.Color.Black;
            this.BangDuLieu.ThemeStyle.RowsStyle.Height = 40;
            this.BangDuLieu.ThemeStyle.RowsStyle.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(245)))), ((int)(((byte)(204)))), ((int)(((byte)(132)))));
            this.BangDuLieu.ThemeStyle.RowsStyle.SelectionForeColor = System.Drawing.Color.Black;
            this.BangDuLieu.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.BangDuLieu_ColumnHeaderMouseClick);
            this.BangDuLieu.SelectionChanged += new System.EventHandler(this.BangDuLieu_SelectionChanged);
            // 
            // MAPHONG
            // 
            this.MAPHONG.DataPropertyName = "MAPHONG";
            this.MAPHONG.HeaderText = "MÃ PHÒNG";
            this.MAPHONG.MinimumWidth = 6;
            this.MAPHONG.Name = "MAPHONG";
            this.MAPHONG.ReadOnly = true;
            // 
            // TENPHONG
            // 
            this.TENPHONG.DataPropertyName = "TENPHONG";
            this.TENPHONG.HeaderText = "TÊN PHÒNG";
            this.TENPHONG.MinimumWidth = 6;
            this.TENPHONG.Name = "TENPHONG";
            this.TENPHONG.ReadOnly = true;
            // 
            // TENTANG
            // 
            this.TENTANG.DataPropertyName = "TENTANG";
            this.TENTANG.HeaderText = "TÊN TẦNG";
            this.TENTANG.MinimumWidth = 6;
            this.TENTANG.Name = "TENTANG";
            this.TENTANG.ReadOnly = true;
            // 
            // TANGTHU
            // 
            this.TANGTHU.DataPropertyName = "TANGTHU";
            this.TANGTHU.HeaderText = "TẦNG THỨ";
            this.TANGTHU.MinimumWidth = 6;
            this.TANGTHU.Name = "TANGTHU";
            this.TANGTHU.ReadOnly = true;
            this.TANGTHU.Visible = false;
            // 
            // MALOAIPHONG
            // 
            this.MALOAIPHONG.DataPropertyName = "MALOAIPHONG";
            this.MALOAIPHONG.HeaderText = "MÃ LOẠI PHÒNG";
            this.MALOAIPHONG.MinimumWidth = 6;
            this.MALOAIPHONG.Name = "MALOAIPHONG";
            this.MALOAIPHONG.ReadOnly = true;
            this.MALOAIPHONG.Visible = false;
            // 
            // TENLOAIPHONG
            // 
            this.TENLOAIPHONG.DataPropertyName = "TENLOAIPHONG";
            this.TENLOAIPHONG.HeaderText = "LOẠI PHÒNG";
            this.TENLOAIPHONG.MinimumWidth = 6;
            this.TENLOAIPHONG.Name = "TENLOAIPHONG";
            this.TENLOAIPHONG.ReadOnly = true;
            // 
            // MATINHTRANG
            // 
            this.MATINHTRANG.DataPropertyName = "MATINHTRANG";
            this.MATINHTRANG.HeaderText = "MÃ TÌNH TRẠNG";
            this.MATINHTRANG.MinimumWidth = 6;
            this.MATINHTRANG.Name = "MATINHTRANG";
            this.MATINHTRANG.ReadOnly = true;
            this.MATINHTRANG.Visible = false;
            // 
            // TENTINHTRANG
            // 
            this.TENTINHTRANG.DataPropertyName = "TENTINHTRANG";
            this.TENTINHTRANG.HeaderText = "TÌNH TRẠNG";
            this.TENTINHTRANG.MinimumWidth = 6;
            this.TENTINHTRANG.Name = "TENTINHTRANG";
            this.TENTINHTRANG.ReadOnly = true;
            // 
            // MATRANGTHAI
            // 
            this.MATRANGTHAI.DataPropertyName = "MATRANGTHAI";
            this.MATRANGTHAI.HeaderText = "MÃ TRẠNG THÁI";
            this.MATRANGTHAI.MinimumWidth = 6;
            this.MATRANGTHAI.Name = "MATRANGTHAI";
            this.MATRANGTHAI.ReadOnly = true;
            this.MATRANGTHAI.Visible = false;
            // 
            // TENTRANGTHAI
            // 
            this.TENTRANGTHAI.DataPropertyName = "TENTRANGTHAI";
            this.TENTRANGTHAI.HeaderText = "TRẠNG THÁI";
            this.TENTRANGTHAI.MinimumWidth = 6;
            this.TENTRANGTHAI.Name = "TENTRANGTHAI";
            this.TENTRANGTHAI.ReadOnly = true;
            // 
            // TIENTHEOH
            // 
            this.TIENTHEOH.DataPropertyName = "TIENTHEOH";
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle8.Format = "N0";
            dataGridViewCellStyle8.NullValue = null;
            this.TIENTHEOH.DefaultCellStyle = dataGridViewCellStyle8;
            this.TIENTHEOH.HeaderText = "GIÁ TIỀN TRONG NGÀY";
            this.TIENTHEOH.MinimumWidth = 6;
            this.TIENTHEOH.Name = "TIENTHEOH";
            this.TIENTHEOH.ReadOnly = true;
            this.TIENTHEOH.Visible = false;
            // 
            // TIENTHEOD
            // 
            this.TIENTHEOD.DataPropertyName = "TIENTHEOD";
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            dataGridViewCellStyle9.Format = "N0";
            dataGridViewCellStyle9.NullValue = null;
            this.TIENTHEOD.DefaultCellStyle = dataGridViewCellStyle9;
            this.TIENTHEOD.HeaderText = "GIÁ TIỀN NGOÀI NGÀY";
            this.TIENTHEOD.MinimumWidth = 6;
            this.TIENTHEOD.Name = "TIENTHEOD";
            this.TIENTHEOD.ReadOnly = true;
            this.TIENTHEOD.Visible = false;
            // 
            // Lock
            // 
            this.Lock.Interval = 500;
            this.Lock.Tick += new System.EventHandler(this.PhongSearchAfterTyping);
            // 
            // PhongNghiForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1883, 741);
            this.Controls.Add(this.BangDuLieu);
            this.Controls.Add(this.ThanhPhanLoai);
            this.Controls.Add(this.BarDockControlLeft);
            this.Controls.Add(this.BarDockControlRight);
            this.Controls.Add(this.BarDockControlBottom);
            this.Controls.Add(this.BarDockControlTop);
            this.IconOptions.Image = global::GUILAYER.Properties.Resources.Logo;
            this.Name = "PhongNghiForm";
            this.Text = " PHÒNG";
            this.Load += new System.EventHandler(this.PhongHotelForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.BarManager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DockManager1)).EndInit();
            this.ThanhPhanLoai.ResumeLayout(false);
            this.DockPanel1_Container.ResumeLayout(false);
            this.DockPanel1_Container.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PhongSearch.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TrangThai_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TinhTrang_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Loai_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Tang_SLUE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BangDuLieu)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.BarManager BarManager;
        private DevExpress.XtraBars.Bar Bar1;
        private DevExpress.XtraBars.BarButtonItem NutThem;
        private DevExpress.XtraBars.BarButtonItem NutSua;
        private DevExpress.XtraBars.BarButtonItem NutXoa;
        private DevExpress.XtraBars.BarDockControl BarDockControlTop;
        private DevExpress.XtraBars.BarDockControl BarDockControlBottom;
        private DevExpress.XtraBars.BarDockControl BarDockControlLeft;
        private DevExpress.XtraBars.BarDockControl BarDockControlRight;
        private DevExpress.XtraBars.Docking.DockManager DockManager1;
        private DevExpress.XtraBars.Docking.DockPanel ThanhPhanLoai;
        private DevExpress.XtraBars.Docking.ControlContainer DockPanel1_Container;
        private DevExpress.XtraEditors.SearchLookUpEdit Loai_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView2;
        private DevExpress.XtraEditors.LabelControl LabelControl2;
        private DevExpress.XtraEditors.SearchLookUpEdit Tang_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView1;
        private DevExpress.XtraEditors.LabelControl LabelControl1;
        private DevExpress.XtraEditors.SearchControl PhongSearch;
        private DevExpress.XtraEditors.LabelControl LabelControl5;
        private DevExpress.XtraEditors.SearchLookUpEdit TrangThai_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView4;
        private DevExpress.XtraEditors.LabelControl LabelControl4;
        private DevExpress.XtraEditors.SearchLookUpEdit TinhTrang_SLUE;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView3;
        private DevExpress.XtraEditors.LabelControl LabelControl3;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn GridColumn4;
        private Guna.UI2.WinForms.Guna2DataGridView BangDuLieu;
        private System.Windows.Forms.DataGridViewTextBoxColumn MAPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENTANG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TANGTHU;
        private System.Windows.Forms.DataGridViewTextBoxColumn MALOAIPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENLOAIPHONG;
        private System.Windows.Forms.DataGridViewTextBoxColumn MATINHTRANG;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENTINHTRANG;
        private System.Windows.Forms.DataGridViewTextBoxColumn MATRANGTHAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn TENTRANGTHAI;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIENTHEOH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TIENTHEOD;
        private System.Windows.Forms.Timer Lock;
    }
}