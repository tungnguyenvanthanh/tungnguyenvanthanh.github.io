﻿using System;
using System.Linq;

namespace DATALAYER
{
    public class KhachHangCustom
    {
        public string IDKHACH { get; set; }
        public string HOVATEN { get; set; }
        public string MAGT { get; set; }
        public string GIOITINH { get; set; }
        public string SOLIENHE { get; set; }
        public string EMAIL { get; set; }
        public string QUEQUAN { get; set; }
        public string MAQT { get; set; }
        public string QUOCTICH { get; set; }
    }
}