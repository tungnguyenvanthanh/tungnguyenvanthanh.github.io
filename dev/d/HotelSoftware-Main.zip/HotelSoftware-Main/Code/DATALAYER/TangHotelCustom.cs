﻿using System;
using System.Linq;

namespace DATALAYER
{
    public class TangHotelCustom
    {
        public int TANGTHU { get; set; }
        public string TENTANG { get; set; }
        public int TONGSOPHONG { get; set; }
        public int PHONGACTIVE { get; set; }
        public int PHONGREVAMP { get; set; }
        public int PHONGUNUSED { get; set; }
    }
}