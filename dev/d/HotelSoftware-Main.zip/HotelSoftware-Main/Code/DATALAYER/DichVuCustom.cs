﻿using System;
using System.Linq;

namespace DATALAYER
{
    public class DichVuCustom
    {
        public string MADICHVU { get; set; }
        public string TENDICHVU { get; set; }
        public string MALOAIDV { get; set; }
        public string TENLOAIDV { get; set; }
        public int GIADICHVU { get; set; }
        public string MATRANGTHAI { get; set; }
        public string TENTRANGTHAI { get; set; }
        public string MOTA { get; set; }
        public string MALOAIHINH { get; set; }
        public string TENLOAIHINH { get; set; }
    }
}