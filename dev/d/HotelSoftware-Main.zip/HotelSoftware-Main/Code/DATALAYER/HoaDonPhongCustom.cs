﻿using System;
using System.Linq;

namespace DATALAYER
{
    public class HoaDonPhongCustom
    {
        public string MAHOADON { get; set; }
        public string MAPHONGDAT { get; set; }
        public string MAPHONG { get; set; }
        public string TENPHONG { get; set; }
        public string IDKHACH { get; set; }
        public string HOVATEN { get; set; }
        public string MATRANGTHAI { get; set; }
        public string TENTRANGTHAI { get; set; }
        public int GIAMGIA { get; set; }
        public System.DateTime NGAYTHANHTOAN { get; set; }
        public string MATHOIDIEM { get; set; }
        public string TENTHOIDIEM { get; set; }
        public int GIATRIBANDAU { get; set; }
        public int GIATHANHTOAN { get; set; }
    }
}