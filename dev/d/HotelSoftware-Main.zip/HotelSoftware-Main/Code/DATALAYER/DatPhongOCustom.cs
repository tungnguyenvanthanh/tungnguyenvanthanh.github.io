﻿using System;
using System.Linq;

namespace DATALAYER
{
    public class DatPhongOCustom
    {
        public string MAPHONGDAT { get; set; }
        public string IDKHACH { get; set; }
        public string HOVATEN { get; set; }
        public string MAPHONG { get; set; }
        public string TENPHONG { get; set; }
        public Decimal THOIHAN { get; set; }
        public System.DateTime NGAYDAT { get; set; }
        public System.DateTime NGAYLAY { get; set; }
        public System.DateTime NGAYTRA { get; set; }
        public string MALOAIHINH { get; set; }
        public string TENLOAIHINH { get; set; }
        public int GIAPHONG { get; set; }
        public string MATRANGTHAI { get; set; }
        public string TENTRANGTHAI { get; set; }
        public string GHICHU { get; set; }
    }
}