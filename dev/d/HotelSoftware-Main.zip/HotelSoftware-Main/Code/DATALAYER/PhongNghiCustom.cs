﻿using System;
using System.Linq;

namespace DATALAYER
{
    public class PhongNghiCustom
    {
        public string MAPHONG { get; set; }
        public string TENPHONG { get; set; }
        public Nullable<int> TANGTHU { get; set; }
        public string TENTANG { get; set; }
        public string MALOAIPHONG { get; set; }
        public string TENLOAIPHONG { get; set; }
        public string MATINHTRANG { get; set; }
        public string TENTINHTRANG { get; set; }
        public string MATRANGTHAI { get; set; }
        public string TENTRANGTHAI { get; set; }
        public int TIENTHEOD { get; set; }
        public int TIENTHEOH { get; set; }
    }
}